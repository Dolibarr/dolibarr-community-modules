<?php
/* Copyright (C) 2025-2026       Laurent Destailleur         <eldy@users.sourceforge.net>
 * Copyright (C) 2026		Jose Martinez				<jose.martinez@pichinov.com>
 * Copyright (C) 2025-2026       Mohamed DAOUD               <mdaoud@dolicloud.com>
 * Copyright (C) 2026		MDW							<mdeweerd@users.noreply.github.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**
 * \file    einvoicing/class/protocols/CommonProtocol.class.php
 * \ingroup einvoicing
 * \brief   Common methods for all AP protocols.
 */

dol_include_once('einvoicing/lib/einvoicing.lib.php');	// removeAllSpaces(), used to clean the identifiers read from a received document

/**
 * @mixin AbstractProtocol
 */
trait CommonProtocol
{
	/**
	 * Determine Factur-X BillingProcessID (Cadre / Mode de facturation)
	 * according to French e-invoicing
	 *
	 * BillingProcessID allowed values:
	 *
	 * STANDARD INVOICE (initial submission)
	 * --------------------------------------
	 * B1 : Products invoice
	 * S1 : Services invoice
	 * M1 : Mixed invoice (products + services non-accessory)
	 *
	 * INVOICE (already paid)
	 * -------------------------------------------
	 * B2 : Products invoice
	 * S2 : Services invoice
	 * M2 : Mixed invoice (products + services non-accessory)
	 *
	 * FINAL INVOICE AFTER DEPOSIT
	 * ----------------------------
	 * B4 : Final products invoice (after deposit)
	 * S4 : Final services invoice (after deposit)
	 * M4 : Final mixed invoice (after deposit)
	 *
	 * SPECIFIC CASES
	 * --------------
	 * S5 : Services invoice issued by subcontractor
	 * S6 : Services invoice issued by co-contractor
	 *
	 * E-REPORTING CASE (VAT already collected)
	 * -----------------------------------------
	 * B7 : Products invoice already reported (VAT already collected)
	 * S7 : Services invoice already reported (VAT already collected)
	 *
	 * Notes:
	 * - Prefix meaning:
	 *     B = Products
	 *     S = Services
	 *     M = Mixed (products + services non-accessory)
	 *
	 * @param  Facture 		$invoice 		Dolibarr invoice object
	 * @param  float|null	$alreadyPaid	Amount already received that the document will report as
	 *                                      BT-113 (payments + used credit notes). Null recomputes the
	 *                                      payments alone, which is enough for a standalone call.
	 * @return string  BillingProcessID
	 */
	public function getBillingProcessID($invoice, $alreadyPaid = null)
	{
		$hasProduct  = false;
		$hasService  = false;

		// Check invoice lines to determine if invoice contains products, services or both
		if (!empty($invoice->lines)) {
			foreach ($invoice->lines as $line) {
				if ((int) $line->product_type === 0) {
					$hasProduct = true;
				}

				if ((int) $line->product_type === 1) {
					$hasService = true;
				}
			}
		}

		// Determine prefix B / S / M (B1, B2, B3, B4 / S1, S2, S3, S4 / M1, M2, M3, M4)
		if ($hasProduct && $hasService) {
			$prefix = 'M';
		} elseif ($hasService && !$hasProduct) {
			$prefix = 'S';
		} else {
			// Default to products
			$prefix = 'B';
		}

		// Determine suffix 1 (initial invoice) or 2 (already paid invoice) according to invoice status and payment information and if the invoice contain a line a deposit (prepayment) so final invoice after deposit then suffix is 4
		//
		// BT-23 is the billing case of the document, not a payment status: BR-FR-CO-09 makes B2/S2/M2
		// fatal unless the amount already paid (BT-113) equals the total (BT-112) and the amount due
		// (BT-115) is 0. Facture::STATUS_CLOSED alone does not say that, so claim the frame only when
		// the amount the document will actually carry in BT-113 covers the total.
		$totalTtc = (float) price2num($invoice->total_ttc, 'MT');
		if ($alreadyPaid === null) {
			$alreadyPaid = (float) $invoice->getSommePaiement();
		}
		$isFullyPaid = ($totalTtc != 0.0 && abs((float) $alreadyPaid - $totalTtc) < 0.005);

		if ($invoice->status == Facture::STATUS_CLOSED && empty($invoice->close_code) && $isFullyPaid) {
			return $prefix . '2';
		} else {
			// Check if the invoice contains a deposit (prepayment) line
			$hasDepositLine = false;
			if (!empty($invoice->lines)) {
				foreach ($invoice->lines as $line) {
					if ($line->desc == '(DEPOSIT)') {
						$hasDepositLine = true;
						break;
					}
				}
			}
			if ($hasDepositLine) {
				return $prefix . '4';
			}
			return $prefix . '1';
		}
	}

	/**
	 * Find paymentMean number
	 *
	 * @param  CommonInvoice 	$invoice 			object name we look for
	 * @return integer                      paymentMeanId for HorstOeko libs
	 ************************************************/
	private function _getPaymentMeanNumber($invoice)
	{
		$paymentMeanId = 97;
		//"Must be defined between trading parties" for empty values
		switch ($invoice->mode_reglement_code) {
			case 'CB':
				$paymentMeanId = 54;
				break;
				//Credit Card
			case 'CHQ':
				$paymentMeanId = 20;
				break;
				//Check
			case 'FAC':
				$paymentMeanId = 1;
				break;
				//Local payment method
			case 'LIQ':
				$paymentMeanId = 10;
				break;
				//Cash
			case 'PRE':
				$paymentMeanId = 59;
				break;
				//SEPA direct debit
			case 'TIP':
				$paymentMeanId = 45;
				break;
				//Bank Transfer with document
			case 'TRA':
				$paymentMeanId = 23;
				break;
				//Check
			case 'VAD':
				$paymentMeanId = 68;
				break;
				//Online Payment
			case 'VIR':
				$paymentMeanId = 30;
				break;
		}
		return $paymentMeanId;
	}


	/**
	 * Map type of invoices dolibarr <-> facturx
	 *
	 * @param 	CommonInvoice	$object 	The invoice object
	 * @return  string|null 				code of invoice type
	 */
	private function _getTypeOfInvoice($object)
	{
		$map = [
			CommonInvoice::TYPE_STANDARD        => '380',
			CommonInvoice::TYPE_REPLACEMENT     => '384',
			CommonInvoice::TYPE_CREDIT_NOTE     => '381',
			CommonInvoice::TYPE_DEPOSIT         => '386',
			CommonInvoice::TYPE_SITUATION       => '380',				// Process situation invoice as common invoice
		];

		return $map[$object->type] ?? null;
	}


	/**
	 * Return IEC_6523 code (https://docs.peppol.eu/poacc/billing/3.0/codelist/ICD/)
	 * This list of codes describes schemes codes for thirdparties but also products. This functions returns need for thirdparty schemes only.
	 *
	 * @param	string		$country_code		Country code
	 * @param	int			$global				Use 0 for legal ID, use 1 for a global ID, use 2 for URI.
	 * @return string code
	 */
	private function getIEC6523Code($country_code, $global = 0)
	{
		// EINVOICING_PARTY_IDENTIFIER_SCHEME decides the scheme of the party identifier (BT-29, BT-46)
		// alone. It must not reach $global == 2, the electronic address (BT-34, BT-49), where 0225 is
		// the right answer and BR-CL-25 accepts nothing outside the CEF EAS list.
		if ($global == 1) {
			$configured = trim(getDolGlobalString('EINVOICING_PARTY_IDENTIFIER_SCHEME'));
			// 'none' rather than an empty string: an empty option is an option nobody set, which
			// keeps the historical scheme of the country.
			if ($configured !== '') {
				return ($configured === 'none') ? '' : $configured;
			}
		}
		$retour = "";
		switch ($country_code) {
			case 'BE':
				if ($global == 1 || $global == 2) {
					$retour = "0208";
				} else {
					$retour = "0008";
				}
				break;
			case 'DE':
				$retour = "0000";
				break;
			case 'FR':
				if ($global == 1 || $global == 2) {
					$retour = "0225";	// SIREN or SIREN_XXX.  	Einvoice global ID, example: "000000002" or URI OD, example "315143296_1939"
				} else {
					$retour = "0002";	// SIREN.	Used for LegalOrganization, example: "315143296"
				}
				break;
			default:
				$retour = "0060";	// DUNS
		}
		return $retour;
	}

	/**
	 * Value of the party identifier (BT-29, BT-46), which follows the scheme the setup asks for.
	 *
	 * Every entry of the list but the SIRET is declared with the professional identifier idprof()
	 * answers for the country of the party, which is what the module has always written.
	 *
	 * @param	Societe	$thirdparty		Party the identifier belongs to
	 * @return	string					Identifier, empty when that party has nothing under that scheme
	 */
	private function getPartyIdentifierValue($thirdparty)
	{
		if (getDolGlobalString('EINVOICING_PARTY_IDENTIFIER_SCHEME') === '0009') {
			return removeAllSpaces($thirdparty->idprof2);
		}

		return idprof($thirdparty);
	}

	/**
	 * Canonical form of a product reference, for comparison only.
	 *
	 * The same identifier reaches us in as many writings as there are systems it travels through.
	 * A vendor may write 'A1234-10_42' on its order forms and 'A1234|10|42' on its invoices.
	 * Dolibarr stores a product reference through dol_sanitizeFileName(), which replaces every
	 * character forbidden in a file name. A catalogue that went through a spreadsheet comes back
	 * with non breaking spaces. Comparing the raw strings answers "not found" for what is plainly
	 * the same item, so the comparison is done on this canonical form instead: letters and digits
	 * only, upper case.
	 *
	 * This form is a comparison key. It is never stored, never displayed, and never written back
	 * to the reference it was computed from.
	 *
	 * @param	string	$ref	Reference as written by its source
	 * @return	string			Canonical form, empty when nothing comparable is left
	 */
	public static function canonicalRef($ref)
	{
		$ref = dol_string_unaccent((string) $ref);
		$ref = preg_replace('/[^A-Za-z0-9]/', '', $ref);

		return strtoupper((string) $ref);
	}

	/**
	 * Vendor references of one supplier, indexed by their canonical form.
	 *
	 * The normalization is done in PHP rather than in SQL, for three reasons: removing every
	 * separator in SQL needs REGEXP_REPLACE, which is not available on every database Dolibarr
	 * supports; a function applied to the column would prevent the use of any index anyway; and
	 * one query per supplier for a whole invoice costs less than one scan per invoice line.
	 * The result is cached for the run, so importing a hundred lines of the same vendor reads
	 * its references once.
	 *
	 * @param	DoliDB	$db			Database handler
	 * @param	int		$socid		Supplier id
	 * @return	array<string,int>	Canonical reference => product id, 0 when several products share it
	 */
	protected static function canonicalVendorRefMap($db, $socid)
	{
		global $conf;

		static $cache = array();

		// The map depends on the entity, through getEntity() below, so the entity is part of the key.
		$cachekey = ((int) $socid) . '_' . ((int) $conf->entity);
		if (isset($cache[$cachekey])) {
			return $cache[$cachekey];
		}

		$map = array();
		$sql = "SELECT pfp.fk_product, pfp.ref_fourn";
		$sql .= " FROM " . MAIN_DB_PREFIX . "product_fournisseur_price as pfp";
		$sql .= " INNER JOIN " . MAIN_DB_PREFIX . "product as p ON p.rowid = pfp.fk_product";
		$sql .= " WHERE pfp.fk_soc = " . ((int) $socid);
		$sql .= " AND p.entity IN (" . getEntity('product') . ")";
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$key = self::canonicalRef($obj->ref_fourn);
				if ($key === '') {
					continue;
				}
				if (!isset($map[$key])) {
					$map[$key] = (int) $obj->fk_product;
				} elseif ($map[$key] !== (int) $obj->fk_product) {
					$map[$key] = 0;		// two products share that canonical form: undecidable
				}
			}
		}

		$cache[$cachekey] = $map;

		return $map;
	}

	/**
	 * Generate a sample E-invoice for demonstration or testing purposes (for Dolibarr version >= 24.0)
	 *
	 * This method creates a dummy invoice with representative data
	 * to illustrate the E-invoice structure without using real business information.
	 *
	 * @param	EInvoicing			$einvoicing			EInvoicing
	 * @param   Societe|null			$thirdpartySeller		Optional third party object to use for generating the sample invoice. If null, a dummy third party will be created.
	 * @param   Societe|null			$thirdpartyBuyer		Optional third party object to use for generating the sample invoice. If null, a dummy third party will be created.
	 * @param   array<string,mixed>		$options				More options
	 * @return 	-1|array<string,string> 							Path or content of the generated sample invoice.
	 */
	public function generateSampleInvoice($einvoicing, $thirdpartySeller = null, $thirdpartyBuyer = null, $options = array())
	{
		global $conf, $langs, $mysoc;

		dol_mkdir($conf->einvoicing->dir_temp, einvoicingDataRoot($conf->einvoicing->dir_temp));

		$outputlangs = $langs;		// TODO Use the target language

		require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
		$tmpinvoice = new Facture($this->db);
		$tmpinvoice->initAsSpecimen('nolines');

		$tmpinvoice->ref .= '-' . dol_print_date(dol_now(), '%y%m%d-%H%M%S');
		if (!empty($options['invoicetype'])) {
			$tmpinvoice->type = $options['invoicetype'];
		}

		// Reference of the original invoice, for the two types that correct one. A credit note carries
		// it as BT-25 and a replacement invoice (BT-3 = 384) in the same slot, where BR-FR-CO-04 makes
		// it mandatory with a "fatal" flag: a replacement sent without it is refused by the access
		// point. A specimen of that type has to carry it too, or it shows the one shape the norm does
		// not accept.
		if (in_array($tmpinvoice->type, array(Facture::TYPE_CREDIT_NOTE, Facture::TYPE_REPLACEMENT))) {
			$tmpinvoice->fk_facture_source = $options['referencedinvoice'] ?? 'FA0000-SPECIMEN';
		}

		// A situation invoice bills a share of the work done, and every amount of the line follows that
		// share: the line carries it and the totals are computed with it. The specimen is the first
		// situation of its cycle, the one shape that needs no predecessor to exist - BT-25/26, the
		// reference to the situation before, only appears from the second one on and would mean
		// reading an invoice out of a database.
		$situationPercent = 0;
		if ($tmpinvoice->type == Facture::TYPE_SITUATION) {
			$tmpinvoice->situation_counter = 1;
			$tmpinvoice->situation_cycle_ref = 1;
			$tmpinvoice->situation_final = 0;
			$situationPercent = 50;
		}

		$line = new FactureLigne($this->db);
		$line->desc = $langs->trans("Description") . " 1";
		$line->qty = 5;
		$line->subprice = 100.05;		// unit price (no discount yet)
		// get_default_tva() requires Societe objects (strictly typed in core, no null allowed on PHP 8+).
		// For the specimen, fall back to our own company ($mysoc) when no third party is provided.
		$sampleSeller = ($thirdpartySeller instanceof Societe) ? $thirdpartySeller : $mysoc;
		$sampleBuyer = ($thirdpartyBuyer instanceof Societe) ? $thirdpartyBuyer : $mysoc;
		$line->tva_tx = get_default_tva($sampleSeller, $sampleBuyer);
		$line->localtax1_tx = 0;
		$line->localtax2_tx = 0;
		$line->remise_percent = 10;
		$line->fk_product = 0;

		include_once DOL_DOCUMENT_ROOT.'/core/lib/price.lib.php';
		// Pin the discount rounding so the specimen reads the same everywhere: no two supported cores
		// agree on MAIN_APPLY_DISCOUNT_ON_UNIT_PRICE... (18 and 20 do not implement it, 23 rounds the
		// unit price up, 24 rounds it down). Restored right after: this is a specimen.
		$savRoundDiscountOnUnitPrice = getDolGlobalString('MAIN_APPLY_DISCOUNT_ON_UNIT_PRICE_THEN_ROUND_BEFORE_MULTIPLICATION_BY_QTY');
		$conf->global->MAIN_APPLY_DISCOUNT_ON_UNIT_PRICE_THEN_ROUND_BEFORE_MULTIPLICATION_BY_QTY = '0';

		// The progress is passed to the very function the invoice would have used, so the totals of the
		// specimen are the totals of its lines. Left at 100 - the default - for every other type, which
		// is what the call meant before and what keeps the other specimens unchanged.
		if ($situationPercent) {
			$line->situation_percent = $situationPercent;
		}
		$tmp = calcul_price_total($line->qty, $line->subprice, $line->remise_percent, $line->tva_tx, 0, 0, 0, 'HT', 0, 0, null, array(), $situationPercent ?: 100);

		$conf->global->MAIN_APPLY_DISCOUNT_ON_UNIT_PRICE_THEN_ROUND_BEFORE_MULTIPLICATION_BY_QTY = $savRoundDiscountOnUnitPrice;

		$line->total_ht = (float) $tmp[0];
		$line->total_ttc = (float) $tmp[2];
		$line->total_tva = (float) $tmp[1];
		$line->multicurrency_tx = 2;
		$line->multicurrency_total_ht = 2 * $line->total_ht;
		$line->multicurrency_total_ttc = 2 * $line->total_ttc;
		$line->multicurrency_total_tva = 2 * $line->total_tva;

		$tmpinvoice->lines[] = $line;

		// TODO Add a second line (deposit) to illustrate the final invoice after deposit scenario.

		$tmpinvoice->total_ht       += $line->total_ht;
		$tmpinvoice->total_tva      += $line->total_tva;
		$tmpinvoice->total_ttc      += $line->total_ttc;

		$tmpinvoice->multicurrency_total_ht       += $line->multicurrency_total_ht;
		$tmpinvoice->multicurrency_total_tva      += $line->multicurrency_total_tva;
		$tmpinvoice->multicurrency_total_ttc      += $line->multicurrency_total_ttc;


		require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';


		// Set $mysoc if seller is not myself (when we want to generate a sample invoice for a purchase).
		$keyforconst = 'EINVOICING_' . getDolGlobalString('EINVOICING_PDP') . '_ROUTING_ID';
		$savmysoc = null;
		$savEINVOICING_ROUTING_ID = null;
		if ($thirdpartySeller instanceof Societe) {
			$savmysoc = $mysoc;
			$savEINVOICING_ROUTING_ID = getDolGlobalString($keyforconst);

			$mysoc = $thirdpartySeller;
			$conf->global->EINVOICING_SUPERPDP_ROUTING_ID = idprof($thirdpartySeller);
		} else {
			$thirdpartySeller = $mysoc;
		}
		//var_dump(($savmysoc ? $savmysoc->name : ''), $mysoc->name, $thirdpartyBuyer->name);


		if ($thirdpartyBuyer instanceof Societe) {
			$tmpthirdparty = $thirdpartyBuyer;
		} else {
			$tmpthirdparty = new Societe($this->db);
			$tmpthirdparty->initAsSpecimen();
			if ($thirdpartySeller->idprof1 == "000000001") {
				// Example Burger Queen on SuperPDP Network
				$tmpthirdparty->idprof1 = '000000002';
				$tmpthirdparty->idprof2 = '00000000200010';
				$tmpthirdparty->tva_intra = 'FR12000000002';
				define('EINVOICING_FORCE_BUYER_EID', getDolGlobalString('EINVOICING_DEMO_ROUTING_BURGER_QUEEN', '315143296_1940')); // vary into demo accounts
			} else {
				// Example Tricatel on SuperPDP Network
				$tmpthirdparty->idprof1 = '000000001';
				$tmpthirdparty->idprof2 = '00000000100010';
				$tmpthirdparty->tva_intra = 'FR12000000001';
				define('EINVOICING_FORCE_BUYER_EID', getDolGlobalString('EINVOICING_DEMO_ROUTING_TRICATEL', '315143296_1939'));
			}
		}
		$tmpinvoice->thirdparty = $tmpthirdparty;
		$tmpinvoice->socid = $tmpthirdparty->id;			// 0 for specimen

		require_once DOL_DOCUMENT_ROOT . '/contact/class/contact.class.php';
		$tmpcontact = new Contact($this->db);
		$tmpcontact->initAsSpecimen();
		$tmpcontact->socid = $tmpthirdparty->id;			// 0 for specimen
		$tmpinvoice->contact = $tmpcontact;


		// Generate the Dolibarr PDF of the invoice.
		// The PDF models reach ExtraFields through CommonDocGenerator::getExtrafieldsInHtml(), and the
		// core only autoloads that class on the paths that go through a real invoice card. Reached
		// from a CLI script or a test that only included master.inc.php, the call fatals with
		// 'Class "ExtraFields" not found', so require it explicitly here.
		require_once DOL_DOCUMENT_ROOT . '/core/class/extrafields.class.php';
		// Note: the carrier of the specimen is the one the setup of the instance produces, untouched.
		// A Factur-X specimen is only a conformant PDF/A-3 when PDF_USE_A is set to PDF/A-3b in
		// "Home - Setup - PDF", which is exactly what the specimen is there to show.
		$tmpinvoice->generateDocument((string) $tmpinvoice->model_pdf, $outputlangs);

		// For invoice with ->specimen=1, the file is SPECIMEN.pdf so we rename it into ref
		$dir = $conf->invoice->multidir_output[$conf->entity];
		$srcfile = $dir . '/SPECIMEN.pdf';
		$destfile = $dir . '/' . dol_sanitizeFileName($tmpinvoice->ref) . '.pdf';

		dol_move($srcfile, $destfile, '0', 1);


		// Generate the EInvoice file
		$pathOfEInvoice = $this->generateInvoice($tmpinvoice, $outputlangs);

		// Restore switched variables if we changed $mysoc for generation of the sample invoice
		if (!empty($savmysoc)) {
			$mysoc = $savmysoc;
			$conf->global->$keyforconst = $savEINVOICING_ROUTING_ID;

			$savmysoc = null;
			$savEINVOICING_ROUTING_ID = null;
		}

		// Restore name SPECIMEN.pdf
		dol_move($destfile, $srcfile, '0', 1);

		// Move EInvoice file into the temp directory
		if (is_numeric($pathOfEInvoice) && $pathOfEInvoice < 0) {
			$result = $pathOfEInvoice;
		} else {
			$newPathOfEInvoice = $dir . '/temp/' . basename($pathOfEInvoice);
			dol_move($pathOfEInvoice, $newPathOfEInvoice, '0', 1);

			$result = array('path' => $newPathOfEInvoice, 'ref' => $tmpinvoice->ref);
		}

		return $result;
	}


	/**
	 * Synchronize or create a Dolibarr thirdparty based on E-invoice seller information.
	 *
	 * @param array     $sellerInfo 	Array containing seller information extracted from E-invoice
	 * @param string    $priority 		Fill priority ('dolibarr' or 'pdp'). If both data are available, which one to prefer
	 * @param string    $flowId 		Flow identifier source of the thirdparty.
	 * @return array{res:int, message:string, actioncode?:string, actionurl?:string, action?:string, actiondata?:array<string,mixed>}   Returns array with 'res' (ID of the synchronized or created/updated thirdparty, -1 on error) with a 'message' and an optional 'actioncode', 'actionurl', 'action', and 'actiondata'.
	 */
	private function _syncOrCreateThirdpartyFromEInvoiceSeller($sellerInfo, $priority = 'dolibarr', $flowId = '')
	{
		// EN 16931 bounds none of these texts, llx_societe does: a longer one was refused and stopped the import.
		foreach (array('sellername' => 128, 'sellercity' => 50) as $key => $max) {
			if (isset($sellerInfo[$key])) {
				$sellerInfo[$key] = dol_substr((string) $sellerInfo[$key], 0, $max);
			}
		}
		/**
		 * Scenario to find or create a thirdparty based on E-invoice seller information:
		 *
		 * 1. Try to find thirdparty by global IDs (SIREN, SIRET ...)
		 * 1.1 If found, update thirdparty information with provided data
		 *
		 * 2. If not found, try to find thirdparty by VAT number
		 * 2.1 If found one match, update thirdparty information with provided data
		 * 2.2 If found multiple matches, log warning and return error
		 *
		 * 3. If still not found, and ONLY if the hidden option EINVOICING_THIRDPARTIES_MATCH_ON_NAME
		 *    is set, try the closest match on the descriptive fields (findNearest)
		 *
		 * 4. If still not found, create new thirdparty with provided data - or refuse the document
		 *    when the automatic creation of thirdparties is disabled
		 *
		 * A received document is attached by structured legal identifier only: name, alias, ref_ext and
		 * email are descriptive fields several companies can carry (issue #739).
		 */
		global $db, $langs, $user, $conf;
		require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
		require_once DOL_DOCUMENT_ROOT . '/core/lib/company.lib.php'; // needed for getCountry() when running in cron context

		$thirdparty = new Societe($db);
		$einvoicing = new EInvoicing($db);
		$thirdpartyId = -1;
		// True when the third party was resolved through a structured identifier (SIREN/SIRET/routing/VAT)
		// and not through a fuzzy name match (step 3, off unless the hidden option is set). Used to raise
		// a non-blocking name-mismatch warning only when identification did not rely on the (descriptive)
		// name itself. See issue #309.
		$matchedByStructuredIdentifier = false;

		$sellerCountryCode = $sellerInfo['sellercountry'] ?? '';

		// The legal id (e.g. SIREN) is often carried only in the SpecifiedLegalOrganization
		// (sellerLegalOrgId/Scheme) and left out of sellerGlobalIds. Merge it in so the lookup,
		// update and creation steps below all populate the matching idprof field (e.g. idprof1).
		if (!empty($sellerInfo['sellerLegalOrgId']) && !empty($sellerInfo['sellerLegalOrgScheme'])) {
			if (empty($sellerInfo['sellerGlobalIds']) || !is_array($sellerInfo['sellerGlobalIds'])) {
				$sellerInfo['sellerGlobalIds'] = array();
			}
			if (empty($sellerInfo['sellerGlobalIds'][$sellerInfo['sellerLegalOrgScheme']])) {
				$sellerInfo['sellerGlobalIds'][$sellerInfo['sellerLegalOrgScheme']] = $sellerInfo['sellerLegalOrgId'];
			}
		}

		// Step 1: Try to find thirdparty by global IDs
		if (!empty($sellerInfo['sellerGlobalIds']) && is_array($sellerInfo['sellerGlobalIds'])) {
			foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
				if (!empty($globalId)) {
					// Map scheme to idprof field (0002 = SIREN)
					// TODO Use function idprof() ?
					$idprofField = $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId);
					if (!empty($idprofField)) {
						$result = 0;
						// Fetch thirdparty by corresponding idprof field
						if ($idprofField === 'idprof1') { // SIREN
							$result = $thirdparty->fetch(0, '', '', '', $globalId);
						}
						if ($idprofField === 'idprof2') { // SIRET
							$result = $thirdparty->fetch(0, '', '', '', '', $globalId);
						}
						if ($idprofField === 'idprof3') {
							$result = $thirdparty->fetch(0, '', '', '', '', '', $globalId);
						}
						if ($idprofField === 'idprof4') {
							$result = $thirdparty->fetch(0, '', '', '', '', '', '', $globalId);
						}
						if ($idprofField === 'idprof5') {
							$result = $thirdparty->fetch(0, '', '', '', '', '', '', '', $globalId);
						}
						if ($idprofField === 'idprof6') {
							$result = $thirdparty->fetch(0, '', '', '', '', '', '', '', '', $globalId);
						}

						if ($result > 0) {
							$thirdpartyId = $thirdparty->id;
							$matchedByStructuredIdentifier = true;
							dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Found thirdparty by ' . $idScheme . ': ' . $thirdpartyId);
							break;
						}
					}
				}
			}
		}
		// Step 2: Try to find using VAT number if not found by global IDs
		if ($thirdpartyId < 0) {
			if (!empty($sellerInfo['sellerTaxRegistations']['VA'])) {
				$sql = "SELECT rowid, siret FROM " . MAIN_DB_PREFIX . "societe WHERE REPLACE(tva_intra, ' ', '') = '" . $db->escape(removeAllSpaces($sellerInfo['sellerTaxRegistations']['VA'])) . "' AND entity IN (". getEntity('societe').")";
				$resql = $db->query($sql);
				if ($resql) {
					if ($db->num_rows($resql) > 1) {
						// Several thirdparties can legitimately share one VAT number: in France it is
						// derived from the SIREN alone (FR + 2 check digits + SIREN), so different
						// établissements (same SIREN, different SIRET) of one legal entity collide here.
						// Try the SIRET carried by the document to pick the right établissement before
						// treating this as an unresolved data-quality duplicate.
						$candidates = array();
						while ($obj = $db->fetch_object($resql)) {
							$candidates[] = $obj;
						}

						$sellerSiret = $this->_extractSellerSiret($sellerInfo, $sellerCountryCode);
						$matchedCandidate = null;
						$severalCandidatesMatchSiret = false;
						if ($sellerSiret !== '') {
							foreach ($candidates as $candidate) {
								if (!empty($candidate->siret) && removeAllSpaces($candidate->siret) === $sellerSiret) {
									if ($matchedCandidate !== null) {
										$severalCandidatesMatchSiret = true;
										break;
									}
									$matchedCandidate = $candidate;
								}
							}
						}

						if ($matchedCandidate !== null && !$severalCandidatesMatchSiret) {
							$result = $thirdparty->fetch($matchedCandidate->rowid);
							if ($result > 0) {
								$thirdpartyId = $thirdparty->id;
								$matchedByStructuredIdentifier = true;
								dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller VAT number ' . $sellerInfo['sellerTaxRegistations']['VA'] . ' shared by ' . count($candidates) . ' thirdparties, disambiguated by SIRET ' . $sellerSiret . ': ' . $thirdpartyId);
							}
						} elseif ($sellerSiret !== '' && !$severalCandidatesMatchSiret) {
							// The document's SIRET matches none of the établissements sharing this VAT
							// number: most likely a new établissement of the same entity. Do not block
							// the import on it, let step 3/4 below handle it (name match or creation).
							dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller VAT number ' . $sellerInfo['sellerTaxRegistations']['VA'] . ' shared by ' . count($candidates) . ' thirdparties, none matches document SIRET ' . $sellerSiret . '; not treated as a blocking duplicate', LOG_WARNING);
						} else {
							// No SIRET on the document to disambiguate with, or several candidates share
							// the same SIRET: genuine ambiguity, cannot safely resolve it.
							dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Error: Multiple thirdparties found for VAT number: ' . $sellerInfo['sellerTaxRegistations']['VA'], LOG_ERR);

							$obj1 = $candidates[0];
							$obj2 = $candidates[1];

							// Create URL to prefill thirdparty creation form
							$createUrl = DOL_URL_ROOT . '/societe/list.php?type=f&search_vat='.urlencode($sellerInfo['sellerTaxRegistations']['VA']);
							$createUrl .= '&backtopage=' . urlencode(dol_buildpath('/einvoicing/document_list.php', 1));

							$action = $langs->trans('CheckSuppliersWithDuplicateCode', $sellerInfo['sellerTaxRegistations']['VA']);
							$action .= '<a class="butAction small smallpaddingimp" href="' . dol_escape_htmltag($createUrl) . '" target="_blank">';
							$action .= '<i class="fas fa-plus-circle"></i> ';
							$action .= $langs->trans('CheckSuppliers');
							$action .= '</a>';

							return array(
								'res' => -1,
								'message' => $langs->trans("SuppliersWithDuplicateVATCode", $sellerInfo['sellerTaxRegistations']['VA']),	// Can be a technical message. The business one is defined into the syncFlows() of the provider.
								'actioncode' => 'THIRDPARTY_DUPLICATE_VAT',
								'action' => $action,
								'actiondata' => array('thirdpartyid1' => $obj1->rowid, 'thirdpartyid2' => $obj2->rowid, 'vatnumber' => $sellerInfo['sellerTaxRegistations']['VA'])
							);
						}
					} elseif ($db->num_rows($resql) === 1) {
						$obj = $db->fetch_object($resql);
						$result = $thirdparty->fetch($obj->rowid);
						if ($result > 0) {
							$thirdpartyId = $thirdparty->id;
							$matchedByStructuredIdentifier = true;
							dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Found thirdparty by VAT number: ' . $thirdpartyId);
						}
					}
				}
			}
		}

		// Step 3: If not found, try to find by findNearest function. A name is not an identity: BT-27 and
		// BT-28 are descriptive, and the last stage of findNearest() ORs name and commercial alias, so a
		// thirdparty merely carrying the seller name collects the invoice (issue #739). OFF by default,
		// behind the hidden option EINVOICING_THIRDPARTIES_MATCH_ON_NAME (no setup page entry on purpose).
		if ($thirdpartyId < 0 && getDolGlobalString('EINVOICING_THIRDPARTIES_MATCH_ON_NAME')) {
			// An email address is not an identity either: it can be shared by several third parties, and
			// a third party that merely carries the sender's address is not necessarily the sender. It is
			// added to the criteria below only when the (equally hidden) option
			// EINVOICING_THIRDPARTIES_MATCH_ON_EMAIL is set too, as it was before issue #739.
			$emailForLooseMatch = '';
			if (getDolGlobalString('EINVOICING_THIRDPARTIES_MATCH_ON_EMAIL')) {
				$emailForLooseMatch = $sellerInfo['sellercontactemailaddr'] ?? '';
			} elseif (!empty($sellerInfo['sellercontactemailaddr'])) {
				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Email of the seller is not used as a match criterion (option EINVOICING_THIRDPARTIES_MATCH_ON_EMAIL is off)');
			}

			if (method_exists($thirdparty, 'findNearest')) {
				$result = $thirdparty->findNearest(
					0,
					$sellerInfo['sellername'] ?? '',
					// The name is not passed as ref_ext any more: ref_ext is a free field, absent from the
					// third party card and usually written by whatever import created the record, so a third
					// party whose ref_ext happens to equal the seller name makes no claim to BE that seller.
					// The last stage of findNearest() ORs name, alias and ref_ext, so that one coincidence
					// was enough to attach the received invoice to it (issue #739).
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					$emailForLooseMatch,
					$sellerInfo['sellername'] ?? ''
				); // TODO: we can add phone, address and vat number to improve matching
			} else {	// Compat method for old versions
				$result = findNearest(
					0,
					$sellerInfo['sellername'] ?? '',
					// The name is not passed as ref_ext any more: ref_ext is a free field, absent from the
					// third party card and usually written by whatever import created the record, so a third
					// party whose ref_ext happens to equal the seller name makes no claim to BE that seller.
					// The last stage of findNearest() ORs name, alias and ref_ext, so that one coincidence
					// was enough to attach the received invoice to it (issue #739).
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					$emailForLooseMatch,
					$sellerInfo['sellername'] ?? ''
				);
			}

			if ($result > 0) {
				// findNearest() RETURNS the rowid (it does not populate $thirdparty->id).
				$thirdpartyId = $result;
				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Found thirdparty by findNearest: ' . $thirdpartyId);
			}
		} elseif ($thirdpartyId < 0) {
			dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Seller not found by its legal identifiers, and the name is not used as a match criterion (hidden option EINVOICING_THIRDPARTIES_MATCH_ON_NAME is off)');
		}

		// Identifier-based match: raise a NON-BLOCKING warning when the name carried by the e-invoice
		// does not match the linked third party. A supplier is identified by its structured identifier,
		// never by name (BT-27 and BT-28 are descriptive), so a mismatch only signals data quality (#309).
		$nameMismatchWarning = '';
		if ($thirdpartyId > 0 && $matchedByStructuredIdentifier) {
			$invoiceNames = array($sellerInfo['sellername'] ?? '', $sellerInfo['sellerTradingName'] ?? '');
			$dolibarrNames = array($thirdparty->name, $thirdparty->name_alias);
			if (!$this->_companyNamesAreConsistent($invoiceNames, $dolibarrNames)) {
				$invoiceName = trim($sellerInfo['sellername'] ?? '');
				if ($invoiceName === '') {
					$invoiceName = trim($sellerInfo['sellerTradingName'] ?? '');
				}
				$nameMismatchWarning = $langs->trans('EInvoiceSupplierNameMismatchWarning', $invoiceName, '{s1}');
				$nameMismatchWarning = str_replace('{s1}', $thirdparty->getNomUrl(0, '', 0, 1), $nameMismatchWarning);

				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller ' . $nameMismatchWarning, LOG_WARNING);
				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller ' . $nameMismatchWarning, LOG_WARNING, 0, '_einvoicing');

				setEventMessages($nameMismatchWarning, null, 'warnings', '', 1);
			}
		}

		// A phone number written in a document is free text (BT-42 is a Text, and so is the fax of the
		// EXTENDED profile), and vendors do write things like "09 77 40 50 60 (service gratuit + prix
		// appel)" in it. Keep the number and leave the sentence out, so the column can hold it. See #943.
		$sellerPhone = $this->_extractPhoneNumberFromDocument($sellerInfo['sellercontactphoneno'] ?? '');
		$sellerFax = $this->_extractPhoneNumberFromDocument($sellerInfo['sellercontactfaxno'] ?? '');
		// A number cut short is a wrong number: one longer than the column (20 up to Dolibarr 21) once the
		// core has removed its spaces and dots is not saved.
		$phoneMax = (int) DOL_VERSION >= 22 ? 30 : 20;
		$sellerPhone = dol_strlen(preg_replace('/[\s.]/', '', $sellerPhone)) > $phoneMax ? '' : $sellerPhone;
		$sellerFax = dol_strlen(preg_replace('/[\s.]/', '', $sellerFax)) > $phoneMax ? '' : $sellerFax;

		// Step 4: Create or update thirdparty

		//$thirdpartyId = -2; // For testing
		if ($thirdpartyId > 0) {
			dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Updating existing thirdparty (client status'.(getDolGlobalString('EINVOICING_THIRDPARTIES_COMPLETE_INFO') ? ' + other info' : '').'): ' . $thirdpartyId);

			$thirdparty = new Societe($db);
			$this->_fetchThirdpartyForImportUpdate($thirdparty, $thirdpartyId);

			// Update thirdparty information based on priority
			if (getDolGlobalInt('EINVOICING_THIRDPARTIES_COMPLETE_INFO')) {
				if ($priority === 'pdp') { // Overwrite Dolibarr data with AP data
					$thirdparty->name = $sellerInfo['sellername'] ?? $thirdparty->name;
					$thirdparty->address = $sellerInfo['sellerlineone'] ?? $thirdparty->address;
					if (!empty($sellerInfo['sellerlinetwo'])) {
						$thirdparty->address .= "\n" . $sellerInfo['sellerlinetwo'];
					}
					if (!empty($sellerInfo['sellerlinethree'])) {
						$thirdparty->address .= "\n" . $sellerInfo['sellerlinethree'];
					}
					$thirdparty->zip = $sellerInfo['sellerpostcode'] ?? $thirdparty->zip;
					$thirdparty->town = $sellerInfo['sellercity'] ?? $thirdparty->town;
					$this->_setThirdpartyCountryFromCode($thirdparty, $sellerInfo['sellercountry'] ?? '');
					$thirdparty->email = $sellerInfo['sellercontactemailaddr'] ?? $thirdparty->email;
					if ($sellerPhone !== '') {
						$thirdparty->phone = $sellerPhone;
					}
					if ($sellerFax !== '') {
						$thirdparty->fax = $sellerFax;
					}
					// Set identification numbers
					if (!empty($sellerInfo['sellerGlobalIds']) && is_array($sellerInfo['sellerGlobalIds'])) {
						foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
							if (!empty($globalId)) {
								$idprofField = $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId);
								if (!empty($idprofField)) {
									$thirdparty->$idprofField = removeAllSpaces($globalId);
								}
							}
						}
					}
					if (!empty($sellerInfo['sellerTaxRegistations']['VA'])) {
						$thirdparty->tva_intra = removeAllSpaces($sellerInfo['sellerTaxRegistations']['VA']);
						$thirdparty->tva_assuj = 1;
					}
				} elseif ($priority === 'dolibarr') { // Fill only empty fields from pdp data
					dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Keeping existing thirdparty data and fill only empty fields as priority is dolibarr: ' . $thirdpartyId);

					if (empty($thirdparty->name) && !empty($sellerInfo['sellername'])) {
						$thirdparty->name = $sellerInfo['sellername'];
					}
					if (empty($thirdparty->address) && !empty($sellerInfo['sellerlineone'])) {
						$thirdparty->address = $sellerInfo['sellerlineone'];
						if (!empty($sellerInfo['sellerlinetwo'])) {
							$thirdparty->address .= "\n" . $sellerInfo['sellerlinetwo'];
						}
						if (!empty($sellerInfo['sellerlinethree'])) {
							$thirdparty->address .= "\n" . $sellerInfo['sellerlinethree'];
						}
						$thirdparty->address = dol_substr($thirdparty->address, 0, 255);
					}
					if (empty($thirdparty->zip) && !empty($sellerInfo['sellerpostcode'])) {
						$thirdparty->zip = $sellerInfo['sellerpostcode'];
					}
					if (empty($thirdparty->town) && !empty($sellerInfo['sellercity'])) {
						$thirdparty->town = $sellerInfo['sellercity'];
					}
					if (empty($thirdparty->country_id) && !empty($sellerInfo['sellercountry'])) {
						$this->_setThirdpartyCountryFromCode($thirdparty, $sellerInfo['sellercountry']);
					}
					if (empty($thirdparty->email) && !empty($sellerInfo['sellercontactemailaddr'])) {
						$thirdparty->email = $sellerInfo['sellercontactemailaddr'];
					}
					if (empty($thirdparty->phone) && $sellerPhone !== '') {
						$thirdparty->phone = $sellerPhone;
					}
					if (empty($thirdparty->fax) && $sellerFax !== '') {
						$thirdparty->fax = $sellerFax;
					}
					// Set identification numbers if empty
					if (!empty($sellerInfo['sellerGlobalIds']) && is_array($sellerInfo['sellerGlobalIds'])) {
						foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
							if (!empty($globalId)) {
								$idprofField = $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId);
								if (!empty($idprofField) && empty($thirdparty->$idprofField)) {
									$thirdparty->$idprofField = removeAllSpaces($globalId);
								}
							}
						}
					}
					if (!empty($sellerInfo['sellerTaxRegistations']['VA']) && empty($thirdparty->tva_intra)) {
						$thirdparty->tva_intra = removeAllSpaces($sellerInfo['sellerTaxRegistations']['VA']);
						$thirdparty->tva_assuj = 1;
					}
				}
			}
			$allowmodcodeclient = 0;
			$allowmodcodefournisseur = 0;
			$tosave = $this->_prepareThirdpartyForImportUpdate($thirdparty, $allowmodcodeclient, $allowmodcodefournisseur);
			// The vendor is identified and the import has nothing to write on it: saving it anyway would only
			// let a setup rule it does not meet (mandatory professional id, code mask...) refuse the document.
			if (!$tosave && !getDolGlobalInt('EINVOICING_THIRDPARTIES_COMPLETE_INFO')) {
				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Nothing to update on thirdparty: ' . $thirdpartyId);
				return array(
					'res' => $thirdpartyId,
					'message' => 'Thirdparty ' . $thirdparty->name . ' found, nothing to update.' . ($nameMismatchWarning !== '' ? ' - ' . $nameMismatchWarning : '')
				);
			}

			$result = $thirdparty->update(0, $user, 1, $allowmodcodeclient, $allowmodcodefournisseur);

			// update() answers -3 to every refusal of verify() (code out of the numbering mask, mandatory or
			// duplicate professional id...): only the error it recorded tells a supplier code used twice.
			$duplicateSupplierCode = ($result == -3 && in_array('ErrorSupplierCodeAlreadyUsed', $thirdparty->errors));

			// Copying into the thirdparty what the document says is a convenience (option
			// EINVOICING_THIRDPARTIES_COMPLETE_INFO), and the vendor is already identified at this point:
			// a value it refuses - a phone number carrying a sentence, a name longer than the column, a
			// trigger of another module - must not cost the invoice. Save the thirdparty again without
			// that completion: the document is then imported, and the caller is told what was left out.
			// The duplicate supplier code is not about the completion and keeps its own answer below.
			$completionWarning = '';
			if ($result < 0 && !$duplicateSupplierCode && getDolGlobalInt('EINVOICING_THIRDPARTIES_COMPLETE_INFO')) {
				$completionError = implode(', ', array_filter(array_merge(array($thirdparty->error), $thirdparty->errors)));

				$plainthirdparty = new Societe($db);
				if ($this->_fetchThirdpartyForImportUpdate($plainthirdparty, $thirdpartyId) > 0) {
					$allowmodcodeclient = 0;
					$allowmodcodefournisseur = 0;
					$this->_prepareThirdpartyForImportUpdate($plainthirdparty, $allowmodcodeclient, $allowmodcodefournisseur);

					$resultwithoutcompletion = $plainthirdparty->update(0, $user, 1, $allowmodcodeclient, $allowmodcodefournisseur);
					if ($resultwithoutcompletion > 0) {
						$thirdparty = $plainthirdparty;
						$result = $resultwithoutcompletion;

						$completionWarning = $langs->trans('EInvoiceThirdpartyNotCompletedWarning', '{s1}', $completionError);
						$completionWarning = str_replace('{s1}', $thirdparty->getNomUrl(0, '', 0, 1), $completionWarning);

						dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Thirdparty ' . $thirdpartyId . ' kept as it is, its completion from the document was refused: ' . $completionError, LOG_WARNING);
						dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller ' . $completionWarning, LOG_WARNING, 0, '_einvoicing');

						setEventMessages($completionWarning, null, 'warnings', '', 1);
					}
				}
			}

			if ($result < 0) {
				$this->error = $thirdparty->error;
				$this->errors = $thirdparty->errors;

				if ($duplicateSupplierCode) {
					// Case of duplicate supplier code, need to change one.
					dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Error updating thirdparty: There is 2+ suppliers with the same supplier code. You msut fix one', LOG_DEBUG);

					// Create URL to prefill thirdparty creation form
					$createUrl = DOL_URL_ROOT . '/societe/list.php?type=f&search_supplier_code='.urlencode($thirdparty->code_fournisseur);
					$createUrl .= '&backtopage=' . urlencode(dol_buildpath('/einvoicing/document_list.php', 1));

					$action = $langs->trans('CheckSuppliersWithDuplicateCode', $thirdparty->code_fournisseur);
					$action .= '<a class="butAction small smallpaddingimp" href="' . dol_escape_htmltag($createUrl) . '" target="_blank">';
					$action .= '<i class="fas fa-plus-circle"></i> ';
					$action .= $langs->trans('CheckSuppliers');
					$action .= '</a>';

					return array(
						'res' => -1,
						'message' => $langs->trans("SuppliersWithDuplicateCode", $thirdparty->code_fournisseur),	// Can be a technical message. The business one is defined into the syncFlows() of the provider.
						'actioncode' => 'THIRDPARTY_DUPLICATE_SUPPLIER_CODE',
						'actionurl' => $createUrl,
						'action' => $action,
						'actiondata' => array('suppliercode' => $thirdparty->code_fournisseur)
					);
				} else {
					// Name the thirdparty: the user has to open it to fix what the core refuses.
					$updateError = implode(', ', array_unique(array_filter(array_merge(array($thirdparty->error), $thirdparty->errors))));
					dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Error updating thirdparty ' . $thirdpartyId . ': ' . $updateError, LOG_ERR);
					return array(
						'res' => -1,
						'message' => 'Thirdparty update error on ' . dol_escape_htmltag($thirdparty->name) . ' (id ' . ((int) $thirdpartyId) . '): ' . dol_escape_htmltag($updateError) . '.'
					);
				}
			} else {
				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Updated thirdparty: ' . $thirdpartyId);
				return array(
					'res' => $thirdpartyId,
					'message' => 'Thirdparty ' . $thirdparty->name . ' updated successfully.' . ($nameMismatchWarning !== '' ? ' - ' . $nameMismatchWarning : '') . ($completionWarning !== '' ? ' - ' . $completionWarning : '')
				);
			}
		}

		// if not found, create new thirdparty
		if ($thirdpartyId < 0 && getDolGlobalInt('EINVOICING_THIRDPARTIES_AUTO_GENERATION')) {
			dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Creating new thirdparty: ' . $sellerInfo['sellername']);

			$thirdparty = new Societe($db);

			$thirdparty->name = $sellerInfo['sellername'] ?? 'Unknown Supplier name';
			$thirdparty->address = $sellerInfo['sellerlineone'] ?? '';
			if (!empty($sellerInfo['sellerlinetwo'])) {
				$thirdparty->address .= "\n" . $sellerInfo['sellerlinetwo'];
			}
			if (!empty($sellerInfo['sellerlinethree'])) {
				$thirdparty->address .= "\n" . $sellerInfo['sellerlinethree'];
			}
			$thirdparty->address = dol_substr($thirdparty->address, 0, 255);
			$thirdparty->zip = $sellerInfo['sellerpostcode'] ?? '';
			$thirdparty->town = $sellerInfo['sellercity'] ?? '';
			$this->_setThirdpartyCountryFromCode($thirdparty, $sellerInfo['sellercountry'] ?? '');
			$thirdparty->email = $sellerInfo['sellercontactemailaddr'] ?? '';
			$thirdparty->phone = $sellerPhone;
			$thirdparty->fax = $sellerFax;

			// Set identification numbers
			if (!empty($sellerInfo['sellerGlobalIds']) && is_array($sellerInfo['sellerGlobalIds'])) {
				foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
					if (!empty($globalId)) {
						$idprofField = $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId);
						if (!empty($idprofField)) {
							$thirdparty->$idprofField = removeAllSpaces($globalId);
						}
					}
				}
			}

			if (!empty($sellerInfo['sellerTaxRegistations']['VA'])) {
				$thirdparty->tva_intra = removeAllSpaces($sellerInfo['sellerTaxRegistations']['VA']);
				$thirdparty->tva_assuj = 1;
			}

			// Set as supplier
			$thirdparty->fournisseur = 1;
			$thirdparty->code_fournisseur = 'auto';

			$result = $thirdparty->create($user);
			if ($result > 0) {
				$thirdpartyId = $thirdparty->id;

				// Add entry in einvoicing_extlinks table to mark that this thirdparty is imported from PDP
				$einvoicing->insertOrUpdateExtLink($thirdpartyId, $thirdparty->element, $flowId);

				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Created new thirdparty: ' . $thirdpartyId);
				return array('res' => $thirdpartyId, 'message' => 'Thirdparty ' . $thirdparty->name . ' created successfully');
			} else {
				dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Error creating thirdparty: ' . $thirdparty->error, LOG_ERR);
				return array('res' => -1, 'message' => 'Thirdparty creation error: ' . dol_escape_htmltag(implode("\n", $thirdparty->errors)));
			}
		} else {
			dol_syslog(get_class($this) . '::_syncOrCreateThirdpartyFromEInvoiceSeller Auto-creation of thirdparties is disabled', LOG_ERR);

			$sellername = trim($sellerInfo['sellername'] ?? '');
			$selleremail = trim($sellerInfo['sellercontactemailaddr'] ?? '');
			$sellervat = trim($sellerInfo['sellerTaxRegistations']['VA'] ?? '');
			$sellerzip = trim($sellerInfo['sellerpostcode'] ?? '');
			$sellertown = trim($sellerInfo['sellercity'] ?? '');
			$sellercountrycode = trim($sellerInfo['sellercountry'] ?? '');
			$selleraddress = trim($sellerInfo['sellerlineone'] ?? '');
			if (!empty($sellerInfo['sellerlinetwo'])) {
				$selleraddress .= "\n" . $sellerInfo['sellerlinetwo'];
			}
			if (!empty($sellerInfo['sellerlinethree'])) {
				$selleraddress .= "\n" . $sellerInfo['sellerlinethree'];
			}


			$createParams = [];

			if (!empty($sellername)) {
				$createParams['name'] = $sellername;
			}
			if (!empty($selleremail)) {
				$createParams['email'] = $selleremail;
			}
			if (!empty($sellervat)) {
				$createParams['tva_intra'] = $sellervat;
			}
			if (!empty($sellerInfo['sellerGlobalIds']) && is_array($sellerInfo['sellerGlobalIds'])) {
				foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
					if (!empty($globalId)) {
						$idprofField = $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId);
						if (!empty($idprofField)) {
							$createParams[$idprofField] = $globalId;
						}
					}
				}
			}
			if (!empty($selleraddress)) {
				$createParams['address'] = $selleraddress;
			}
			if (!empty($sellerzip)) {
				$createParams['zipcode'] = $sellerzip;
			}
			if (!empty($sellertown)) {
				$createParams['town'] = $sellertown;
			}
			if (!empty($sellercountrycode)) {
				$countryid = dol_getIdFromCode($this->db, $sellercountrycode, 'c_country', 'code', 'rowid');
				if ($countryid > 0) {
					$createParams['country_id'] = $countryid;
				}
			}


			// Create URL to prefill thirdparty creation form
			$createUrl = DOL_URL_ROOT . '/societe/card.php?action=create&type=f';
			if (!empty($createParams)) {
				// The Dolibarr GET firewall (analyseVarsForSqlAndScriptsInjection) rejects " < > in any URL
				// parameter, so a seller name/address carrying them would 403 before the prefilled creation
				// form even opens. Use the core helper (replaces " with ' and removes < >, identical from
				// v18 to v25) to drop them from the prefill - a convenience the operator reviews and edits.
				foreach ($createParams as $cpKey => $cpVal) {
					if (is_string($cpVal)) {
						$createParams[$cpKey] = dol_string_nospecial($cpVal, "'", array('"'), array('<', '>'));
					}
				}
				$createUrl .= '&' . http_build_query($createParams);
			}
			$createUrl .= '&backtopage=' . urlencode(dol_buildpath('/einvoicing/document_list.php', 1));

			$langs->loadLangs(array("companies", "einvoicing@einvoicing"));

			$errorDetails = [];
			// The caller renders $actiondata as "key: value" pairs, the flat shape the PRODUCT_NOT_FOUND
			// case returns. Building it as a list of one-entry arrays made every value reach the message
			// as the string "Array", and dropped the first pair altogether, its key being the falsy
			// index 0 - so the vendor name never made it there.
			$actiondata = [];
			if (!empty($sellername)) {
				$errorDetails['name'] = $langs->trans("Supplier").': ' . $sellername;
				$actiondata['name'] = $sellername;
			}
			if (!empty($selleremail)) {
				$errorDetails['email'] = $langs->trans("Email").': ' . $selleremail;
				$actiondata['email'] = $selleremail;
			}
			if (!empty($sellervat)) {
				$errorDetails['vatnumber'] = $langs->trans("VATIntra").': ' . $sellervat;
				$actiondata['vatnumber'] = $sellervat;
			}
			if (!empty($sellerInfo['sellerGlobalIds']) && is_array($sellerInfo['sellerGlobalIds'])) {
				foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
					if (!empty($globalId)) {
						$idprofField = $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId);
						if (!empty($idprofField)) {
							$errorDetails[$idprofField] = $langs->trans($idprofField).': ' . $globalId;
							$actiondata[$idprofField] = $globalId;
						}
					}
				}
			}

			$detailsStr = !empty($errorDetails) ? ' [' . implode(' - ', $errorDetails) . ']' : '';

			$message = $langs->trans("FailedToFindSupplier"). ' ' . $detailsStr . ". \n";
			$message .= $langs->trans("AutoCreateThirdPartyOffCreateItManually");

			// Creating the thirdparty needs the right on it. Without that right the button stays where it is,
			// greyed and titled: a button that disappears reads as "create it, but how?", a greyed one names
			// the permission to ask for.
			$action = '<div class="marginbottomonly opacitymedium">'.$langs->trans('CreateSupplierManually');
			$action .= ' '.$langs->trans('OrAssignProfessionalIdToExistingSupplier').'</div>';

			$action .= $user->hasRight('societe', 'creer')
				? '<a class="butAction small smallpaddingimp nomarginleft" href="' . dol_escape_htmltag($createUrl) . '" target="_blank">'
				: '<a class="butActionRefused classfortooltip small smallpaddingimp" href="#" title="' . dol_escape_htmltag($langs->trans("NotEnoughPermissions")) . '">';
			$action .= '<i class="fas fa-plus-circle"></i> ';
			$action .= $langs->trans('CreateSupplier');
			$action .= '</a>';

			// The seller may already exist as a thirdparty under another identity: the professional
			// identifier of the document can be set on it by hand, and the suppliers list is where to look for it.
			$searchUrl = DOL_URL_ROOT . '/societe/list.php?type=f';
			$searchUrl .= '&backtopage=' . urlencode(dol_buildpath('/einvoicing/document_list.php', 1));

			$action .= ' ';

			// Reading the list needs the right on it, and the same reasoning as for the creation
			// button above applies: a greyed button names the permission to ask for.
			$action .= $user->hasRight('societe', 'lire')
				? '<a class="butAction small smallpaddingimp" href="' . dol_escape_htmltag($searchUrl) . '" target="_blank">'
				: '<a class="butActionRefused classfortooltip small smallpaddingimp" href="#" title="' . dol_escape_htmltag($langs->trans("NotEnoughPermissions")) . '">';
			$action .= '<i class="fas fa-search"></i> ';
			$action .= $langs->trans('SearchAmongSuppliers');
			$action .= '</a>';

			return array(
				'res' => -1,
				'message' => $message,
				'actioncode' => 'THIRDPARTY_NOT_FOUND',
				'actionurl' => $createUrl,
				'action' => $action,
				'actiondata' => $actiondata
			);
		}
	}

	/**
	 * Set the country of a thirdparty from the country code carried by a received document.
	 *
	 * The stored country is fk_pays, which the core writes from country_id: up to Dolibarr 19,
	 * Societe::update() never derives it from country_code, so a thirdparty created by the import
	 * silently ended up with no country at all (issue #1037). An unknown code is left out.
	 *
	 * @param	Societe		$thirdparty		Thirdparty to set the country on
	 * @param	string		$countrycode	Country code read in the document (BT-40, BT-55...)
	 * @return	void
	 */
	private function _setThirdpartyCountryFromCode($thirdparty, $countrycode)
	{
		$countrycode = trim((string) $countrycode);
		if ($countrycode === '') {
			return;
		}

		$countryid = dol_getIdFromCode($this->db, $countrycode, 'c_country', 'code', 'rowid');
		if ($countryid > 0) {
			$thirdparty->country_id = $countryid;
			$thirdparty->country_code = $countrycode;
		} else {
			dol_syslog(get_class($this) . '::_setThirdpartyCountryFromCode Unknown country code in document: ' . $countrycode, LOG_WARNING);
		}
	}

	/**
	 * Load a thirdparty found in Dolibarr for the update done when a document is imported.
	 *
	 * @param	Societe	$thirdparty		Thirdparty to load
	 * @param	int		$thirdpartyId	Id of the thirdparty
	 * @return	int						Result of Societe::fetch()
	 */
	private function _fetchThirdpartyForImportUpdate($thirdparty, $thirdpartyId)
	{
		$result = $thirdparty->fetch($thirdpartyId);
		// Societe::update() accepts a code out of the current numbering mask only when oldcopy holds it
		// unchanged. A plain clone: dol_clone() of Dolibarr 24 drops the null properties update() reads.
		$thirdparty->oldcopy = clone $thirdparty;

		return $result;
	}

	/**
	 * Prepare a thirdparty found in Dolibarr for the update done when a document is imported.
	 *
	 * A thirdparty code may be mandatory (MAIN_COMPANY_CODE_ALWAYS_REQUIRED, or a numbering module
	 * refusing an empty code): verify() then refuses every update of a thirdparty saved without one,
	 * and the whole synchronization stops on it. Ask for a generated code when the numbering module
	 * allows it. The allowmod flags are required twice over: update() checks them before writing the
	 * code columns, and it is also how the thirdparty card saves a code.
	 *
	 * @param	Societe	$thirdparty					Thirdparty to save, already loaded
	 * @param	int		$allowmodcodeclient			Set to 1 when a customer code has to be generated
	 * @param	int		$allowmodcodefournisseur	Set to 1 when a vendor code has to be generated
	 * @return	int									1 if there is something to save on the thirdparty, 0 if not
	 */
	private function _prepareThirdpartyForImportUpdate($thirdparty, &$allowmodcodeclient, &$allowmodcodefournisseur)
	{
		$tosave = 0;

		// Flag the thirdparty as a vendor if it is not one yet
		// (ex: a prospect or customer receiving its first supplier invoice).
		if (!$thirdparty->fournisseur) {
			$thirdparty->fournisseur = 1;
			$tosave = 1;
		}

		if (empty($thirdparty->code_fournisseur) && $thirdparty->codefournisseur_modifiable()) {
			$thirdparty->code_fournisseur = 'auto';
			$allowmodcodefournisseur = 1;
			$tosave = 1;
		}
		if (!empty($thirdparty->client) && empty($thirdparty->code_client) && $thirdparty->codeclient_modifiable()) {
			$thirdparty->code_client = 'auto';
			$allowmodcodeclient = 1;
			$tosave = 1;
		}

		// This function never sets an extrafield on a thirdparty, so it must not rewrite them, and it has
		// to say so explicitly: from Dolibarr 20 on, fetch() pre-fills array_options with a null entry for
		// every declared extrafield, and update() hands that array to insertExtraFields(), which refuses
		// the WHOLE update as soon as one of those fields is mandatory and empty. Emptied, array_options
		// makes insertExtraFields() return 0 without touching the stored row.
		$thirdparty->array_options = array();

		return $tosave;
	}

	/**
	 * Extract the phone number out of what a received document carries as a phone or fax number.
	 *
	 * The telephone number of the seller contact (BT-42) is a Text, and so is the fax number the
	 * EXTENDED profile adds next to it (BT-X-107, outside EN 16931): vendors do add a sentence to them
	 * ("09 77 40 50 60 (service gratuit + prix appel)"), which no longer fits the phone column of a
	 * thirdparty. A value that is already made of number characters only is returned untouched,
	 * whatever its local formatting; anything else is reduced to the first group of at least 6 digits
	 * it holds, and an empty string is returned when it holds none.
	 *
	 * @param	string	$value	Phone or fax number as written in the document
	 * @return	string			Phone number to save, or an empty string when there is none to save
	 */
	private function _extractPhoneNumberFromDocument($value)
	{
		$value = trim((string) $value);
		if ($value === '') {
			return '';
		}

		// Already a number: keep what the vendor wrote, separators included.
		if (preg_match('/^[+(]?[0-9][0-9 .\/()+-]*$/', $value)) {
			return $value;
		}

		if (preg_match_all('/[+]?[0-9][0-9 .\/()-]*/', $value, $matches)) {
			foreach ($matches[0] as $candidate) {
				$candidate = trim($candidate, " .-/()");
				if (strlen(preg_replace('/[^0-9]/', '', $candidate)) >= 6) {
					return $candidate;
				}
			}
		}

		return '';
	}

	/**
	 * Search an existing Dolibarr product matching an e-invoice line. Read only: nothing is created.
	 *
	 * Note: this is the matching part (steps 1 to 4 + default routing) of _findOrCreateProductFromEinvoiceLine().
	 * It is public so a manual mapping screen (see einvoicing/product_mapping.php) can show, for each line of a
	 * flow, if the line is already resolved or not, without importing anything.
	 *
	 * @param 	array 	$lineData 	Array containing invoice line data extracted from XML
	 * @return 	array{res:int, message:string, matchtype?:string}   'res' = ID of the product found, 0 if no product found. 'matchtype' tells how it was resolved ('defaultrouting' when the line fell back on the default product of the vendor).
	 */
	public function findProductFromEinvoiceLine($lineData)
	{
		global $db;

		$einvoicing = new EInvoicing($db);

		// Search in product supplier prices table using prodsellerid (the ref of product of the vendor)
		// An absent reference is not a search key: looked up as it stands it matches any vendor price
		// row whose ref_fourn is empty, and binds the line to a product that has nothing to do with it.
		$sellerref = trim((string) ($lineData['prodsellerid'] ?? ''));
		$searchname = trim((string) ($lineData['prodname'] ?? ''));
		if ($sellerref !== '' || $searchname !== '') {
			$sql = "SELECT p.rowid ";
			$sql .= " FROM " . MAIN_DB_PREFIX . "product as p ";
			$sql .= " INNER JOIN " . MAIN_DB_PREFIX . "product_fournisseur_price as pfp ON pfp.fk_product = p.rowid ";
			if ($sellerref !== '' && $searchname !== '') {
				$sql .= " WHERE (pfp.ref_fourn = '" . $db->escape($sellerref) . "' OR pfp.ref_fourn = '" . $db->escape($searchname) . "') ";
			} elseif ($sellerref !== '') {
				$sql .= " WHERE pfp.ref_fourn = '" . $db->escape($sellerref) . "' ";
			} else {
				$sql .= " WHERE pfp.ref_fourn = '" . $db->escape($searchname) . "' ";
			}
			$sql .= " AND pfp.fk_soc = " . intval($lineData['supplierId'] ?? 0) . " ";
			$sql .= " AND p.entity IN (" . getEntity('product') . ")";
			$sql .= " LIMIT 1";
			$resql = $db->query($sql);
			if ($resql && $db->num_rows($resql) > 0) {
				$obj = $db->fetch_object($resql);
				dol_syslog(__METHOD__ . ' Found product by prodsellerid or prodname as ref_fourn: ' . $obj->rowid);
				return array('res' => $obj->rowid, 'message' => 'Product found by prodsellerid');
				// No match found, continue to next step
			}
		}

		// Fall back on the canonical form of the reference, for the vendors that do not write it
		// the same way on their orders and on their invoices. The exact lookup above stays first,
		// so nothing changes for the vendors that already match, and its index is still used there.
		// Off by default: this comparison is an approximation, so it is a setup option the user
		// turns on knowingly.
		if (getDolGlobalInt('EINVOICING_PRODUCTS_MATCH_CANONICAL_REF')) {
			$canonical = self::canonicalRef($lineData['prodsellerid'] ?? '');
			if ($canonical !== '' && !empty($lineData['supplierId'])) {
				$map = self::canonicalVendorRefMap($db, (int) $lineData['supplierId']);
				if (isset($map[$canonical])) {
					if ($map[$canonical] > 0) {
						dol_syslog(__METHOD__ . ' Found product by prodsellerid on its canonical form: ' . $map[$canonical]);
						return array('res' => $map[$canonical], 'message' => 'Product found by prodsellerid (canonical form)');
					}
					// Several products of this supplier share that canonical form. Nothing can be
					// decided here, so the line goes to the manual mapping instead of being bound
					// to whichever row came first.
					dol_syslog(__METHOD__ . ' Ambiguous canonical vendor ref ' . $canonical . ', left to the manual mapping', LOG_WARNING);
				}
			}
		}

		// Global ID (prodglobalid + prodglobalidtype) and prodglobalidtype = '0160' search by barcode
		// TODO

		// if Buyer Reference (prodbuyerid) is available search prodbuyerid = internal product reference
		// A reference is a string, so its emptiness is tested on the string: empty() also answers true on '0'.
		if (trim((string) ($lineData['prodbuyerid'] ?? '')) !== '') {
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "product";
			$sql .= " WHERE ref = '" . $db->escape($lineData['prodbuyerid']) . "' OR rowid = '" . $db->escape($lineData['prodbuyerid']) . "' ";
			$sql .= " AND entity IN (" . getEntity('product') . ")";
			$sql .= " LIMIT 1";
			$resql = $db->query($sql);
			if ($resql && $db->num_rows($resql) > 0) {
				$obj = $db->fetch_object($resql);
				dol_syslog(__METHOD__ . ' Found product by prodbuyerid: ' . $obj->rowid);
				return array('res' => $obj->rowid, 'message' => 'Product found by prodbuyerid');
			}
		}

		// Check with EI- prefix for product imported using prodsellerid as internal reference with EI- prefix
		if (trim((string) ($lineData['prodsellerid'] ?? '')) !== '') {
			// The reference is sanitized when the product is created (see
			// _findOrCreateProductFromEinvoiceLine), so the lookup has to apply the same transform.
			// A vendor reference holding a character forbidden in a file name is stored as
			// 'EI-A1234_10_42' but was looked up as 'EI-A1234|10|42', so the module could never
			// find back a product it had created itself.
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "product";
			$sql .= " WHERE ref = '" . $db->escape(dol_substr('EI-' . dol_sanitizeFileName($lineData['prodsellerid']), 0, 128)) . "'";
			$sql .= " AND entity IN (" . getEntity('product') . ")";
			$sql .= " LIMIT 1";
			$resql = $db->query($sql);
			if ($resql && $db->num_rows($resql) > 0) {
				$obj = $db->fetch_object($resql);
				dol_syslog(__METHOD__ . ' Found product by prodsellerid with EI- prefix: ' . $obj->rowid);
				return array('res' => $obj->rowid, 'message' => 'Product found by prodsellerid with EI- prefix');
			}
		}

		// Text Search using prodname
		$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "product";
		$sql .= " WHERE label = '" . $db->escape(trim(dol_substr((string) ($lineData['prodname'] ?? ''), 0, 255))) . "'";
		$sql .= " AND entity IN (" . getEntity('product') . ")";
		$resql = $db->query($sql);
		if ($resql) {
			if ($db->num_rows($resql) === 1) {
				$obj = $db->fetch_object($resql);
				dol_syslog(__METHOD__ . ' Found product by text search: ' . $obj->rowid);
				return array('res' => $obj->rowid, 'message' => 'Product found by text search');
			}
		}

		// If not found, we check by using the default product ID on thirdpary level
		$resFetchP = $einvoicing->fetchDefaultRouting($lineData['supplierId'] ?? 0, 'product');
		if (!empty($resFetchP) && $resFetchP != '-1') {
			$product_id = (string) $resFetchP;		// Can be 'idprod_123' (product id) or '456' (supplier ref id)
			if (preg_match('/^idprod_/', $product_id)) {
				$productId = str_replace('idprod_', '', $product_id);
				$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "product";
				$sql .= " WHERE rowid = '" . (int) $productId . "'";
				$sql .= " AND entity IN (" . getEntity('product') . ")";
				$sql .= " LIMIT 1";
				$resql = $db->query($sql);
				if ($resql && $db->num_rows($resql) > 0) {
					$obj = $db->fetch_object($resql);
					dol_syslog(__METHOD__ . ' Default routing product found for supplier=' . $lineData['supplierId'] . ' product=' . $obj->rowid);
					return array('res' => $obj->rowid, 'message' => 'Line product not found, but a default routing product ID was found for this supplier', 'matchtype' => 'defaultrouting');
				}
			} else {
				// We search in product supplier prices table.
				$sql = "SELECT pfp.fk_product";
				$sql .= " FROM " . MAIN_DB_PREFIX . "product_fournisseur_price as pfp";
				$sql .= " INNER JOIN " . MAIN_DB_PREFIX . "product as p";
				$sql .= " ON p.rowid = pfp.fk_product";
				$sql .= " WHERE pfp.rowid = " . ((int) $product_id);
				$sql .= " AND pfp.fk_soc = " . ((int) $lineData['supplierId']);
				$sql .= " AND p.entity IN (" . getEntity('product') . ")";
				$sql .= " LIMIT 1";
				$resql = $db->query($sql);
				if ($resql && $db->num_rows($resql) > 0) {
					$obj = $db->fetch_object($resql);
					dol_syslog(__METHOD__ . ' Default routing product found for supplier=' . $lineData['supplierId'] . ' product=' . $obj->fk_product);
					return array('res' => $obj->fk_product, 'message' => 'Line product not found, but a default routing product was found for this supplier', 'matchtype' => 'defaultrouting');
				}
			}
		}

		return array('res' => 0, 'message' => 'No product found for this e-invoice line');
	}

	/**
	 * Find or create a Dolibarr product based on Einvoice line data
	 *
	 * @param array $lineData Array containing invoice line data extracted from XML
	 * @param string $flowId Flow identifier source of the product. Used for logging purposes.
	 * @return array{res:int, message:string, actioncode:string|null, action:string|null, actionurl:string|null, actiondata:array<string,mixed>, allactiondata:array<string,array<string,mixed>>}   Returns array with 'res' (ID of the found or created product, -1 on error) with a 'message' and an optional 'action'.
	 */
	private function _findOrCreateProductFromEinvoiceLine($lineData, $flowId = '')
	{
		/*
		 * PRODUCT MATCHING FOR SUPPLIER INVOICE (XML invoice line => Dolibarr product)
		 *
		 * This matching strategy attempts to find or create a product based on
		 * XML invoice line data, following a priority-based approach.
		 *
		 * 1 to 4. Search of an existing product, see findProductFromEinvoiceLine()
		 *
		 * 5. If no match found after all steps:
		 *    - Automatic product creation (with extrafield source=Einvoice and to be verified tag)
		 *    - Use this product for supplier invoice line (with extrafield to be verified tag)
		 *    - Add supplier price information (if not added automatically by Dolibarr)
		 *    - Or, if auto creation is disabled, suggest a manual action (create the product or map it
		 *      to an existing one with einvoicing/product_mapping.php)
		 */
		global $db, $user, $langs;

		$einvoicing = new EInvoicing($db);

		// Steps 1 to 4: try to find an existing product
		$resFind = $this->findProductFromEinvoiceLine($lineData);
		if ($resFind['res'] > 0) {
			return $resFind;
		}

		// If no match found after all steps: Create new product
		if (getDolGlobalInt('EINVOICING_PRODUCTS_AUTO_GENERATION')) {
			// Auto-create product
			$product = new Product($db);
			$product->type 		= $this->_detectProductTypeFromEinvoiceLine($lineData);
			// The && was inside the empty(), which warns on an absent key instead of being protected by it.
			$sellerref = trim((string) ($lineData['prodsellerid'] ?? ''));
			$product->ref 		= dol_substr('EI-' . dol_sanitizeFileName($sellerref !== '' ? $sellerref : uniqid()), 0, 128);
			$product->ref_ext 	= $sellerref;
			// BT-153 has no maximum length (EN 16931, BR-FR) and product.label holds 255 characters: a longer
			// name was refused by the database and stopped the whole synchronization. The line keeps it whole.
			$product->label 	= !empty($lineData['prodname'])
				? trim(dol_substr($lineData['prodname'], 0, 255))
				: 'Imported product from supplier invoice (Ref: ' . $lineData['parentDocumentNo'] . ')';
			$product->description = trim($lineData['proddesc'] ?? '');
			$product->tva_tx 	= (float) ($lineData['rateApplicablePercent'] ?? 0);
			$product->status 	= 0; // Status not to sell
			$product->status_buy = 1; // Status to buy
			$product->note_private = 'Product created automatically from E-invoice import.';
			$product->import_key = AbstractPDPProvider::$EINVOICING_LAST_IMPORT_KEY; // It does not work here, so we will update it after creation
			// Set barcode if global ID is provided and is a GTIN/EAN type
			if (!empty($lineData['prodglobalid']) && !empty($lineData['prodglobalidtype']) && in_array($lineData['prodglobalidtype'], ['0160', '0011'])) {
				$product->barcode = $lineData['prodglobalid'];
				$product->barcode_type = getDolGlobalInt('PRODUIT_DEFAULT_BARCODE_TYPE', 0);
			} else {
				$product->barcode = 'auto';
			}
			// Validate before creation
			$resCheck = $product->check();
			if ($resCheck < 0) {
				dol_syslog(__METHOD__ . ' Product check failed: ' . $product->error, LOG_ERR);
				return array('res' => -1, 'message' => 'Product check failed: ' . dol_escape_htmltag(implode("\n", $product->errors)));
			}

			// Create product
			$resCreate = $product->create($user);
			if ($resCreate > 0) {
				$productId = $product->id;

				// Set import_key
				$sql = "UPDATE " . MAIN_DB_PREFIX . "product SET import_key = '" . $db->escape($product->import_key) . "'";
				$sql .= " WHERE rowid = " . ((int) $productId);
				$db->query($sql);

				// Add entry in einvoicing_extlinks table to mark product as created from e-invoice
				$einvoicing->insertOrUpdateExtLink($productId, $product->element, $flowId);

				dol_syslog(__METHOD__ . ' New product created (ID: ' . $productId . ')');
				return [
					'res' => $productId,
					'message' => 'Product successfully created from E-invoice import',
				];
			}

			// Error on creation
			dol_syslog(__METHOD__ . ' Product creation error: ' . $product->error, LOG_ERR);
			return [
				'res' => -1,
				'message' => 'Product creation error: ' . dol_escape_htmltag($product->error),
			];
		} else {
			// Suggest manual creation of product
			dol_syslog(get_class($this) . '::_findOrCreateProductFromEinvoiceLine Auto-creation of products is disabled', LOG_ERR);

			// Free line mode: import the line without linking any product (res=0 signals the protocol to set desc from XML)
			if (getDolGlobalInt('EINVOICING_IMPORT_AS_FREE_LINES')) {
				dol_syslog(get_class($this) . '::_findOrCreateProductFromEinvoiceLine Free line mode: importing without product link', LOG_DEBUG);
				return array('res' => 0, 'message' => 'Product not found, line imported as free description line (no product link)');
			}

			$prodRef = trim($lineData['prodbuyerid'] ?? '');
			$prodSupplierRef = trim($lineData['prodsellerid'] ?? '');
			$prodName = trim($lineData['prodname'] ?? '');
			$prodDesc = trim($lineData['proddesc'] ?? '');
			$vendorId = $lineData['supplierId'];

			$langs->loadLangs(array("product", "einvoicing@einvoicing"));

			$errorDetails = [];
			$createParams = [];
			$allactiondata = [];

			if ($prodRef !== '') {
				$errorDetails[] = 'Ref: '.$prodRef;

				$createParams['ref'] = 'EI-' . dol_sanitizeFileName($prodSupplierRef !== '' ? $prodSupplierRef : uniqid());

				$createParams['ref_ext'] = $prodRef;
			}
			if (!empty($vendorId)) {
				$errorDetails[] = 'Vendor id: ' . $vendorId;
				$createParams['socid'] = $vendorId;							// TODO Dolibarr must be able to handle this parameter
			}
			if ($prodSupplierRef !== '') {
				$errorDetails[] = 'Supplier ref: ' . $prodSupplierRef;
				$createParams['supplierref'] = $prodSupplierRef;			// TODO Dolibarr must be able to handle this parameter
			}
			if (!empty($prodName)) {
				$errorDetails[] = $langs->trans("Name").': ' . $prodName;
				$createParams['label'] = $prodName;
			}
			if (!empty($prodDesc)) {
				//$errorDetails[] = 'Description: ' . $prodDesc;
				$createParams['desc'] = $prodDesc;
			}

			// Detect type to prefill form (0 = product, 1 = service). Fallback on product if the service module is not enabled.
			$prodType = $this->_detectProductTypeFromEinvoiceLine($lineData);
			if ($prodType == 1 && !isModEnabled('service')) {
				$prodType = 0;
			}
			$createParams['type'] = $prodType;
			$createParams['tva_tx'] = (float) ($lineData['rateApplicablePercent'] ?? 0);
			$createParams['status'] = 1; // Active
			if (!empty($lineData['prodglobalid']) && !empty($lineData['prodglobalidtype']) && in_array($lineData['prodglobalidtype'], ['0160', '0011'])) {
				$createParams['barcode'] = $lineData['prodglobalid'];
				$createParams['barcode_type'] = getDolGlobalInt('PRODUIT_DEFAULT_BARCODE_TYPE', 0);
			} else {
				$createParams['barcode'] = 'auto';
			}

			// Create URL to prefill product creation form
			$createUrl = DOL_URL_ROOT . '/product/card.php?action=create';
			if (!empty($createParams)) {
				// The Dolibarr GET firewall (analyseVarsForSqlAndScriptsInjection) rejects " < > in any URL
				// parameter, so a line label/description carrying them would 403 before the prefilled creation
				// form even opens. Use the core helper (replaces " with ' and removes < >, identical from
				// v18 to v25) to drop them from the prefill - a convenience the operator reviews and edits.
				foreach ($createParams as $cpKey => $cpVal) {
					if (is_string($cpVal)) {
						$createParams[$cpKey] = dol_string_nospecial($cpVal, "'", array('"'), array('<', '>'));
					}
				}
				$createUrl .= '&' . http_build_query($createParams);
			}
			$createUrl .= '&backtopage=' . urlencode(dol_buildpath('/einvoicing/document_list.php', 1));

			$detailsStr = !empty($errorDetails) ? ' [' . implode(' - ', $errorDetails) . ']' : '';

			$message = 'Unable to find product' . $detailsStr . '. Auto-creation of products is disabled in settings.';

			$btnStyle = 'display:inline-block;width:auto;';

			$action = '<div class="marginbottomonly opacitymedium">' . $langs->trans('SuggestedActionsIntro') . '</div>';


			// First choice: create a new product manually
			$action .= '<a class="button small smallpaddingimp" style="' . $btnStyle . '" href="' . dol_escape_htmltag($createUrl) . '" target="_blank" title="'.$langs->trans($prodType == 1 ? 'CreateServiceManually' : 'CreateProductManually').'">';
			$action .= '<i class="fas fa-plus-circle"></i> ';
			$action .= $langs->trans($prodType == 1 ? 'CreateService' : 'CreateProduct');
			$action .= '</a>';
			$actiondata = $createParams;
			$allactiondata['createproduct'] = array('label' => $langs->trans($prodType == 1 ? 'CreateServiceManually' : 'CreateProductManually'), 'url' => $createUrl, 'actiondata' => $actiondata);

			// Second choice: map the vendor product reference(s) of this flow onto existing Dolibarr products.
			// This creates the vendor reference (llx_product_fournisseur_price) that the matching uses at step 1,
			// so the next synchronization will find the product without creating a new one.
			if (!empty($flowId)) {
				$mappingUrl = dol_buildpath('/einvoicing/product_mapping.php', 1);
				$mappingUrl .= '?flowid=' . urlencode($flowId);
				if (!empty($vendorId)) {
					$mappingUrl .= '&socid=' . ((int) $vendorId);
				}

				$action .= '<a class="button small smallpaddingimp" style="' . $btnStyle . '" href="' . dol_escape_htmltag($mappingUrl) . '" target="_blank">';
				$action .= '<i class="fas fa-link unsetcolor"></i> ';
				$action .= $langs->trans('AssociateExistingProductMessage');
				$action .= '</a>';

				$allactiondata['addsupplierrefprice'] = array('label' => $langs->trans("AssociateExistingProductMessage"), 'url' => $mappingUrl, 'actiondata' => array('socid' => ((int) $vendorId)));
			}

			// Third choice: set a default product on the vendor thirdparty (used for future imports when no product is found)
			// The field lives on the thirdparty card, so this one takes the right to edit it. Greyed without it,
			// like the button above. "disabled" and not "buttonRefused": the eldy theme dropped the rule for
			// that class in Dolibarr 24, which would leave the button looking enabled there.
			if (!empty($vendorId)) {
				$thirdpartyUrl = dol_buildpath('/societe/card.php', 1) . '?socid=' . ((int) $vendorId) . '&action=edit&highlight=routing_product_id#treinvoicing';
				$action .= $user->hasRight('societe', 'creer')
					? '<a class="button small smallpaddingimp" style="' . $btnStyle . '" href="' . dol_escape_htmltag($thirdpartyUrl) . '" target="_blank">'
					: '<a class="button disabled classfortooltip small smallpaddingimp" style="' . $btnStyle . '" href="#" title="' . dol_escape_htmltag($langs->trans("NotEnoughPermissions")) . '">';
				$action .= '<i class="fas fa-star"></i> ';
				$action .= $langs->trans('SetDefaultProductForThirdparty');
				$action .= '</a>';

				$allactiondata['setdefaultproduct'] = array('label' => $langs->trans("SetDefaultProductForThirdparty"), 'url' => $thirdpartyUrl, 'actiondata' => array('socid' => ((int) $vendorId)));
			}


			return array(
				'res' => -1,
				'message' => $message,
				'actioncode' => 'PRODUCT_NOT_FOUND',
				'action' => $action,				// full text suggested to make actions
				'actionurl' => $createUrl,			// URL of first action
				'actiondata' => $actiondata,		// Array of param to use for first action
				'allactiondata' => $allactiondata	// Array with all actions
			);
		}
	}


	/**
	 * Extract a SIRET from the seller's global identifiers (sellerGlobalIds / sellerLegalOrgId), the
	 * only identifier precise enough to tell apart two établissements of one French entity that share
	 * a single VAT number (the number is derived from the SIREN alone, not the SIRET).
	 *
	 * @param	array<string,mixed>	$sellerInfo	Seller information extracted from the e-invoice
	 * @param	string	$sellerCountryCode	Country code of the seller
	 * @return	string						Cleaned SIRET (no spaces), '' when the document carries none
	 */
	private function _extractSellerSiret($sellerInfo, $sellerCountryCode)
	{
		if (empty($sellerInfo['sellerGlobalIds']) || !is_array($sellerInfo['sellerGlobalIds'])) {
			return '';
		}

		foreach ($sellerInfo['sellerGlobalIds'] as $idScheme => $globalId) {
			if (!empty($globalId) && $this->_mapGlobalIdSchemeToIdprof($idScheme, $sellerCountryCode, $globalId) === 'idprof2') {
				return removeAllSpaces($globalId);
			}
		}

		return '';
	}


	/**
	 * Map global ID scheme to Dolibarr idprof field
	 *
	 * 0002 and 0009 name the register they come from, 0225 does not: it is the French e-invoicing
	 * ADDRESS scheme, whose value is a SIREN, a SIRET, or either of them suffixed with a routing code
	 * (rules G1.83, G1.93 and G1.115 of the French specification). Its shape is therefore what decides
	 * where it is stored, and a suffixed one is stored nowhere: it identifies a mailbox, not a company.
	 * 0231 (the SIREN of a VAT group) and 0088 (a GLN) are left out on purpose - neither is the
	 * registration identifier of the party the document names.
	 *
	 * @param 	string 	$scheme 		Global ID scheme code
	 * @param	string	$countrycode	Country code
	 * @param	string	$value			Identifier carried under that scheme, read when the scheme alone does not decide
	 * @return 	string 					Corresponding idprof field name, empty when the identifier is not one
	 */
	private function _mapGlobalIdSchemeToIdprof($scheme, $countrycode = '', $value = '')
	{
		if ($scheme === '0225') {
			$digits = preg_replace('/\D/', '', (string) $value);
			if ($digits !== (string) $value) {
				return '';
			}
			if (dol_strlen($digits) == 9) {
				return 'idprof1';	// SIREN
			}
			return (dol_strlen($digits) == 14) ? 'idprof2' : '';	// SIRET
		}

		$map = [
			'0002' => 'idprof1',	// SIREN
			'0009' => 'idprof2',	// SIRET
		];

		return $map[$scheme] ?? '';
	}


	/**
	 * Normalize a company name for tolerant comparison.
	 *
	 * Applies the normalization recommended for e-invoicing name checks so that purely descriptive
	 * differences do not raise false positives: strip accents, lowercase, drop common legal forms
	 * (SARL, SAS, GmbH, Ltd...) and collapse everything that is not a letter or a digit. The result is a
	 * comparison key, not a displayable name.
	 *
	 * @param 	string 	$name 	Raw company name
	 * @return 	string 			Normalized comparison key (may be an empty string)
	 */
	private function _normalizeCompanyNameForComparison($name)
	{
		$name = trim((string) $name);
		if ($name === '') {
			return '';
		}

		// Strip accents then lowercase so "Société" and "SOCIETE" compare equal
		$name = strtolower(dol_string_unaccent($name));

		// Remove common legal forms (whole words only) to avoid false positives on suffixes
		$legalForms = array(
			'sarl', 'sas', 'sasu', 'sa', 'eurl', 'sci', 'snc', 'scop', 'scs', 'sca', 'gie', 'ei',
			'societe', 'ste', 'ets', 'etablissements', 'cie', 'gmbh', 'ug', 'ag', 'kg', 'ohg',
			'ltd', 'limited', 'llc', 'inc', 'corp', 'co', 'plc', 'bv', 'nv', 'srl', 'spa', 'sl',
		);
		$name = preg_replace('/\b(' . implode('|', $legalForms) . ')\b/', ' ', $name);

		// Keep only alphanumeric characters (drops punctuation, spaces, &, -, etc.)
		$name = preg_replace('/[^a-z0-9]/', '', (string) $name);

		return (string) $name;
	}


	/**
	 * Check whether a name carried by an e-invoice is consistent with the linked third party.
	 *
	 * Each candidate name is normalized (see _normalizeCompanyNameForComparison) and a match is accepted
	 * when any invoice name equals or is contained in any Dolibarr name (or vice versa), so that a trading
	 * name vs. legal name difference does not trigger a warning. When either side has no usable name after
	 * normalization, the comparison is inconclusive and the names are considered consistent (no false alarm).
	 *
	 * @param 	string[] 	$invoiceNames 	Candidate names from the e-invoice (e.g. BT-27 seller name, BT-28 trading name)
	 * @param 	string[] 	$dolibarrNames 	Candidate names from the linked third party (e.g. nom, name_alias)
	 * @return 	bool 						True if consistent (or not comparable), false on a genuine mismatch
	 */
	private function _companyNamesAreConsistent(array $invoiceNames, array $dolibarrNames)
	{
		$normInvoice = array();
		foreach ($invoiceNames as $candidate) {
			$key = $this->_normalizeCompanyNameForComparison($candidate);
			if ($key !== '') {
				$normInvoice[$key] = $key;
			}
		}
		$normDolibarr = array();
		foreach ($dolibarrNames as $candidate) {
			$key = $this->_normalizeCompanyNameForComparison($candidate);
			if ($key !== '') {
				$normDolibarr[$key] = $key;
			}
		}

		// Not enough data to compare -> do not raise a warning
		if (empty($normInvoice) || empty($normDolibarr)) {
			return true;
		}

		foreach ($normInvoice as $invoiceName) {
			foreach ($normDolibarr as $dolibarrName) {
				if ($invoiceName === $dolibarrName
					|| strpos($invoiceName, $dolibarrName) !== false
					|| strpos($dolibarrName, $invoiceName) !== false) {
					return true;
				}
			}
		}

		return false;
	}


	/**
	 * Determine if a invoice line corresponds to a product (0) or a service (1)
	 *
	 * @param 	array 	$line 	Invoice line data
	 * @return 	int 			0 = product / 1 = service
	 */
	private function _detectProductTypeFromEinvoiceLine(array $line): int
	{
		$globalId = trim($line['prodglobalid'] ?? '');
		$globalIdType = trim($line['prodglobalidtype'] ?? '');
		$sellerId = trim($line['prodsellerid'] ?? '');
		$unitCode = strtoupper(trim($line['billedquantityunitcode'] ?? ''));
		$name = strtolower($line['prodname'] ?? '');
		$desc = strtolower($line['proddesc'] ?? '');

		// A. Global ID known => product
		// EAN = 0088
		$productGlobalIdTypes = ['0160', '0011', '0002', '0023', '0004', '0001', '0088']; // GTIN/UPC/EAN...
		if ($globalId !== '' && in_array($globalIdType, $productGlobalIdTypes, true)) {
			return 0;
		}

		// B. Units typical for services
		$serviceUnits = ['HUR', 'HRS', 'DAY', 'MON', 'ANN', 'MIN', 'WEE', 'E48']; // hours, days, months...
		if (in_array($unitCode, $serviceUnits, true)) {
			return 1;
		}

		// C. Piece but no seller reference => likely service
		if ($sellerId === '') {
			return 1;
		}

		// D. Keywords indicating service
		$keywordsService = ['service', 'prestation', 'maintenance', 'installation', 'abonnement', 'support', 'forfait', 'consult'];
		foreach ($keywordsService as $kw) {
			if (stripos($name, $kw) !== false || stripos($desc, $kw) !== false) {
				return 1;
			}
		}

		// Fallback = product
		return 0;
	}

	/**
	 * Get a timestamp and return a php DateTime object
	 *
	 * @param	int		$ts			Timestamp
	 * @return 	\DateTime|null 		DateTime object or null if $ts is empty
	 */
	private function _tsToDateTime($ts)
	{
		dol_syslog("call _tsToDateTime for {$ts} ...");
		if (empty($ts)) {
			return null;
		}
		$dt = new \DateTime();
		$dt->setTimestamp($ts);
		return $dt;
	}

	/**
	 * Check if a given VAT rate is valid for a specific country based on the c_tva table in the database.
	 *
	 * @param 	string	$vatrate		Vat rate to check (e.g. '20' for 20%)
	 * @param 	string	$countryCode	Country code to check the VAT rate against (e.g. 'FR' for France)
	 * @return 	boolean					Returns true if the VAT rate is valid for the given country, false otherwise.
	 */
	public function checkIfVatRateIsValid($vatrate, $countryCode)
	{
		if ($countryCode == 'FR') {
			// Check rule BR-FR-16 For AFNOR Einvoice - List in XP-Z12-012
			$validRatesString = ['0', '10', '13', '20', '8.5', '19.6', '2.1', '5.5', '7', '20.6', '1.05', '0.9', '1.75', '9.2', '9.6'];
			//$valtotest = price2num((float) $vatrate, '', 1);
			if (!in_array($vatrate, $validRatesString)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Refuse to build a line whose VAT category requires a Seller VAT identifier the seller has not got.
	 *
	 * BR-E-02 and its siblings BR-S-02, BR-Z-02 and BR-AE-02 are satisfied by either the Seller VAT
	 * identifier (BT-31, schemeID VA) or the tax registration identifier (BT-32, schemeID FC). BR-G-02
	 * and BR-IC-02 are not: their assertion reads schemeID = 'VA' alone. Reported here rather than left
	 * to the platform, which refuses on a rule the operator cannot connect to a missing field (#560).
	 *
	 * @param	Societe		$seller		Selling company
	 * @param	string		$rule		Business rule that will be broken, for the message
	 * @param	string		$operation	What the invoice does, in words, for the message
	 * @return	void
	 * @throws	Exception				When the seller has no VAT number to declare
	 */
	private function assertSellerVatIdentifier($seller, $rule, $operation)
	{
		if (!empty($seller->tva_intra)) {
			return;
		}

		$why = ': that rule accepts the seller VAT identifier (BT-31) only, not the tax registration identifier (BT-32) a seller charging no VAT would declare.';

		throw new Exception('BADVATNUMBER[' . $rule . ']: The VAT number of the seller ' . $seller->name . ' is mandatory on ' . $operation . $why);
	}

	/**
	 * Tell the EN 16931 VAT category a VAT exemption reason code (BT-121) imposes.
	 *
	 * The code list annotates some of its entries with the category they go with - "Only use with VAT
	 * category code O" for VATEX-EU-O - so the dictionary entry the seller fills already carries the
	 * qualification, and nothing else has to be asked of them.
	 *
	 * Only "Not subject to VAT" is mapped here. The three other bound codes (AE, G, IC) describe
	 * situations the country tests above already decide, and reading them from the dictionary as well
	 * would let a mis-filled entry contradict the seller and buyer countries.
	 *
	 * @param 	string 	$vatex 	VAT exemption reason code, uppercased
	 * @return 	string 			Category code the list imposes, or '' when it imposes none
	 */
	protected function vatCategoryForExemptionCode($vatex)
	{
		// Dolibarr 24 is where llx_c_tva.einvoice_vatex appears, and it is the only place a seller can
		// state the code without a hidden constant. Below that the category keeps its previous value.
		if ((float) DOL_VERSION < 24.0) {
			return '';
		}

		return strtoupper((string) $vatex) === 'VATEX-EU-O' ? 'O' : '';
	}

	/**
	 * Get the category of the VAT rate and the VATEX code and reason.
	 *
	 * @param 	CommonInvoiceLine		$line			Invoice line
	 * @param 	Societe 				$seller			Seller
	 * @param 	CommonInvoice			$buyer			Invoice the line belongs to, whose ->thirdparty is the buyer. Not a Societe: the single caller passes the invoice, and the buyer is read through it below.
	 * @return 	array<string,string>					array('categoryVAT' => Category of VAT rate ('S', 'Z', 'E', 'AE', 'K', 'G'), 'ExemptionReason' => '', 'ExemptionReasonCode => '')
	 */
	public function getCategoryRate($line, $seller, $buyer)
	{
		global $langs;

		$vat_rate = $line->tva_tx;
		$vat_src_code = $line->vat_src_code;
		$id = $line->id;

		$errormsg = '';

		// List of VATEX codes and reasons imported from https://docs.peppol.eu/poacc/billing/3.0/codelist/vatex/
		$VATEX_CODE_LIST = array(
			'VATEX-EU-79-C' => array('reason' => 'Exempt based on article 79, point c of Council Directive 2006/112/EC', 'details' => 'Exemptions relating to repayment of expenditures. Remark, Repayment of expenditure is not an exemption in the sense of the VAT Directive but may be handled as such in the context of the EN16931.'),
			'VATEX-EU-132' => array('reason' => 'Exempt based on article 132 of Council Directive 2006/112/EC', 'details' => 'Exemptions for certain activities in public interest.'),
			'VATEX-EU-132-1A' => array('reason' => 'Exempt based on article 132, section 1 (a) of Council Directive 2006/112/EC', 'details' => 'The supply by the public postal services of services other than passenger transport and telecommunications services, and the supply of goods incidental thereto.'),
			'VATEX-EU-132-1B' => array('reason' => 'Exempt based on article 132, section 1 (b) of Council Directive 2006/112/EC', 'details' => 'Hospital and medical care and closely related activities undertaken by bodies governed by public law or, under social conditions comparable with those applicable to bodies governed by public law, by hospitals, centres for medical treatment or diagnosis and other duly recognised establishments of a similar nature'),
			'VATEX-EU-132-1C' => array('reason' => 'Exempt based on article 132, section 1 (c) of Council Directive 2006/112/EC', 'details' => 'The provision of medical care in the exercise of the medical and paramedical professions as defined by the Member State concerned.'),
			'VATEX-EU-132-1D' => array('reason' => 'Exempt based on article 132, section 1 (d) of Council Directive 2006/112/EC', 'details' => 'The supply of human organs, blood and milk.'),
			'VATEX-EU-132-1E' => array('reason' => 'Exempt based on article 132, section 1 (e) of Council Directive 2006/112/EC', 'details' => 'The supply of services by dental technicians in their professional capacity and the supply of dental prostheses by dentists and dental technicians.'),
			'VATEX-EU-132-1F' => array('reason' => 'Exempt based on article 132, section 1 (f) of Council Directive 2006/112/EC', 'details' => 'The supply of services by independent groups of persons, who are carrying on an activity which is exempt from VAT or in relation to which they are not taxable persons, for the purpose of rendering their members the services directly necessary for the exercise of that activity, where those groups merely claim from their members exact reimbursement of their share of the joint expenses, provided that such exemption is not likely to cause distortion of competition.'),
			'VATEX-EU-132-1G' => array('reason' => 'Exempt based on article 132, section 1 (g) of Council Directive 2006/112/EC', 'details' => 'The supply of services and of goods closely linked to welfare and social security work, including those supplied by old people\'s homes, by bodies governed by public law or by other bodies recognised by the Member State concerned as being devoted to social wellbeing.'),
			'VATEX-EU-132-1H' => array('reason' => 'Exempt based on article 132, section 1 (h) of Council Directive 2006/112/EC', 'details' => '"The supply of services and of goods closely linked to the protection of children and young persons by bodies governed by public law or by other organisations recognised by the Member State concerned as being devoted to social wellbeing"'),
			'VATEX-EU-132-1I' => array('reason' => 'Exempt based on article 132, section 1 (i) of Council Directive 2006/112/EC', 'details' => '" The provision of children\'s or young people\'s education, school or university education, vocational training or retraining, including the supply of services and of goods closely related thereto, by bodies governed by public law having such as their aim or by other organisations recognised by the Member State concerned as having similar objects."'),
			'VATEX-EU-132-1J' => array('reason' => 'Exempt based on article 132, section 1 (j) of Council Directive 2006/112/EC', 'details' => 'Tuition given privately by teachers and covering school or university education.'),
			'VATEX-EU-132-1K' => array('reason' => 'Exempt based on article 132, section 1 (k) of Council Directive 2006/112/EC', 'details' => 'The supply of staff by religious or philosophical institutions for the purpose of the activities referred to in points (b), (g), (h) and (i) and with a view to spiritual welfare.'),
			'VATEX-EU-132-1L' => array('reason' => 'Exempt based on article 132, section 1 (l) of Council Directive 2006/112/EC', 'details' => 'The supply of services, and the supply of goods closely linked thereto, to their members in their common interest in return for a subscription fixed in accordance with their rules by non-profitmaking organisations with aims of a political, trade-union, religious, patriotic, philosophical, philanthropic or civic nature, provided that this exemption is not likely to cause distortion of competition.'),
			'VATEX-EU-132-1M' => array('reason' => 'Exempt based on article 132, section 1 (m) of Council Directive 2006/112/EC', 'details' => 'The supply of certain services closely linked to sport or physical education by non-profit-making organisations to persons taking part in sport or physical education.'),
			'VATEX-EU-132-1N' => array('reason' => 'Exempt based on article 132, section 1 (n) of Council Directive 2006/112/EC', 'details' => 'The supply of certain cultural services, and the supply of goods closely linked thereto, by bodies governed by public law or by other cultural bodies recognised by the Member State concerned.'),
			'VATEX-EU-132-1O' => array('reason' => 'Exempt based on article 132, section 1 (o) of Council Directive 2006/112/EC', 'details' => '"The supply of services and goods, by organisations whose activities are exempt pursuant to points (b), (g), (h), (i), (l), (m) and (n), in connection with fund-raising events organised exclusively for their own benefit, provided that exemption is not likely to cause distortion of competition."'),
			'VATEX-EU-132-1P' => array('reason' => 'Exempt based on article 132, section 1 (p) of Council Directive 2006/112/EC', 'details' => 'The supply of transport services for sick or injured persons in vehicles specially designed for the purpose, by duly authorised bodies.'),
			'VATEX-EU-132-1Q' => array('reason' => 'Exempt based on article 132, section 1 (q) of Council Directive 2006/112/EC', 'details' => 'The activities, other than those of a commercial nature, carried out by public radio and television bodies.'),
			'VATEX-EU-143' => array('reason' => 'Exempt based on article 143 of Council Directive 2006/112/EC', 'details' => 'Exemptions on importation.'),
			'VATEX-EU-143-1A' => array('reason' => 'Exempt based on article 143, section 1 (a) of Council Directive 2006/112/EC', 'details' => 'The final importation of goods of which the supply by a taxable person would in all circumstances be exempt within their respective territory.'),
			'VATEX-EU-143-1B' => array('reason' => 'Exempt based on article 143, section 1 (b) of Council Directive 2006/112/EC', 'details' => 'The final importation of goods governed by Council Directives 69/169/EEC (1), 83/181/EEC (2) and 2006/79/EC (3).'),
			'VATEX-EU-143-1C' => array('reason' => 'Exempt based on article 143, section 1 (c) of Council Directive 2006/112/EC', 'details' => 'The final importation of goods, in free circulation from a third territory forming part of the Community customs territory, which would be entitled to exemption under point (b) if they had been imported within the meaning of the first paragraph of Article 30'),
			'VATEX-EU-143-1D' => array('reason' => 'Exempt based on article 143, section 1 (d) of Council Directive 2006/112/EC', 'details' => 'The importation of goods dispatched or transported from a third territory or a third country into a Member State other than that in which the dispatch or transport of the goods ends, where the supply of such goods by the importer designated or recognised under Article 201 as liable for payment of VAT is exempt under Article 138.'),
			'VATEX-EU-143-1E' => array('reason' => 'Exempt based on article 143, section 1 (e) of Council Directive 2006/112/EC', 'details' => 'The reimportation, by the person who exported them, of goods in the state in which they were exported, where those goods are exempt from customs duties.'),
			'VATEX-EU-143-1F' => array('reason' => 'Exempt based on article 143, section 1 (f) of Council Directive 2006/112/EC', 'details' => 'The importation, under diplomatic and consular arrangements, of goods which are exempt from customs duties.'),
			'VATEX-EU-143-1FA' => array('reason' => 'Exempt based on article 143, section 1 (fa) of Council Directive 2006/112/EC', 'details' => '"The importation of goods by the European Community, the European Atomic Energy Community, the European Central Bank or the European Investment Bank, or by the bodies set up by the Communities to which the Protocol of 8 April 1965 on the privileges and immunities of the European Communities applies, within the limits and under the conditions of that Protocol and the agreements for its implementation or the headquarters agreements, in so far as it does not lead to distortion of competition"'),
			'VATEX-EU-143-1G' => array('reason' => 'Exempt based on article 143, section 1 (g) of Council Directive 2006/112/EC', 'details' => '" The importation of goods by international bodies, other than those referred to in point (fa), recognised as such by the public authorities of the host Member State, or by members of such bodies, within the limits and under the conditions laid down by the international conventions establishing the bodies or by headquarters agreements"'),
			'VATEX-EU-143-1H' => array('reason' => 'Exempt based on article 143, section 1 (h) of Council Directive 2006/112/EC', 'details' => 'The importation of goods, into Member States party to the North Atlantic Treaty, by the armed forces of other States party to that Treaty for the use of those forces or the civilian staff accompanying them or for supplying their messes or canteens where such forces take part in the common defence effort.'),
			'VATEX-EU-143-1I' => array('reason' => 'Exempt based on article 143, section 1 (i) of Council Directive 2006/112/EC', 'details' => 'The importation of goods by the armed forces of the United Kingdom stationed in the island of Cyprus pursuant to the Treaty of Establishment concerning the Republic of Cyprus, dated 16 August 1960, which are for the use of those forces or the civilian staff accompanying them or for supplying their messes or canteens.'),
			'VATEX-EU-143-1J' => array('reason' => 'Exempt based on article 143, section 1 (j) of Council Directive 2006/112/EC', 'details' => 'The importation into ports, by sea fishing undertakings, of their catches, unprocessed or after undergoing preservation for marketing but before being supplied.'),
			'VATEX-EU-143-1K' => array('reason' => 'Exempt based on article 143, section 1 (k) of Council Directive 2006/112/EC', 'details' => 'The importation of gold by central banks.'),
			'VATEX-EU-143-1L' => array('reason' => 'Exempt based on article 143, section 1 (l) of Council Directive 2006/112/EC', 'details' => 'The importation of gas through a natural gas system or any network connected to such a system or fed in from a vessel transporting gas into a natural gas system or any upstream pipeline network, of electricity or of heat or cooling energy through heating or cooling networks.'),
			'VATEX-EU-144' => array('reason' => 'Exempt based on article 144 of Council Directive 2006/112/EC', 'details' => 'Exemptions for services linked to the import of goods'),
			'VATEX-EU-146-1E' => array('reason' => 'Exempt based on article 146 section 1 (e) of Council Directive 2006/112/EC', 'details' => 'Exempt Exemptions for services linked to the export of goods'),
			'VATEX-EU-148' => array('reason' => 'Exempt based on article 148 of Council Directive 2006/112/EC', 'details' => 'Exemptions related to international transport.'),
			'VATEX-EU-148-A' => array('reason' => 'Exempt based on article 148, section (a) of Council Directive 2006/112/EC', 'details' => 'Fuel supplies for commercial international transport vessels'),
			'VATEX-EU-148-B' => array('reason' => 'Exempt based on article 148, section (b) of Council Directive 2006/112/EC', 'details' => 'Fuel supplies for fighting ships in international transport.'),
			'VATEX-EU-148-C' => array('reason' => 'Exempt based on article 148, section (c) of Council Directive 2006/112/EC', 'details' => 'Maintenance, modification, chartering and hiring of international transport vessels.'),
			'VATEX-EU-148-D' => array('reason' => 'Exempt based on article 148, section (d) of Council Directive 2006/112/EC', 'details' => 'Supply to of other services to commercial international transport vessels.'),
			'VATEX-EU-148-E' => array('reason' => 'Exempt based on article 148, section (e) of Council Directive 2006/112/EC', 'details' => 'Fuel supplies for aircraft on international routes.'),
			'VATEX-EU-148-F' => array('reason' => 'Exempt based on article 148, section (f) of Council Directive 2006/112/EC', 'details' => 'Maintenance, modification, chartering and hiring of aircraft on international routes.'),
			'VATEX-EU-148-G' => array('reason' => 'Exempt based on article 148, section (g) of Council Directive 2006/112/EC', 'details' => 'Supply to of other services to aircraft on international routes.'),
			'VATEX-EU-151' => array('reason' => 'Exempt based on article 151 of Council Directive 2006/112/EC', 'details' => 'Exemptions relating to certain Transactions treated as exports.'),
			'VATEX-EU-151-1A' => array('reason' => 'Exempt based on article 151, section 1 (a) of Council Directive 2006/112/EC', 'details' => 'The supply of goods or services under diplomatic and consular arrangements.'),
			'VATEX-EU-151-1AA' => array('reason' => 'Exempt based on article 151, section 1 (aa) of Council Directive 2006/112/EC', 'details' => 'The supply of goods or services to the European Community, the European Atomic Energy Community, the European Central Bank or the European Investment Bank, or to the bodies set up by the Communities to which the Protocol of 8 April 1965 on the privileges and immunities of the European Communities applies, within the limits and under the conditions of that Protocol and the agreements for its implementation or the headquarters agreements, in so far as it does not lead to distortion of competition.'),
			'VATEX-EU-151-1B' => array('reason' => 'Exempt based on article 151, section 1 (b) of Council Directive 2006/112/EC', 'details' => 'The supply of goods or services to international bodies, other than those referred to in point (aa), recognised as such by the public authorities of the host Member States, and to members of such bodies, within the limits and under the conditions laid down by the international conventions establishing the bodies or by headquarters agreements.'),
			'VATEX-EU-151-1C' => array('reason' => 'Exempt based on article 151, section 1 (c) of Council Directive 2006/112/EC', 'details' => 'The supply of goods or services within a Member State which is a party to the North Atlantic Treaty, intended either for the armed forces of other States party to that Treaty for the use of those forces, or of the civilian staff accompanying them, or for supplying their messes or canteens when such forces take part in the common defence effort.'),
			'VATEX-EU-151-1D' => array('reason' => 'Exempt based on article 151, section 1 (d) of Council Directive 2006/112/EC', 'details' => 'The supply of goods or services to another Member State, intended for the armed forces of any State which is a party to the North Atlantic Treaty, other than the Member State of destination itself, for the use of those forces, or of the civilian staff accompanying them, or for supplying their messes or canteens when such forces take part in the common defence effort.'),
			'VATEX-EU-151-1E' => array('reason' => 'Exempt based on article 151, section 1 (e) of Council Directive 2006/112/EC', 'details' => 'The supply of goods or services to the armed forces of the United Kingdom stationed in the island of Cyprus pursuant to the Treaty of Establishment concerning the Republic of Cyprus, dated 16 August 1960, which are for the use of those forces, or of the civilian staff accompanying them, or for supplying their messes or canteens.'),
			'VATEX-EU-159' => array('reason' => 'Exempt based on article 159 of Council Directive 2006/112/EC', 'details' => 'Exemptions for services linked to supplies of goods intended to be placed under customs warehouses, warehouses other than customs warehouses and similar arrangements.'),
			'VATEX-EU-309' => array('reason' => 'Exempt based on article 309 of Council Directive 2006/112/EC', 'details' => 'Travel agents performed outside of EU.'),
			'VATEX-EU-AE' => array('reason' => 'Reverse charge', 'details' => 'Supports EN 16931-1 rule BR-AE-10 - Only use with VAT category code AE'),
			'VATEX-EU-D' => array('reason' => 'Intra-Community acquisition from second hand means of transport', 'details' => 'Second-hand means of transport - Indication that VAT has been paid according to the relevant transitional arrangements - Only use with VAT category code E'),
			'VATEX-EU-F' => array('reason' => 'Intra-Community acquisition of second hand goods', 'details' => 'Second-hand goods - Indication that the VAT margin scheme for second-hand goods has been applied. - Only use with VAT category code E'),
			'VATEX-EU-G' => array('reason' => 'Export outside the EU', 'details' => 'Supports EN 16931-1 rule BR-G-10 - Only use with VAT category code G'),
			'VATEX-EU-I' => array('reason' => 'Intra-Community acquisition of works of art', 'details' => 'Works of art - Indication that the VAT margin scheme for works of art has been applied. - Only use with VAT category code E'),
			'VATEX-EU-IC' => array('reason' => 'Intra-Community supply', 'details' => 'Supports EN 16931-1 rule BR-IC-10 - Only use with VAT category code K'),
			'VATEX-EU-O' => array('reason' => 'Not subject to VAT', 'details' => 'Supports EN 16931-1 rule BR-O-10 - Only use with VAT category code O'),
			'VATEX-EU-J' => array('reason' => 'Intra-Community acquisition of collectors items and antiques', 'details' => 'Collectors\' items and antiques - Indication that the VAT margin scheme for collector’s items and antiques has been applied. - Only use with VAT category code E'),
			'VATEX-FR-FRANCHISE' => array('reason' => 'France domestic VAT franchise in base', 'details' => 'For domestic invoicing in France'),
			'VATEX-FR-CNWVAT' => array('reason' => 'France domestic Credit Notes without VAT, due to supplier forfeit of VAT for discount', 'details' => 'For domestic Credit Notes only in France'),
			'VATEX-EU-153' => array('reason' => 'Exempt based on article 153 of Council Directive 2006/112/EC', 'details' => ''),
			'VATEX-FR-CGI261-1' => array('reason' => 'Exempt based on 1 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261-2' => array('reason' => 'Exempt based on 2 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261-3' => array('reason' => 'Exempt based on 3 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261-4' => array('reason' => 'Exempt based on 4 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261-5' => array('reason' => 'Exempt based on 5 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261-7' => array('reason' => 'Exempt based on 7 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261-8' => array('reason' => 'Exempt based on 8 of article 261 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261A' => array('reason' => 'Exempt based on article 261 A of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261B' => array('reason' => 'Exempt based on article 261 B of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261C-1' => array('reason' => 'Exempt based on 1° of article 261 C of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261C-2' => array('reason' => 'Exempt based on 2° of article 261 C of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261C-3' => array('reason' => 'Exempt based on 3° of article 261 C of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261D-1' => array('reason' => 'Exempt based on 1° of article 261 D of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261D-1BIS' => array('reason' => 'Exempt based on 1°bis of article 261 D of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261D-2' => array('reason' => 'Exempt based on 2° of article 261 D of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261D-3' => array('reason' => 'Exempt based on 3° of article 261 D of the Code Général des Impôts (CGI ; General tax code) Exonération de TVA - Article 261 D-3° du Code Général des Impôts', 'details' => ''),
			'VATEX-FR-CGI261D-4' => array('reason' => 'Exempt based on 4° of article 261 D of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261E-1' => array('reason' => 'Exempt based on 1° of article 261 E of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI261E-2' => array('reason' => 'Exempt based on 2° of article 261 E of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI277A' => array('reason' => 'Exempt based on article 277 A of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI275' => array('reason' => 'Exempt based on article 275 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-298SEXDECIESA' => array('reason' => 'Exempt based on article 298 sexdecies A of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-CGI295' => array('reason' => 'Exempt based on article 295 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-FR-AE' => array('reason' => 'Exempt based on 2 of article 283 of the Code Général des Impôts (CGI ; General tax code)', 'details' => ''),
			'VATEX-EU-135-1' => array('reason' => 'Exempt based on article 135, section 1 of Council Directive 2006/112/EC', 'details' => ''),
		);

		$exemptionReason = null;		// BT-120
		$exemptionReasonCode = null;	// BT-121 - Must contain a VATEX code. https://docs.peppol.eu/poacc/billing/3.0/codelist/vatex/

		// A line carrying recoverable non-collected VAT (the overseas departments scheme of article 295 of
		// the CGI) states a VAT rate that is not collected. EN 16931 offers no way to declare a VAT that is
		// not claimed - BR-CO-15 makes the total with VAT the net total plus the VAT total - so the line is
		// issued exempt, with the VATEX reason code of that very article (issue #508).
		if (!empty($line->info_bits) && ((int) $line->info_bits & 1)) {
			$categoryVAT = 'E';
			if ($seller->country_code == 'FR') {
				$exemptionReasonCode = 'VATEX-FR-CGI295';
			} else {
				// The scheme is French; for any other seller there is no code to quote, and BR-E-10 is
				// satisfied by the reason text alone.
				$exemptionReason = 'VAT not collected';
			}
			$exemptionReason = $exemptionReason ?: ($VATEX_CODE_LIST[(string) $exemptionReasonCode]['reason'] ?? $exemptionReasonCode);

			return array('categoryVAT' => $categoryVAT, 'ExemptionReason' => $exemptionReason, 'ExemptionReasonCode' => $exemptionReasonCode);
		}

		// The VAT code the line carries (vat_src_code, the code column of the VAT dictionary) states the
		// regime the line is invoiced under, which is what BT-151 asks for. It is read here rather than
		// deduced from the rate, because a rate of zero covers Z, E, AE, G and K alike.
		// The category is the segment of the code before its first dash, so 'AE' and 'AE-IC' are both reverse
		// charge. A code that does not open on a category the module supports is left to the rules below.
		$declaredCategoryVAT = $this->_getVatCategoryFromVatCode($vat_src_code);

		if ($declaredCategoryVAT !== '' && $declaredCategoryVAT !== 'S') {
			// BR-AE-05, BR-E-05, BR-G-05, BR-K-05 and BR-Z-05: none of these categories is ever invoiced on a
			// taxed rate. A line stating one of them at a rate above zero contradicts its own dictionary entry,
			// and either of the two answers would build a document the Schematron refuses.
			if ((float) $vat_rate != 0) {
				throw new Exception('BADVATRATE[BR-'.$declaredCategoryVAT.'-05]: The VAT code \''.$vat_src_code.'\''.($id ? ' on line '.$id : '').' declares the VAT category '.$declaredCategoryVAT.', which EN 16931 only allows on a rate of 0, while the rate of the line is '.$vat_rate.'.');
			}

			$categoryVAT = $declaredCategoryVAT;

			if ($categoryVAT == 'Z') {
				// BR-Z-09 and BR-Z-10: a zero rated line is taxed, at zero, and must carry no exemption reason.
				return array('categoryVAT' => $categoryVAT, 'ExemptionReason' => null, 'ExemptionReasonCode' => null);
			}

			if ($categoryVAT == 'AE') {
				// BR-AE-02 and BR-AE-03: a reverse charge line names both parties, since the tax is declared by
				// the one that receives the supply. The seller answers with its VAT identifier (BT-31) or its tax
				// registration identifier (BT-32), the buyer with its VAT identifier (BT-48) or its legal
				// registration identifier (BT-47). Reporting it here names the record to complete; left to the
				// Schematron it comes back from the platform as a rejected document.
				$buyerThirdparty = empty($buyer->thirdparty) ? null : $buyer->thirdparty;	// @phpstan-ignore empty.property (Dolibarr 18 documents $thirdparty as always set, it stays empty until fetch_thirdparty())
				if (empty($seller->tva_intra) && empty($seller->idprof1)) {
					throw new Exception('BADVATNUMBER[BR-AE-02]: The VAT number or the professional id of the seller '.$seller->name.' is mandatory when a line is invoiced under the reverse charge (VAT category AE).');
				}
				if ($buyerThirdparty !== null && empty($buyerThirdparty->tva_intra) && empty(idprof($buyerThirdparty))) {
					throw new Exception('BADVATNUMBER[BR-AE-03]: The VAT number or the legal registration id of the customer '.$buyerThirdparty->name.' is mandatory when a line is invoiced under the reverse charge (VAT category AE).');
				}
			}

			$dictionaryEntry = $this->_getVatDictionaryEntry($vat_rate, $vat_src_code);

			// BT-120 is the note of the dictionary line, and nothing else: two regimes may share a category and
			// quote different articles - subcontracting in the building trade answers to article 283, 2 nonies
			// of the CGI where an intra-community supply answers to article 283-1 - and only the note of the
			// line the invoice actually used tells them apart. Hard coding it would state one for the other.
			$exemptionReason = $dictionaryEntry['note'];
			$exemptionReasonCode = $dictionaryEntry['einvoice_vatex'];

			if (empty($exemptionReasonCode)) {
				// Dolibarr 23 and below have no einvoice_vatex column in the dictionary; there the code is the
				// hidden constant the module already documents for the exempt lines.
				$exemptionReasonCode = strtoupper(getDolGlobalString('MAIN_VAT_EXEMPTION_CODE_FOR_'.price2num($vat_rate, 2).'_'.strtoupper($vat_src_code)));
			}
			if (empty($exemptionReasonCode)) {
				// The regime itself has a code in the VATEX list for AE, G and K, so those need no setup at all.
				// E has none: what exempts the line is the article it quotes, which only the dictionary knows.
				// A French seller quotes the French code of the reverse charge, which names the article the
				// mention on the invoice has to name - article 283 of the CGI - where VATEX-EU-AE only says
				// "reverse charge". Sellers of the other member states have that one and nothing more precise.
				$defaultVatexOfCategory = array(
					'AE' => 'VATEX-'.($seller->country_code == 'FR' ? 'FR' : 'EU').'-AE',
					'G' => 'VATEX-EU-G',
					'K' => 'VATEX-EU-IC',
				);
				$exemptionReasonCode = isset($defaultVatexOfCategory[$categoryVAT]) ? $defaultVatexOfCategory[$categoryVAT] : '';
			}

			if (empty($exemptionReason) && empty($exemptionReasonCode)) {
				// BR-AE-10, BR-E-10, BR-G-10 and BR-K-10 all ask for one of the two, and the module does not
				// invent either: it names the code it could not translate, as it does everywhere else.
				$langs->load("compta");
				$urltovatdic = DOL_URL_ROOT.'/admin/dict.php?id=10';
				$errormsg = $langs->trans("UnknownVATEX1", $id, '0', $vat_src_code);
				$errormsg .= '<br>'.$langs->trans("UnknownVATEX2b", '0', ($vat_src_code ? $vat_src_code : "''"), $urltovatdic, $langs->trans("VATExemptionCode"));

				throw new Exception('MISSINGSETUP: '.$errormsg);
			}

			// If we have a code but no reason, we try to find the reason in the list of VATEX codes, otherwise we use the code as reason.
			$exemptionReason = $exemptionReason ?: ($VATEX_CODE_LIST[(string) $exemptionReasonCode]['reason'] ?? $exemptionReasonCode);

			return array('categoryVAT' => $categoryVAT, 'ExemptionReason' => $exemptionReason, 'ExemptionReasonCode' => $exemptionReasonCode);
		}

		if ($vat_rate > 0) {
			$categoryVAT = 'S';

			if (empty($seller->tva_intra)) {
				// BR-S-02: a "Standard rated" line requires the Seller VAT identifier (BT-31). The test is
				// on the seller, so the message must name the seller - naming the customer sends the
				// operator looking for the missing number in the wrong record.
				throw new Exception('BADVATNUMBER[BR-S-02]: The VAT number of the seller ' . $seller->name . ' is mandatory when there is a non null VAT on at least one line.');
			}
			if (!$this->checkIfVatRateIsValid($vat_rate, $seller->country_code)) {
				throw new Exception('BADVATRATE[BR-FR-16]: The VAT rate ' . $vat_rate . ($id ? ' on line ' . $id : '') . ' is not a valid string value for country ' . $seller->country_code . '.');
			}
		} else {
			if ($seller->isInEEC()) {
				$categoryVAT = 'K';

				if (empty($seller->tva_assuj)) {
					// Can be $categoryVAT = E (VAT exempted) or AE (Autoliquidation)
					if (1 == 2) {	// Autoliquidation (the VAT is declared by the customer that pay it directly to the government). TODO Not implemented. @phan-suppress-current-line PhanPluginBothLiteralsBinaryOp
						// Note: the option ACCOUNTING_FORCE_ENABLE_VAT_REVERSE_CHARGE is for purchase invoices only and is used to dispatch vat differently in accounting..
						$categoryVAT = 'AE';	// Autoliquidation
						$exemptionReasonCode = 'VATEX-'.($seller->country_code == 'FR' ? 'FR' : 'EU').'-AE';	// VATEX-EU-AE or VATEX-FR-AE
						$exemptionReason = 'Autoliquidation';
					} else {
						$categoryVAT = 'E';		// Exempt from VAT (self-entrepreneurs, doctor, ...)
						$exemptionReasonCode = getDolGlobalString('MAIN_INFO_SOCIETE_VAT_EXEMPTION_CODE');
						$exemptionReason = getDolGlobalString('MAIN_INFO_SOCIETE_VAT_EXEMPTION_REASON');
						if ($seller->country_code == 'FR') {
							// List of VATEX: https://docs.peppol.eu/poacc/billing/3.0/codelist/vatex/
							// TVA non applicable article 293B CGI (auto-entrepreneurs, volume sous seuil, defined into setup of company):   VATEX-FR-FRANCHISE (rule BR-FR-CO-16), the default one
							$exemptionReasonCode = getDolGlobalString('MAIN_INFO_SOCIETE_VAT_EXEMPTION_CODE', 'VATEX-FR-FRANCHISE');		// VATEX-FR-FRANCHISE, VATEX-FR-CGI261-1, VATEX-FR-CGI261-4, VATEX-EU-79-C...
							$exemptionReason = getDolGlobalString('MAIN_INFO_SOCIETE_VAT_EXEMPTION_REASON', 'Tax exempted - TVA en franchise');
						}
						if (empty($exemptionReasonCode)) {
							if ((float) DOL_VERSION < 24.0) {
								throw new Exception('MISSINGSETUP: Your organization is configured to not use VAT. In this case, you must enter into the constant MAIN_INFO_SOCIETE_VAT_EXEMPTION_CODE the reason code of exemption (VATEX-FR-CGI261-1, VATEX-FR-CGI261-4, VATEX-EU-79C.');
							} else {
								throw new Exception('MISSINGSETUP: Your organization is configured to not use VAT. In this case, you must enter into the reason code of exemption in the setup of your organization (VATEX-FR-CGI261-1, VATEX-FR-CGI261-4, VATEX-EU-79C.');
							}
						}
					}
				} elseif (!$buyer->thirdparty->isInEEC()) {
					$this->assertSellerVatIdentifier($seller, 'BR-G-02', 'an exportation outside the EU');
					$categoryVAT = 'G';
					$exemptionReasonCode = 'VATEX-EU-G';
					$exemptionReason = 'Exportation outside UE';
				} elseif ($buyer->thirdparty->isInEEC() && $seller->country_code != $buyer->thirdparty->country_code) {
					$this->assertSellerVatIdentifier($seller, 'BR-IC-02', 'an intracommunity supply');
					$categoryVAT = 'K';		// Intra communautary VAT
					$exemptionReasonCode = 'VATEX-EU-IC';
					$exemptionReason = 'Intracommunautary VAT';
				} else {
					$categoryVAT = 'E';		// Exempt from VAT (product).

					// The sell is from an EU country to the same country, reason depends on the product line itself (reason saved into the VAT rate/code used)
					if ((float) DOL_VERSION < 24.0) {
						// We must use the reason found in the constant MAIN_VAT_EXEMPTION_CODE_FOR_0.00_XXXX
						// List of VATEX: https://docs.peppol.eu/poacc/billing/3.0/codelist/vatex/
						// TVA non applicable: article 261-4 CGI (comme médecin) VATEX-FR-CGI261-4, vente art VATEX-FR-I,
						// vente antiquité VATEX-FR-J, vente agence voyage VATEX-EU-D,
						// debours (VAT paid by customer) VATEX-EU-79-C
						$vatex = '';

						// We try to find code in the vat code definition in the dictionary table (code only because einvoice_vatex does not exists).
						global $db, $mysoc;

						$sql = "SELECT code FROM ".MAIN_DB_PREFIX."c_tva";
						$sql .= " WHERE taux = ".((float) $vat_rate);
						$sql .= " AND active = 1";
						$sql .= " AND fk_pays = ".((int) $mysoc->country_id);
						$sql .= $this->_getVatDictionaryEntityFilter();
						$sql .= " AND (code = '".$db->escape($vat_src_code)."')";
						$resql = $db->query($sql);
						if ($resql) {
							$obj = $db->fetch_object($resql);
							if ($obj) {
								if (preg_match('/^VATEX/i', $obj->code)) {
									$vatex = strtoupper((string) $obj->code);
								}
							}
						}

						$vat_rate = price2num($vat_rate, 2);
						$constantforvatex = '';

						if (empty($vatex)) {
							$constantforvatex = "MAIN_VAT_EXEMPTION_CODE_FOR_" . $vat_rate.($vat_src_code ? "_". $vat_src_code : '');
							$vatex = strtoupper(getDolGlobalString($constantforvatex));
						}

						if (empty($vatex)) {
							// Say where the constant is entered: its name alone sends the administrator looking for a
							// setup page that does not exist for it (it is a hidden constant, only Home - Setup - Other).
							$urltoconstsetup = DOL_URL_ROOT.'/admin/const.php';
							$errormsg = $langs->trans("UnknownVATEX1", $id, '0', $vat_src_code);
							$errormsg .= '<br>'.$langs->trans("UnknownVATEX2a", '0', ($vat_src_code ? $vat_src_code : "''"), $constantforvatex, $urltoconstsetup);
							//$exemptionReason .= ' '.$langs->trans("ClickHere", $constantforvatex);		// Go on other setup page

							throw new Exception('MISSINGSETUP: '.$errormsg);
						} else {
							$exemptionReasonCode = $vatex;
							$exemptionReason = '';
						}
					} else {
						$vatex = '';

						// We try to find code in the vat code definition in the dictionary table (einvoice_vatex else code).
						global $db, $mysoc;

						$sql = "SELECT code, einvoice_vatex FROM ".MAIN_DB_PREFIX."c_tva";
						$sql .= " WHERE taux = ".((float) $vat_rate);
						$sql .= " AND active = 1";
						$sql .= " AND fk_pays = ".((int) $mysoc->country_id);
						$sql .= $this->_getVatDictionaryEntityFilter();
						$sql .= " AND (code = '".$db->escape($vat_src_code)."')";
						$resql = $db->query($sql);
						if ($resql) {
							$obj = $db->fetch_object($resql);
							if ($obj) {
								$vatex = strtoupper((string) $obj->einvoice_vatex);
								if (empty($vatex) && preg_match('/^VATEX/i', $obj->code)) {
									$vatex = strtoupper((string) $obj->code);
								}
							}
						}

						if (empty($vatex)) {
							// The dictionary has a lot of columns: name the one to fill, and name it with the label of
							// the core so the administrator reads on screen the same words as in the message.
							$langs->load("compta");
							$urltovatdic = DOL_URL_ROOT.'/admin/dict.php?id=10';
							$errormsg = $langs->trans("UnknownVATEX1", $id, '0', $vat_src_code);
							$errormsg .= '<br>'.$langs->trans("UnknownVATEX2b", '0', ($vat_src_code ? $vat_src_code : "''"), $urltovatdic, $langs->trans("VATExemptionCode"));
							//$errormsg .= ' '.$langs->trans("ClickHere", $constantforvatex);		// Go on dictionary page

							throw new Exception('MISSINGSETUP: '.$errormsg);
						} else {
							$exemptionReasonCode = $vatex;
							$exemptionReason = '';
							// The dictionary entry can say the operation is outside the scope of VAT rather than
							// exempt from it (CGI art. 258 for a supply of goods located abroad, for instance).
							// "E" would announce a taxable operation that a rule exempts, which is another claim.
							$imposedCategory = $this->vatCategoryForExemptionCode($vatex);
							if ($imposedCategory !== '') {
								$categoryVAT = $imposedCategory;
							}
						}
					}
				}
			} else {
				$categoryVAT = 'Z';		// Seller is not in EU
			}
		}

		// If we have a code but no reason, we try to find the reason in the list of VATEX codes, otherwise we use the code as reason.
		$exemptionReason = $exemptionReason ?: ($VATEX_CODE_LIST[(string) $exemptionReasonCode]['reason'] ?? $exemptionReasonCode);

		return array('categoryVAT' => $categoryVAT, 'ExemptionReason' => $exemptionReason, 'ExemptionReasonCode' => $exemptionReasonCode);
	}

	/**
	 * Read the EN 16931 VAT category the VAT code of a line declares.
	 *
	 * The category is the segment of the code before its first dash. That is a convention of the data,
	 * not a guess about it: a dictionary that needs to tell apart two regimes sharing one category names
	 * them 'AE' and 'AE-IC', and both are answered reverse charge without a line of code being written
	 * for the second one.
	 *
	 * @param	string	$vat_src_code	Code of the VAT dictionary line the invoice line was built with
	 * @return	string					VAT category of EN 16931 (BT-151), '' when the code declares none
	 */
	private function _getVatCategoryFromVatCode($vat_src_code)
	{
		// The categories of UNTDID 5305 this generator issues documents for. L and M (Canary Islands, Ceuta
		// and Melilla) and O (outside the scope of VAT) are left out on purpose: each answers to rules of
		// its own that the rest of the document does not honour yet, so a code opening on one of them is
		// not taken at its word and keeps going through the rules that follow.
		$supportedCategories = array('S', 'Z', 'E', 'AE', 'K', 'G');

		$code = strtoupper(trim((string) $vat_src_code));
		if ($code === '') {
			return '';
		}

		$dash = strpos($code, '-');
		$category = ($dash === false ? $code : substr($code, 0, $dash));

		return in_array($category, $supportedCategories, true) ? $category : '';
	}

	/**
	 * Build the entity restriction of a read of the VAT dictionary table.
	 *
	 * The dictionary is per entity and the core reads it with "AND t.entity IN (getEntity('c_tva'))"
	 * (getTaxesFromId(), htdocs/core/lib/functions.lib.php); without it the exemption reason (BT-121)
	 * can be the one another entity declared. The column only exists from Dolibarr 19: the core of 18
	 * reads llx_c_tva with no entity clause at all.
	 *
	 * @return	string		SQL clause to append to the WHERE, '' on Dolibarr 18
	 */
	private function _getVatDictionaryEntityFilter()
	{
		if ((float) DOL_VERSION < 19.0) {
			return '';
		}

		return " AND entity IN (".getEntity('c_tva').")";
	}

	/**
	 * Read the VAT dictionary line a rate and a code point to.
	 *
	 * @param	float|string	$vat_rate		VAT rate of the invoice line
	 * @param	string			$vat_src_code	Code of the VAT dictionary line the invoice line was built with
	 * @return	array{note:string,einvoice_vatex:string}	Empty strings when the dictionary holds no such line
	 */
	private function _getVatDictionaryEntry($vat_rate, $vat_src_code)
	{
		global $db, $mysoc;

		$entry = array('note' => '', 'einvoice_vatex' => '');

		// The column holding the VATEX code of a dictionary line appeared with Dolibarr 24. Below that
		// version the note is all the dictionary has to say about the line.
		$hasVatexColumn = ((float) DOL_VERSION >= 24.0);

		$sql = "SELECT note".($hasVatexColumn ? ", einvoice_vatex" : "")." FROM ".MAIN_DB_PREFIX."c_tva";
		$sql .= " WHERE taux = ".((float) $vat_rate);
		$sql .= " AND active = 1";
		$sql .= " AND fk_pays = ".((int) $mysoc->country_id);
		$sql .= $this->_getVatDictionaryEntityFilter();
		$sql .= " AND code = '".$db->escape($vat_src_code)."'";
		$sql .= " LIMIT 1";

		$resql = $db->query($sql);
		if ($resql) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				$entry['note'] = trim((string) $obj->note);
				$entry['einvoice_vatex'] = ($hasVatexColumn ? strtoupper(trim((string) $obj->einvoice_vatex)) : '');
			}
		}

		return $entry;
	}



	/**
	 *    Check line type from external module ?
	 *
	 * @param  object $line       line we work on
	 * @param  string $searchName module name we look for
	 * @return boolean                        true if the line is a special one and was created by the module we ask for
	 ************************************************/
	private function _isLineFromExternalModule($line, $searchName)
	{
		if ((int) $line->product_type != 9) {
			return false;
		}
		// Legacy: line created by the given external module, matched on its special_code.
		if ($line->special_code == $this->_getModNumber($searchName)) {
			return true;
		}
		// The title / subtotal feature is now part of the Dolibarr core (htdocs/subtotals, trait
		// CommonSubtotal with $PRODUCT_TYPE = 9 and special_code = SUBTOTALS_SPECIAL_CODE). Such lines
		// no longer carry the legacy modSubtotal module number, but any product_type 9 line is a
		// title / subtotal / page-break pseudo-line, so we treat them all as subtotal lines.
		return $searchName == 'modSubtotal';
	}

	/**
	 * Find module number
	 *
	 * @param  string 	$modName 	Module name we look for
	 * @return integer              -1 if KO, 0 not found or module number if Ok
	 */
	private function _getModNumber($modName)
	{
		global $db;
		if (class_exists($modName)) {
			$objMod = new $modName($db);
			return $objMod->numero;
		}
		return 0;
	}


	/**
	 * Keep the order reference the supplier declared on the invoice it sent (BT-13) on the created
	 * supplier invoice, whether or not it matched a purchase order of Dolibarr.
	 *
	 * Auto-linking only happens on an exact, unambiguous match for that supplier; on every other case
	 * the reference would be dropped. Stored into the table of the module and not into an extrafield of
	 * the core, which a user could rename or delete. Never blocking.
	 *
	 * @param FactureFournisseur	$supplierInvoice	Supplier invoice created by the import
	 * @param string				$orderReference		Order reference declared by the supplier (BT-13)
	 * @return void
	 */
	private function _saveImportedBuyerOrderReference($supplierInvoice, $orderReference)
	{
		global $db;

		$orderReference = trim((string) $orderReference);
		if ($orderReference === '' || empty($supplierInvoice->id)) {
			return;
		}

		$einvoicing = new EInvoicing($db);
		$res = $einvoicing->insertOrUpdateExtraField($supplierInvoice->id, $supplierInvoice->element, EInvoicing::EXTRAFIELD_BUYER_ORDER_REFERENCE, $orderReference);
		if ($res < 0) {
			dol_syslog(get_class($this) . '::_saveImportedBuyerOrderReference Failed to store the order reference "' . $orderReference . '" of supplier invoice ' . ((int) $supplierInvoice->id) . ': ' . implode(', ', $einvoicing->errors), LOG_ERR);
		}
	}

	/**
	 * Link an inbound supplier invoice to its Dolibarr purchase order (commande fournisseur).
	 *
	 * Uses BT-13 (BuyerOrderReferencedDocument/IssuerAssignedID). The lookup is reference-exact and
	 * scoped to the resolved supplier, and only a single unambiguous match creates the link. Internal
	 * ERP reconciliation logic: it must NEVER block import (issue #303).
	 *
	 * @param 	FactureFournisseur 	$supplierInvoice 	Freshly created supplier invoice (must expose ->id)
	 * @param 	int 				$socId 				Resolved supplier third party id
	 * @param 	string 				$orderReference 	BT-13 purchase order reference carried by the invoice
	 * @return 	string 									Status message for the import log ('' when nothing was done)
	 */
	private function _linkSupplierInvoiceToPurchaseOrder($supplierInvoice, $socId, $orderReference)
	{
		global $db, $langs;

		$orderReference = trim((string) $orderReference);
		if ($orderReference === '' || empty($supplierInvoice->id) || (int) $socId <= 0) {
			return '';
		}

		require_once DOL_DOCUMENT_ROOT . '/fourn/class/fournisseur.commande.class.php';

		// Reference-exact, supplier-scoped, entity-aware lookup to avoid false positives
		$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "commande_fournisseur";
		$sql .= " WHERE ref = '" . $db->escape($orderReference) . "'";
		$sql .= " AND fk_soc = " . ((int) $socId);
		$sql .= " AND entity IN (" . getEntity('supplier_order') . ")";

		$resql = $db->query($sql);
		if (!$resql) {
			dol_syslog(get_class($this) . '::_linkSupplierInvoiceToPurchaseOrder DB error: ' . $db->lasterror(), LOG_ERR);
			return '';
		}

		$num = $db->num_rows($resql);

		if ($num == 0) {
			// No order for this supplier. Surface a warning only if the reference exists for another supplier
			// (likely mis-reference), otherwise stay silent (unchanged behaviour).
			$sqlOther = "SELECT rowid FROM " . MAIN_DB_PREFIX . "commande_fournisseur";
			$sqlOther .= " WHERE ref = '" . $db->escape($orderReference) . "'";
			$sqlOther .= " AND fk_soc <> " . ((int) $socId);
			$sqlOther .= " AND entity IN (" . getEntity('supplier_order') . ")";
			$resqlOther = $db->query($sqlOther);
			if ($resqlOther && $db->num_rows($resqlOther) > 0) {
				$warn = $langs->trans('EInvoiceSupplierOrderRefWrongSupplier', $orderReference);
				dol_syslog(get_class($this) . '::_linkSupplierInvoiceToPurchaseOrder ' . $warn, LOG_WARNING);
				setEventMessages($warn, null, 'warnings');
				return $warn;
			}
			dol_syslog(get_class($this) . '::_linkSupplierInvoiceToPurchaseOrder No supplier order "' . $orderReference . '" for socid ' . ((int) $socId), LOG_DEBUG);
			return '';
		}

		if ($num > 1) {
			// Ambiguous: do not auto-link, flag for manual resolution
			$warn = $langs->trans('EInvoiceSupplierOrderLinkAmbiguous', $orderReference);
			dol_syslog(get_class($this) . '::_linkSupplierInvoiceToPurchaseOrder ' . $warn, LOG_WARNING);
			setEventMessages($warn, null, 'warnings');
			return $warn;
		}

		$orderId = (int) $db->fetch_object($resql)->rowid;

		$res = $supplierInvoice->add_object_linked('order_supplier', $orderId);
		if ($res > 0) {
			$msg = $langs->trans('EInvoiceSupplierInvoiceLinkedToOrder', $orderReference);
			dol_syslog(get_class($this) . '::_linkSupplierInvoiceToPurchaseOrder ' . $msg, LOG_DEBUG);

			// Propagate extrafields from the purchase order to the supplier invoice.
			// Only empty fields on the invoice are filled: values already set by the import are kept.
			// insertExtraFields() silently ignores keys that are not defined for facture_fourn.
			$order = new CommandeFournisseur($db);
			if ($order->fetch($orderId) > 0) {
				$order->fetch_optionals();
				if (!empty($order->array_options)) {
					$supplierInvoice->fetch_optionals();
					$changed = false;
					foreach ($order->array_options as $key => $value) {
						if (isset($value) && $value !== '' && (!isset($supplierInvoice->array_options[$key]) || $supplierInvoice->array_options[$key] === '')) {
							$supplierInvoice->array_options[$key] = $value;
							$changed = true;
						}
					}
					if ($changed) {
						$supplierInvoice->insertExtraFields();
					}
				}
			}

			return $msg;
		}

		dol_syslog(get_class($this) . '::_linkSupplierInvoiceToPurchaseOrder Failed to link order ' . $orderId . ' to invoice ' . $supplierInvoice->id . ': ' . $supplierInvoice->error, LOG_ERR);
		return '';
	}

	/**
	 * Map of UNTDID 4461 payment means codes (BT-81, ram:TypeCode under
	 * SpecifiedTradeSettlementPaymentMeans) to Dolibarr's paiement.code.
	 * @var array<int|'ZZZ',string>
	 */
	private static $UNTDID4461_TO_DOLIBARR_PAIEMENT_CODE = [
		'10' => 'LIQ',	// Cash
		'20' => 'CHQ',	// Check
		'21' => 'CHQ',	// Banker's draft
		'22' => 'CHQ',	// Certified banker's draft
		'23' => 'TRA',	// Banque check
		'24' => 'TRA',	// Bill of exchange awaiting acceptance
		'25' => 'CHQ',	// Certified cheque
		'26' => 'CHQ',	// Local cheque
		'30' => 'VIR',	// Bank transfer
		'31' => 'VIR',	// Debit transfer, a transfer within a giro system network
		'42' => 'VIR',	// Payment to bank account
		'45' => 'TIP',	// Referenced home-banking credit transfer
		'48' => 'CB',	// Bank card, the generic code most senders use rather than 54
		'49' => 'PRE',	// Direct debit, the generic code most senders use rather than 59
		'54' => 'CB',	// Credit card
		'55' => 'CB',	// Debit card, the dictionary of Dolibarr has one code for both cards
		'58' => 'VIR',	// SEPA credit transfer, which BR-49/BR-50 put on a par with 30
		'59' => 'PRE',	// SEPA direct debit
		'68' => 'VAD',	// Online payment
		'70' => 'LCR',	// Bill drawn by the creditor on the debtor, the French LCR
		'1' => 'FAC',	// local payment method | not defined
	];

	/**
	 * Fill Payment due on (date_echeance), Payment Terms (cond_reglement_id) and
	 * Payment method (mode_reglement_id) on a Dolibarr supplier invoice from data parsed
	 * out of a received CII/Factur-X document.
	 *
	 * @param  FactureFournisseur 	$supplierInvoice 	Supplier invoice being built (modified by reference)
	 * @param  array 				$parsedHeader 		Parsed CII header data (see CIIProtocol::parseInvoiceHeader())
	 * @return array{message:string} 					Informational messages about what could/could not be applied (never blocking)
	 */
	private function _applyPaymentInfoToSupplierInvoice(FactureFournisseur $supplierInvoice, array $parsedHeader)
	{
		global $db;

		$messages = array();

		//------------------------
		// Payment due on (BT-9)
		//------------------------
		$dueDate = null;
		if (!empty($parsedHeader['paymentDueDate'])) {
			$dueDateTimestamp = dol_stringtotime($parsedHeader['paymentDueDate'], 'tzserver');
			if ($dueDateTimestamp) {
				$dueDate = $dueDateTimestamp;
				$supplierInvoice->date_echeance = $dueDate;
			} else {
				$messages[] = 'Payment due date "' . $parsedHeader['paymentDueDate'] . '" could not be parsed, left empty.';
			}
		}

		//---------------------------------------------------------------
		// Payment Terms (derived from Invoice date <-> Payment due on)
		//---------------------------------------------------------------
		if ($dueDate && !empty($supplierInvoice->date)) {
			$invoiceDateTimestamp = is_numeric($supplierInvoice->date) ? $supplierInvoice->date : dol_stringtotime((string) $supplierInvoice->date, 'tzserver');

			if ($invoiceDateTimestamp) {
				$nbDays = (int) round(($dueDate - $invoiceDateTimestamp) / 86400);

				if ($nbDays >= 0) {
					// The dictionary is per entity (llx_c_payment_term.entity, unique key on entity+code), so the
					// term must be looked for in the entities the current one may read, the way the core reads
					// that same table (Form::load_cache_conditions_paiement(), CommonInvoice::calculate_date_lim_reglement()).
					$entities = getEntity('c_payment_term'); // for the log line below only, see the WHERE clause

					$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "c_payment_term";
					// getEntity() is called inline rather than through the variable above on purpose: the SQL
					// plugin of phan rejects any variable interpolated into a query, however safe its origin
					$sql .= " WHERE entity IN (" . getEntity('c_payment_term') . ")";
					$sql .= " AND nbjour = " . ((int) $nbDays);
					$sql .= " AND type_cdr = 0"; // fixed number of days only (no end of month)
					$sql .= " AND active = 1";
					$sql .= " ORDER BY rowid ASC"; // deterministic pick if duplicates
					$sql .= " LIMIT 1";

					dol_syslog(get_class($this) . '::_applyPaymentInfoToSupplierInvoice Looking for a payment term of ' . $nbDays . ' day(s) in entity ' . $entities, LOG_DEBUG);
					$resql = $db->query($sql);
					if ($resql && $db->num_rows($resql) == 1) {
						$obj = $db->fetch_object($resql);
						$supplierInvoice->cond_reglement_id = (int) $obj->rowid;
						$messages[] = 'Payment Terms matched dictionary entry for ' . $nbDays . ' day(s).';
					} else {
						$messages[] = 'No matching Payment Terms dictionary entry found for ' . $nbDays . ' day(s) between invoice date and due date, left empty.';
					}
				} else {
					$messages[] = 'Payment due date is before invoice date, cannot derive Payment Terms, left empty.';
				}
			}
		}

		//-------------------------------------
		// Payment method (BT-81, UNTDID 4461)
		// ------------------------------------
		if (!empty($parsedHeader['paymentMeansCode'])) {
			$untdidCode = trim((string) $parsedHeader['paymentMeansCode']);

			if (isset(self::$UNTDID4461_TO_DOLIBARR_PAIEMENT_CODE[$untdidCode])) {
				$dolibarrPaymentCode = self::$UNTDID4461_TO_DOLIBARR_PAIEMENT_CODE[$untdidCode];

				// Read the dictionary through the core helper: it applies the multicompany filter and caches the
				// lookup. The extra filter keeps the "active entries only" behaviour and is a hardcoded literal,
				// never anything coming from the document. Only 7 arguments: the 8th ($useCache) does not exist
				// on Dolibarr 19.
				$paymentModeId = (int) dol_getIdFromCode($db, $dolibarrPaymentCode, 'c_paiement', 'code', 'id', 1, " AND active = 1");

				if ($paymentModeId > 0) {
					$supplierInvoice->mode_reglement_id = $paymentModeId;
					$messages[] = 'Payment method mapped from UNTDID 4461 code ' . $untdidCode . ' to Dolibarr code ' . $dolibarrPaymentCode . '.';
				} else {
					dol_syslog('CommonProtocol::_applyPaymentInfoToSupplierInvoice no active c_paiement entry with code ' . $dolibarrPaymentCode . ' for the current entity', LOG_NOTICE);
					$messages[] = 'Payment method code ' . $dolibarrPaymentCode . ' (from UNTDID 4461 code ' . $untdidCode . ') not found or not active in Dolibarr dictionary, left empty.';
				}
			} else {
				$messages[] = 'UNTDID 4461 payment means code ' . $untdidCode . ' has no known Dolibarr mapping, left empty.';
			}
		}

		return array('message' => implode("<br>\n", $messages));
	}
}
