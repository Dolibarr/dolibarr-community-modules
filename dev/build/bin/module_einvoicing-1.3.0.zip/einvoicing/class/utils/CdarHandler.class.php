<?php
/* Copyright (C) 2025       Laurent Destailleur         <eldy@users.sourceforge.net>
 * Copyright (C) 2025       Mohamed DAOUD               <mdaoud@dolicloud.com>
 * Copyright (C) 2026       Frédéric France             <frederic.france@free.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    einvoicing/class/utils/CdarHandler.class.php
 * \ingroup einvoicing
 * \brief   CDAR (Cross Domain Acknowledgement and Response) Handler
 */

require_once __DIR__ . '/../../lib/einvoicing.lib.php';	// removeAllSpaces(), used to normalize an electronic address
require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';	// @phpstan-ignore requireOnce.fileNotFound (PHPStan takes DOL_DOCUMENT_ROOT from install/inc.php of the core, where it is '..')


/**
 * CdarHandler
 */
class CdarHandler
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;

	/**
	 * @var string Reason of the last failure, when a method returns false or a negative result.
	 */
	public $error = '';

	// ==================== CONSTANTS ====================

	// DateTime Formats
	const FORMAT_DATETIME = '204'; // YYYYMMDDHHmmss
	const FORMAT_DATE = '102';     // YYYYMMDD

	// Acknowledgement Type Codes
	const ACK_ACKNOWLEDGEMENT = '305';
	const ACK_REJECTION = '304';
	const ACK_ACCEPTANCE = '302';

	// Length MDT-4 (the id of the message) is given in the PPF profile of XP Z12-012
	const ID_MAX_LENGTH = 50;

	// Document Type Codes
	const DOC_INVOICE = '380';
	const DOC_CREDIT_NOTE = '381';
	const DOC_CORRECTIVE_INVOICE = '384';
	const DOC_DEBIT_NOTE = '383';
	const DOC_PREPAYMENT_INVOICE = '386';

	// Process Condition Codes
	const PROC_DEPOSITED = '200';
	const PROC_ISSUED = '201';
	const PROC_RECEIVED = '202';
	const PROC_AVAILABLE = '203';
	const PROC_TAKEN_OVER = '204';
	const PROC_APPROVED = '205';
	const PROC_PARTIALLY_APPROVED = '206';
	const PROC_DISPUTED = '207';
	const PROC_SUSPENDED = '208';
	const PROC_COMPLETED = '209';
	const PROC_REFUSED = '210';
	const PROC_PAYMENT_TRANSMITTED = '211';
	const PROC_PAID = '212';
	const PROC_REJECTED = '213';

	// Role Codes
	const ROLE_WK = 'WK'; // Platform
	const ROLE_SE = 'SE'; // Seller
	const ROLE_BY = 'BY'; // Buyer
	const ROLE_CN = 'CN'; // Consignee
	const ROLE_DP = 'DP'; // Delivery point

	// Scheme IDs
	const SCHEME_SIREN_0225 = '0225';
	const SCHEME_SIREN_0002 = '0002';

	// MDT-97: what kind of object the lifecycle message is about (rule G7.14 of XP Z12-012).
	// A status sent by this module always refers to an invoice of the e-invoicing circuit; the
	// other values of the rule cover a flow, regulatory data, an e-reporting transmission, the
	// directory, and a status about a status.
	const REFERENCE_TYPE_EINVOICE = 'urn.cpro.gouv.fr:1p0:CDV:einvoicingF2';

	// Status Codes
	const STATUS_ACCEPTED = '1';
	const STATUS_REJECTED = '8';
	const STATUS_RECEIVED = '43';
	const STATUS_IN_PROCESS = '45';
	const STATUS_PAID = '47';
	const STATUS_ACKNOWLEDGED = '48';
	const STATUS_DEPOSITED = '10';

	/**
	 * Document status code (MDT-88) that goes with a lifecycle status (MDT-105), as read from the
	 * XP Z12-012 annex B reference examples. The lifecycle statuses those examples do not cover
	 * (refusal, dispute, suspension...) keep the historical "in process", which the platforms accept.
	 */
	const STATUS_CODE_PER_PROCESS_CONDITION = [
		self::PROC_DEPOSITED           => self::STATUS_DEPOSITED,
		self::PROC_RECEIVED            => self::STATUS_RECEIVED,
		self::PROC_AVAILABLE           => self::STATUS_ACKNOWLEDGED,
		self::PROC_TAKEN_OVER          => self::STATUS_IN_PROCESS,
		self::PROC_APPROVED            => self::STATUS_ACCEPTED,
		self::PROC_PAYMENT_TRANSMITTED => self::STATUS_PAID,
		self::PROC_PAID                => self::STATUS_PAID,
	];

	// XML Namespaces
	private $namespaces = [
		'rsm' => 'urn:un:unece:uncefact:data:standard:CrossDomainAcknowledgementAndResponse:100',
		'ram' => 'urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100',
		'udt' => 'urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100',
		'qdt' => 'urn:un:unece:uncefact:data:standard:QualifiedDataType:100'
	];

	/**
	 * Constructor
	 *
	 * @param DoliDB $db handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * readFromFile
	 *
	 * @param  string $xmlFile xml file
	 * @return array{GuidelineID:string,ExchangedDocument:array,AcknowledgementDocument:array}
	 */
	public function readFromFile($xmlFile)
	{
		if (!file_exists($xmlFile)) {
			throw new Exception("XML file does not exist: $xmlFile");
		}
		return $this->readFromString(file_get_contents($xmlFile));
	}

	/**
	 * @var string	Electronic address (MDT-73) the last CDAR was addressed to
	 */
	public $recipientURIID = '';

	/**
	 * @var string	Where that address came from: 'routing' (recorded in Dolibarr), 'einvoice' (BT-34 of
	 *				the document received), 'directory' (access point directory), 'thirdpartyid' or
	 *				'issuerid' (fallen back on an identifier of the vendor)
	 */
	public $recipientURIIDOrigin = '';

	/**
	 * @var string EAS scheme (MDT-73-1) declared for the address above, as chosen by generateCdarFile()
	 */
	public $recipientURISchemeID = self::SCHEME_SIREN_0225;

	/**
	 * readFromString
	 *
	 * @param  string $xmlString xml string
	 * @return array{GuidelineID:string,ExchangedDocument:array,AcknowledgementDocument:array}
	 */
	public function readFromString($xmlString)
	{
		$xml = simplexml_load_string($xmlString);
		if ($xml === false) {
			throw new Exception("Error parsing XML string");
		}

		foreach ($this->namespaces as $prefix => $uri) {
			$xml->registerXPathNamespace($prefix, $uri);
		}

		$GuidelineID = $this->getXpathValue($xml, '//ram:GuidelineSpecifiedDocumentContextParameter/ram:ID');
		$ExchangedDocument = $this->parseExchangedDocument($xml);
		$AcknowledgementDocument = $this->parseAcknowledgementDocument($xml);

		return [
			'GuidelineID' => $GuidelineID,
			'ExchangedDocument' => $ExchangedDocument,
			'AcknowledgementDocument' => $AcknowledgementDocument
		];
	}

	/**
	 * generate
	 *
	 * Values coming from the data are escaped with einvoicingXmlText() before they reach
	 * DOMDocument::createElement(), which parses its second argument: an ampersand in a free text
	 * (a rejection reason, a party name) would otherwise produce an empty element and lose the
	 * information - same defect as issue #695 on the invoice side.
	 *
	 * @param  array $data array of data
	 *
	 * @return string|false
	 */
	public function generate($data)
	{
		$dom = new DOMDocument('1.0', 'UTF-8');
		$dom->formatOutput = true;
		$dom->standalone = true;
		$dom->xmlStandalone = true;

		$root = $this->createRootElement($dom);

		// Same stamp as the invoice XML (CIIProtocol::buildXML()): a lifecycle answer received by a
		// partner says which Dolibarr and which module build wrote it, otherwise a malformed CDAR
		// can only be traced back by asking the sender.
		$textforcomment = 'CDAR XML generated by';
		$textforcomment .= ' Dolibarr ' . DOL_VERSION;
		$textforcomment .= ' Einvoicing ' . einvoicingModuleStamp();
		$textforcomment .= ' - ' . dol_print_date(dol_now('gmt'), 'dayhourrfc', 'gmt');
		$root->appendChild($dom->createComment($textforcomment));

		$this->addContext($dom, $root, $data['GuidelineID']);
		$this->addExchangedDocument($dom, $root, $data['ExchangedDocument']);
		$this->addAcknowledgementDocument($dom, $root, $data['AcknowledgementDocument']);

		return $dom->saveXML();
	}

	/**
	 * saveToFile
	 *
	 * @param  array $data array of data
	 * @param  string $filename filename
	 * @return bool
	 */
	public function saveToFile($data, $filename)
	{
		$this->error = '';

		$xmlContent = $this->generate($data);
		if ($xmlContent === false) {
			$this->error = 'Failed to build the CDAR XML content';
			return false;
		}

		// Report the write that did not happen, and the one that stopped halfway on a full disk. Without
		// this, the file is simply missing or truncated further down the road, and the caller can only
		// say the file does not exist, which points at the wrong cause.
		$written = file_put_contents($filename, $xmlContent);
		if ($written === false || $written < strlen($xmlContent)) {
			$this->error = 'Failed to write the CDAR file ' . $filename;
			return false;
		}

		return true;
	}

	/**
	 * Generate a CDAR file
	 *
	 * @param Facture|FactureFournisseur    $object       Invoice object (CustomerInvoice or SupplierInvoice)
	 * @param int                           $statusCode     Status code to send
	 * @param string                        $reasonCode Reason code to send (optional)
	 * @param array{amount?:float,breakdown?:array<array{vatrate:float,amount:float}>,reason?:string}  $paymentData  Amount (TTC, in the company currency) moved for status 212, negative on a refund, with an optional ready-made breakdown by VAT rate and the reason of the cancellation (MDT-126)
	 *
	 * @return  array{res:int<-1,1>, message:string, file?:string}   Returns array with 'res' (1 on success, -1 on failure) with a 'message' and 'file' with the path.
	 */
	public function generateCdarFile($object, $statusCode, $reasonCode = '', $paymentData = array())
	{
		global $conf, $mysoc;

		/**
		* CDARs must be generated manually, with the minimum number of mandatory blocks; more blocks
		* will be added based on PDP feedback. We start by processing the following cases:
		* - Rejection (210) - mandatory in the case of a rejection (The only mandatory status for now)
		* - Acceptance (204) - optional => Implemented ; Acceptance (205) - optional
		* - Payment transmitted (212) - optional but recommended
		*/

		// MDT-91 is the BT-3 of the document the status is about: a cash-out is reported on the credit
		// note the money was refunded on, which the platform holds as a 381, not as a 380.
		$referencedDocTypeCode = ($statusCode == CdarHandler::PROC_PAID)
			? $this->getReferencedDocumentTypeCode($object)
			: CdarHandler::DOC_INVOICE;	// TODO: map DOC_INVOICE with $object type on the supplier invoice statuses too

		// Id format {StatusCode}_{CreationDate}#{DocType}_{CreationDate}_{SupplierRef}: same parts as the
		// documentation, the reference last. MDT-4 names THIS message - a lifecycle message about another
		// one designates it by that id - and the PPF profile caps the field at 50 characters, so the only
		// part of variable length is the one the cap eats into, and the document carries the reference
		// whole in MDT-87 anyway.
		// 'tzserver' and not the 'auto' default: 'auto' resolves to $conf->tzuserinputkey, which the
		// MAIN_TZUSERINPUTKEY constant can switch to 'tzuserrel', and the id would then follow the
		// timezone of whoever triggers the send instead of the server one.
		$issueDateTime = CdarHandler::getCurrentDateTime();
		// Dated by the moment of the message, milliseconds included: two statuses recorded on the same
		// invoice within the same second - a bank import, a mass payment - would otherwise share the id.
		$now = microtime(true);
		$messageStamp = $issueDateTime . sprintf('%03d', (int) (($now - floor($now)) * 1000));
		$reference = (string) ($statusCode == CdarHandler::PROC_PAID ? $object->ref : $object->ref_supplier);
		$ID = $statusCode . '_' . $messageStamp . '#' . $referencedDocTypeCode . '_' . dol_print_date((int) $object->date_creation, '%Y%m%d', 'tzserver') . '_' . $reference;
		$ID = dol_trunc($ID, CdarHandler::ID_MAX_LENGTH, 'right', 'UTF-8', 1);

		// We use same as ID for Name as its not required to be different
		$Name = $ID;

		// 212 (Encaissee) is the only status sent on one of OUR OWN invoices: we are then the seller and the
		// CDAR goes to our customer, every other status is sent on a supplier invoice where we are the buyer.
		// Swapping the two makes the platform answer "no matching invoices found" (XP Z12-012 annex B, UC1).
		$isOurOwnInvoice = ($statusCode == CdarHandler::PROC_PAID);

		// SIREN (0002)
		$mysocGlobalID = idprof($mysoc);

		// Issuer SIREN (0002) of the invoice the status is about: us when we sell, the vendor otherwise.
		// For a received supplier invoice, the platform indexed the flow under the identifier the vendor's
		// PDP placed in SellerTradeParty.GlobalID, which may differ from the Dolibarr third-party SIREN.
		// Reading it from the stored XML is the only reliable way to reference the same invoice. The same
		// parse also yields the vendor's address (BT-34), used below for MDT-73 when no routing is recorded.
		$vendorIdentity = array('globalid' => '', 'uriid' => '');
		if ($isOurOwnInvoice) {
			$InvoiceIssuerGlobalID = $mysocGlobalID;
		} else {
			// fetch_thirdparty() populates $object->thirdparty, which the MDT-73 routing ladder below
			// requires. thirdpartyidprof() used to provide this side effect unconditionally; now that it
			// only runs as a fallback, the call must be explicit so the ladder is never skipped on a
			// null thirdparty (e.g. automatic 211 from PaiementFourn::create(), where fetch() nulls it
			// and setPaid() triggers the status before anyone fetches it back).
			$object->fetch_thirdparty();
			$vendorIdentity = $this->getVendorIdentityFromReceivedInvoice($object);
			$InvoiceIssuerGlobalID = $vendorIdentity['globalid'];
			if ($InvoiceIssuerGlobalID === '') {
				$InvoiceIssuerGlobalID = thirdpartyidprof($object);
				dol_syslog(__METHOD__ . ' no GlobalID found in stored XML for supplier invoice id=' . $object->id . ', falling back on Dolibarr third-party SIREN: ' . $InvoiceIssuerGlobalID, LOG_DEBUG);
			}
		}

		// Invoice reference
		$IssuerAssignedID = $isOurOwnInvoice
			? $object->ref
			: $object->ref_supplier;

		/**
		 * MDT-88
		 * Note: the lifecycle statuses with no reference example still fall back on "in process":
		 * 39 (on hold) = Suspendue
		 * 37 (Complete) = Complétée
		 * 50 (Rejected / Refused) = Refusée (by C4)
		 * 49 (Conditionally accepted) = Approuvée Partiellement
		 * 46 (Under Query) = En litige
		 */
		// The keys of the map are numeric strings, which PHP stores as integer array keys
		$StatusCodeCdar = CdarHandler::STATUS_CODE_PER_PROCESS_CONDITION[(int) $statusCode] ?? CdarHandler::STATUS_IN_PROCESS;

		// Label for ProcessCondition (Label of status code) we get it from class einvoicing
		dol_include_once('/einvoicing/class/providers/PDPProviderManager.class.php');
		$einvoicing = new EInvoicing($this->db);
		$ProcessCondition = $einvoicing->getStatusLabel($statusCode);
		$ProcessCondition = str_replace(' ', '_', dol_string_unaccent($ProcessCondition));
		$ProcessCondition = preg_replace('/[^A-Za-z0-9_]/', '', $ProcessCondition); // Clean special chars

		// Electronic address (MDT-73) of the CDAR recipient - the vendor, for every status but the cash-in
		// (212). Its SIREN only works when the platform knows the vendor under that address, and gets the
		// message refused with "Electronic address (MDT-73) is invalid" otherwise.
		// Reply-to address, in order: routing recorded in Dolibarr, BT-34 of the received e-invoice, directory,
		// then getBuyerCommunicationURI() on the third party alone (its override reads element_type='facture').
		$RecipientURIID = $InvoiceIssuerGlobalID;
		$RecipientURISchemeID = CdarHandler::SCHEME_SIREN_0225;
		$this->recipientURIIDOrigin = 'issuerid';
		if ($statusCode != 212 && $object->thirdparty instanceof Societe) {
			$vendorRouting = $einvoicing->fetchDefaultRouting($object->thirdparty->id);
			$vendorURIID = ($vendorRouting > 0) ? removeAllSpaces((string) $vendorRouting) : '';	// 0 when none is recorded, -1 on error

			if ($vendorURIID !== '') {
				$this->recipientURIIDOrigin = 'routing';
			}

			if ($vendorURIID === '') {
				$vendorURIID = removeAllSpaces($vendorIdentity['uriid']);
				if ($vendorURIID !== '') {
					$this->recipientURIIDOrigin = 'einvoice';
					// MDT-73-1 is the EAS scheme of the address actually used, not a constant: the vendor
					// published this one on its invoice (BT-34) together with its scheme, and re-labelling
					// it as a national directory address (0225) would describe it wrongly. Every other rung
					// does take an address of the national directory, so 0225 stays right for them.
					if ($vendorIdentity['urischeme'] !== '') {
						$RecipientURISchemeID = $vendorIdentity['urischeme'];
					}
					dol_syslog(__METHOD__ . ' no routing ID recorded for vendor SIREN ' . $InvoiceIssuerGlobalID . ', replying to the electronic address of the invoice it sent us: ' . $vendorURIID, LOG_NOTICE);
				}
			}

			if ($vendorURIID === '' && $InvoiceIssuerGlobalID !== '') {
				// checkRecipientDirectory() returns the first active reception address declared for that
				// SIREN, and degrades to an empty identifier on the providers that expose no directory.
				$PDPManager = new PDPProviderManager($this->db);
				$provider = $PDPManager->getProvider(getDolGlobalString('EINVOICING_PDP'));
				if (is_object($provider)) {
					$directory = $provider->checkRecipientDirectory($InvoiceIssuerGlobalID);
					if (!empty($directory['identifier'])) {
						$vendorURIID = removeAllSpaces($directory['identifier']);
						$this->recipientURIIDOrigin = 'directory';
						dol_syslog(__METHOD__ . ' nothing known about how to reach vendor SIREN ' . $InvoiceIssuerGlobalID . ', using the address the directory declares for it: ' . $vendorURIID, LOG_NOTICE);
					} else {
						dol_syslog(__METHOD__ . ' nothing known about how to reach vendor SIREN ' . $InvoiceIssuerGlobalID . ' and the directory returned none (' . $directory['status'] . '), falling back on the SIREN as electronic address: the platform will refuse the status if it does not know the vendor under that address', LOG_WARNING);
					}
				}
			}

			if ($vendorURIID === '') {
				$vendorURIID = $einvoicing->getBuyerCommunicationURI($object->thirdparty);
				if ($vendorURIID !== '') {
					$this->recipientURIIDOrigin = 'thirdpartyid';
				}
			}

			if ($vendorURIID !== '') {	// Empty with EINVOICING_BLOCK_INVOICE_NO_ROUTING_ID and no routing: keep the SIREN, an empty MDT-73 is worse
				$RecipientURIID = $vendorURIID;
			} else {
				$this->recipientURIIDOrigin = 'issuerid';
			}
		}
		// The platform answers "Electronic address (MDT-73) is invalid" when it does not know the vendor
		// under the address chosen above, and its message names neither the vendor nor the address. Keep
		// both so the caller can say which one was tried and where it came from: without that, a received
		// invoice that can be neither approved nor refused - and therefore not deleted - leaves the user
		// with nothing to act on.
		$this->recipientURIID = $RecipientURIID;
		$this->recipientURISchemeID = $RecipientURISchemeID;

		// MDG-43 blocks. Rule BR-FR-CDV-14: a "Encaissee" status (212) must carry at least one block with
		// MDT-207 = MEN, and every MEN block must hold both an amount (MDT-215) and a VAT rate (MDT-224).
		// Without them the platform rejects the CDAR with a 400.
		$SpecifiedDocumentStatus = array();
		if (!empty($reasonCode)) {
			$SpecifiedDocumentStatus['ReasonCode'] = $reasonCode;
			//$SpecifiedDocumentStatus['Reason'] = 'Taux de TVA erroné';
		}
		if ($statusCode == CdarHandler::PROC_PAID) {
			$cashedAmounts = $this->getCashedAmountCharacteristics($object, $paymentData);
			if (empty($cashedAmounts)) {
				// Better to fail here than to have the platform reject the CDAR on BR-FR-CDV-14.
				return array('res' => -1, 'message' => 'Cannot compute the cashed amount (MEN) per VAT rate for invoice ' . $object->ref);
			}
			$SpecifiedDocumentStatus['SpecifiedDocumentCharacteristic'] = $cashedAmounts;

			// Rule P1.17: a cash-out states why the cash-in is being cancelled, in the note (MDT-126).
			if ((float) $cashedAmounts[0]['ValueAmount'] < 0) {
				$reason = isset($paymentData['reason']) ? trim((string) $paymentData['reason']) : '';
				$SpecifiedDocumentStatus['IncludedNoteContent'] = ($reason !== '') ? $reason : 'Refund of ' . $object->ref;
			}
		} elseif ($statusCode == CdarHandler::PROC_PAYMENT_TRANSMITTED) {
			// "Paiement transmis" tells the vendor what was paid and when (MDG-43 block MDT-207 = MPA).
			// No rule makes it mandatory, so a status with no known amount is still sent, just bare.
			$paidAmounts = $this->getPaymentSentCharacteristics($object, $paymentData);
			if (!empty($paidAmounts)) {
				$SpecifiedDocumentStatus['SpecifiedDocumentCharacteristic'] = $paidAmounts;
			}
		}
		if (!empty($SpecifiedDocumentStatus)) {
			// Rule BR-FR-CDV-16: any status detail block must be numbered (MDT-124-2). Only one block is sent.
			$SpecifiedDocumentStatus['SequenceNumeric'] = 1;
		}

		if ($isOurOwnInvoice) {
			// We issue the status as the SELLER, and it is addressed to the buyer of the invoice
			$CdarIssuerTradeParty = [
				'GlobalID' => $mysocGlobalID,
				'SchemeID' => CdarHandler::SCHEME_SIREN_0002,
				'RoleCode' => CdarHandler::ROLE_SE
			];

			$buyerGlobalID = thirdpartyidprof($object);
			$buyerURIID = $einvoicing->getBuyerCommunicationURI($object->thirdparty, $object);
			$CdarRecipientTradeParty = [
				'GlobalID'     => $buyerGlobalID,
				'SchemeID'     => CdarHandler::SCHEME_SIREN_0002,
				'RoleCode'     => CdarHandler::ROLE_BY,
				'URIID'        => $buyerURIID !== '' ? $buyerURIID : $buyerGlobalID,
				'URISchemeID'  => CdarHandler::SCHEME_SIREN_0225
			];
		} else {
			// We issue the status as the BUYER of a supplier invoice, and it goes back to the vendor
			$CdarIssuerTradeParty = [
				'GlobalID'  => $mysocGlobalID, // GlobalID of CDAR SENDER
				'SchemeID'  => CdarHandler::SCHEME_SIREN_0002,
				'RoleCode'  => CdarHandler::ROLE_BY
			];

			$CdarRecipientTradeParty = [
				'GlobalID'     => $InvoiceIssuerGlobalID, // GlobalID of CDAR RECIPIENT
				'SchemeID'     => CdarHandler::SCHEME_SIREN_0002,
				'RoleCode'     => CdarHandler::ROLE_SE,
				'URIID'        => $RecipientURIID,	// The routing of the vendor, its SIREN when none is recorded
				'URISchemeID'  => $RecipientURISchemeID
			];
		}

		$data = [
			'GuidelineID' => 'urn.cpro.gouv.fr:1p0:CDV:invoice',

			'ExchangedDocument' => [
				'ID' => $ID,
				'Name' => $Name,
				'IssueDateTime' => $issueDateTime,

				'SenderTradeParty' => [
					'RoleCode' => CdarHandler::ROLE_WK
				],

				'IssuerTradeParty' => $CdarIssuerTradeParty,

				'RecipientTradeParty' => $CdarRecipientTradeParty
			],

			'AcknowledgementDocument' => [
				'MultipleReferencesIndicator' => false,
				'TypeCode' => '23',
				'IssueDateTime' => $issueDateTime,

				'ReferenceReferencedDocument' => [
					'IssuerAssignedID' => $IssuerAssignedID,
					'StatusCode' => $StatusCodeCdar,
					'TypeCode' => $referencedDocTypeCode,
					// MDT-97, mandatory in the CTC-FR profile: it says what the lifecycle message is about
					'ReferenceTypeCode' => CdarHandler::REFERENCE_TYPE_EINVOICE,
					// Every XP Z12-012 reference example dates the referenced invoice with a plain date
					'FormattedIssueDateTime' => dol_print_date((int) $object->date, '%Y%m%d', 'tzserver'),
					'ProcessConditionCode' => $statusCode,
					'ProcessCondition' => $ProcessCondition,

					'SpecifiedDocumentStatus' => $SpecifiedDocumentStatus,

					'IssuerTradeParty' => [
						'GlobalID' => $InvoiceIssuerGlobalID, // GlobalID of invoice sender (Supplier)
						'SchemeID' => CdarHandler::SCHEME_SIREN_0002,
						'RoleCode' => CdarHandler::ROLE_SE
					]
				]
			]
		];

		$tempDir = $conf->einvoicing->dir_temp;
		if (!dol_is_dir($tempDir)) {
			dol_mkdir($tempDir, einvoicingDataRoot($tempDir));
			if (!dol_is_dir($tempDir)) {
				return array('res' => -1, 'message' => 'The temporary directory of the module cannot be created: ' . $tempDir);
			}
		}
		// A directory the web server may enter but not write into is a plausible state (it happens when a
		// command line script running as another user creates it first). Name it here, where the cause is
		// still visible, rather than let the write fail silently.
		if (!is_writable($tempDir)) {
			return array('res' => -1, 'message' => 'The temporary directory of the module is not writable by the web server: ' . $tempDir);
		}

		// Unique per-call name so two concurrent status sends of the same condition cannot collide (#226).
		$baseName = strtolower(dol_sanitizePathName(dol_string_unaccent('cdar_' . $ProcessCondition . '_' . bin2hex(random_bytes(8)) . '.xml')));
		$filename = $tempDir . '/' . $baseName;

		$result = $this->saveToFile($data, $filename);
		if ($result === false) {
			return array('res' => -1, 'message' => $this->error !== '' ? $this->error : 'Error saving CDAR file');
		}
		//echo "CDAR file generated: " . $filename;

		return array('res' => 1, 'message' => 'CDAR file generated successfully', 'file' => $filename);
	}

	/**
	 * Build the MDG-43 "paid amount" (MPA) block of a status 211 (Paiement transmis) CDAR.
	 *
	 * That status tells the vendor of a supplier invoice that its payment has been sent: the block holds
	 * how much was paid (MDT-215) and when (MDT-217), as in the XP Z12-012 annex B example. Unlike the
	 * cash-in, no rule makes it mandatory, hence an empty return when no amount is known.
	 *
	 * @param  FactureFournisseur|Facture $object      Invoice that has been paid
	 * @param  array{amount?:float,date?:int}          $paymentData Amount paid (TTC, company currency) and its date as a timestamp. Both default to the payments recorded on the invoice.
	 * @return array<array{TypeCode:string,ValueAmount:string,CurrencyID:string,ValueDateTime:string}>  MPA block, empty if no amount is known
	 */
	public function getPaymentSentCharacteristics($object, $paymentData = array())
	{
		global $conf;

		$paidAmount = isset($paymentData['amount']) ? (float) $paymentData['amount'] : 0.0;
		if (empty($paidAmount) && method_exists($object, 'getSommePaiement')) {
			$paidAmount = (float) $object->getSommePaiement();
		}
		if ($paidAmount <= 0) {
			dol_syslog(__METHOD__ . ' No paid amount found for invoice id=' . $object->id, LOG_WARNING, 0, '_einvoicing');
			return array();
		}

		$paidDate = empty($paymentData['date']) ? dol_now() : $paymentData['date'];

		return array(
			array(
				'TypeCode' => 'MPA',
				'ValueAmount' => number_format($paidAmount, 2, '.', ''),
				'CurrencyID' => $conf->currency,
				// 'tzserver' like the other dates read from the invoice, and not the 'auto' default:
				// the day the payment was made must not follow the timezone of whoever sends the status.
				'ValueDateTime' => dol_print_date($paidDate, '%Y%m%d', 'tzserver')
			)
		);
	}

	/**
	 * What the e-invoice we received says about its vendor: the legal identifier it issued under
	 * (BT-29, or BT-30 when the former is absent) and the electronic address it exchanges from (BT-34).
	 *
	 * The globalid is used as InvoiceIssuerGlobalID in the CDAR so the status references the invoice
	 * under the same identifier the platform indexed it — which may differ from the Dolibarr third-party
	 * SIREN in legitimate cases: test environments where the PDP assigns synthetic identifiers that
	 * Dolibarr's own validation would reject as input, or a vendor that sends via one PDP and receives
	 * via another (its sending routing address differs from its receiving one, and cannot be derived
	 * from the third-party card alone). Fallback to the card SIREN when the XML carries nothing.
	 *
	 * The uriid is the natural reply-to address when no routing is recorded for that vendor in Dolibarr.
	 *
	 * Read from the e-invoice stored with the supplier invoice, never by calling the platform back:
	 * addressing a status is no reason for a network round trip, and an invoice keyed by hand has none.
	 * A single parse serves both values, since a CDAR always needs the two together.
	 *
	 * @param  FactureFournisseur $object  Supplier invoice the status is sent on
	 * @return array{globalid:string,uriid:string,urischeme:string}  Empty strings when there is no stored
	 *                                              e-invoice, when it is unparsable, or when it carries no
	 *                                              such field. 'urischeme' is the EAS scheme the document
	 *                                              declares on that address (MDT-73-1 of the CDAR).
	 */
	private function getVendorIdentityFromReceivedInvoice($object)
	{
		$identity = array('globalid' => '', 'uriid' => '', 'urischeme' => '');

		if (empty($object->id) || $object->element !== 'invoice_supplier') {
			return $identity;
		}

		dol_include_once('/einvoicing/class/utils/SupplierInvoiceHelper.class.php');

		$xmlData = '';
		try {
			// false: an invoice with no e-invoice stored is a normal case (keyed by hand), and addressing
			// a status is no reason to call the platform back.
			$xmlData = (string) SupplierInvoiceHelper::getXmlData((int) $object->id, false);
		} catch (Exception $e) {
			dol_syslog(__METHOD__ . ' no e-invoice stored for supplier invoice id ' . $object->id . ': ' . $e->getMessage(), LOG_DEBUG);
			return $identity;
		}
		if ($xmlData === '') {
			return $identity;
		}

		$xml = @simplexml_load_string($xmlData);
		if ($xml === false) {
			dol_syslog(__METHOD__ . ' the e-invoice stored for supplier invoice id ' . $object->id . ' is not parsable XML', LOG_WARNING);
			return $identity;
		}

		// Only ram: is needed — the same read works on a CII and on the XML extracted from a Factur-X
		$xml->registerXPathNamespace('ram', 'urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100');

		// BT-29: GlobalID[@schemeID="0002"] is the SIREN in the French mandate
		$found = $xml->xpath('//ram:SellerTradeParty/ram:GlobalID[@schemeID="0002"]');
		if (!empty($found)) {
			$identity['globalid'] = removeAllSpaces((string) $found[0]);
		} else {
			// BT-30: SpecifiedLegalOrganization/ID[@schemeID="0002"] — legal registration number.
			// The schemeID guard is required: without it a SIRET (0009), a GLN (0088), or a foreign
			// registration number would be shipped to the platform declared as a SIREN.
			$found = $xml->xpath('//ram:SellerTradeParty/ram:SpecifiedLegalOrganization/ram:ID[@schemeID="0002"]');
			if (!empty($found)) {
				$identity['globalid'] = removeAllSpaces((string) $found[0]);
			}
		}

		$found = $xml->xpath('//ram:SellerTradeParty/ram:URIUniversalCommunication/ram:URIID');
		if (!empty($found)) {
			$identity['uriid'] = trim((string) $found[0]);
			// The scheme comes with the address: MDT-73-1 has to declare the address for what the vendor
			// published it as, and a vendor reachable under its SIREN (0002) is not a national directory
			// address (0225). Kept only when the document actually carries one.
			$scheme = (string) ($found[0]->attributes()->schemeID ?? '');
			$identity['urischeme'] = trim($scheme);
		}

		return $identity;
	}

	/**
	 * Document type code (MDT-91, the BT-3 of the document the status is about) of one of our own invoices.
	 *
	 * @param  Facture|FactureFournisseur $object Invoice, credit note or deposit the status is about
	 * @return string                             Document type code, 380 for a commercial invoice
	 */
	private function getReferencedDocumentTypeCode($object)
	{
		$codes = array(
			CommonInvoice::TYPE_CREDIT_NOTE => CdarHandler::DOC_CREDIT_NOTE,
			CommonInvoice::TYPE_REPLACEMENT => CdarHandler::DOC_CORRECTIVE_INVOICE,
			CommonInvoice::TYPE_DEPOSIT => CdarHandler::DOC_PREPAYMENT_INVOICE,
		);

		return isset($codes[(int) $object->type]) ? $codes[(int) $object->type] : CdarHandler::DOC_INVOICE;
	}

	/**
	 * Build the MDG-43 "cashed amount" (MEN) blocks of a status 212 (Encaissee) CDAR.
	 *
	 * One block per VAT rate, holding the TTC amount (MDT-215) and the rate itself (MDT-224). Dolibarr only
	 * records a payment as a single TTC amount, so it is spread over the VAT rates proportionally to their
	 * TTC weight; rounding differences go to the largest block, so the blocks always sum up to the amount.
	 * A refund is a cash-out: it is reported the same way, with negative amounts (rule P1.15).
	 *
	 * @param  Facture|FactureFournisseur $object       Invoice the payment belongs to
	 * @param  array{amount?:float,breakdown?:array<array{vatrate:float,amount:float}>,reason?:string}  $paymentData  Amount (TTC, company currency) moved, negative on a refund, and/or a ready-made breakdown. Defaults to the sum of the payments of the invoice.
	 * @return array<array{TypeCode:string,ValueAmount:string,CurrencyID:string,ValuePercent:string}>  MEN blocks, empty if they cannot be computed
	 */
	public function getCashedAmountCharacteristics($object, $paymentData = array())
	{
		global $conf;

		$breakdown = array();

		if (!empty($paymentData['breakdown'])) {
			$breakdown = $paymentData['breakdown'];
		} else {
			$cashedAmount = isset($paymentData['amount']) ? (float) $paymentData['amount'] : 0.0;
			if (empty($cashedAmount) && method_exists($object, 'getSommePaiement')) {
				$cashedAmount = (float) $object->getSommePaiement();
			}
			if (empty($cashedAmount)) {
				dol_syslog(__METHOD__ . ' No cashed amount found for invoice id=' . $object->id, LOG_WARNING, 0, '_einvoicing');
				return array();
			}

			if (empty($object->lines)) {
				$object->fetch_lines();
			}

			// TTC weight of each VAT rate, on absolute values: a credit note holds its lines negative
			// while the amount refunded carries the direction of the money on its own (rule P1.15).
			$totalPerRate = array();
			foreach ($object->lines as $line) {
				$rate = (string) price2num($line->tva_tx, 'MU');
				if (!isset($totalPerRate[$rate])) {
					$totalPerRate[$rate] = 0.0;
				}
				$totalPerRate[$rate] += abs((float) $line->total_ttc);
			}

			$totalTtc = array_sum($totalPerRate);
			if (empty($totalTtc)) {
				dol_syslog(__METHOD__ . ' Cannot split the cashed amount, invoice id=' . $object->id . ' has no TTC total', LOG_WARNING, 0, '_einvoicing');
				return array();
			}

			$ratio = $cashedAmount / $totalTtc;
			$rounded = 0.0;
			$biggest = null;
			foreach ($totalPerRate as $rate => $amountTtc) {
				$amount = (float) price2num($amountTtc * $ratio, 'MT');
				$rounded += $amount;
				$breakdown[$rate] = array('vatrate' => (float) $rate, 'amount' => $amount);
				if (is_null($biggest) || abs($amount) > abs($breakdown[$biggest]['amount'])) {
					$biggest = $rate;
				}
			}

			// Keep the sum of the blocks equal to what was really cashed
			$residual = (float) price2num($cashedAmount - $rounded, 'MT');
			if (!empty($residual) && !is_null($biggest)) {
				$breakdown[$biggest]['amount'] = (float) price2num($breakdown[$biggest]['amount'] + $residual, 'MT');
			}
		}

		$characteristics = array();
		foreach ($breakdown as $entry) {
			if (empty($entry['amount'])) {	// A rate that cashed nothing brings no information
				continue;
			}
			$characteristics[] = array(
				'TypeCode' => 'MEN',
				'ValueAmount' => number_format((float) $entry['amount'], 2, '.', ''),
				'CurrencyID' => $conf->currency,
				'ValuePercent' => number_format((float) $entry['vatrate'], 2, '.', '')
			);
		}

		return $characteristics;
	}


	// ==================== UTILITY METHODS ====================

	/**
	 * formatDateTime
	 *
	 * Kept on plain substr() on purpose: this is a pass-through formatter, anything that is not
	 * exactly 14 digits comes back untouched. dol_stringtotime() strips every non-digit and pads
	 * the result with '000000', so it cannot give that pass-through back, and it would also
	 * normalize a 14-digit string that is not a real date (a DST gap hour, or '99999999999999').
	 *
	 * @param  string $dateTimeStr datetime
	 *
	 * @return string
	 */
	public static function formatDateTime($dateTimeStr)
	{
		return strlen($dateTimeStr) === 14
			? substr($dateTimeStr, 0, 4) . '-' . substr($dateTimeStr, 4, 2) . '-' .
			  substr($dateTimeStr, 6, 2) . ' ' . substr($dateTimeStr, 8, 2) . ':' .
			  substr($dateTimeStr, 10, 2) . ':' . substr($dateTimeStr, 12, 2)
			: $dateTimeStr;
	}

	/**
	 * formatDate
	 *
	 * Same reason as formatDateTime(): a pass-through formatter the core date helpers cannot
	 * reproduce, so it stays on substr().
	 *
	 * @param  string $dateStr date
	 *
	 * @return string
	 */
	public static function formatDate($dateStr)
	{
		return strlen($dateStr) === 8
			? substr($dateStr, 0, 4) . '-' . substr($dateStr, 4, 2) . '-' . substr($dateStr, 6, 2)
			: $dateStr;
	}

	/**
	 * getCurrentDateTime
	 *
	 * @return string
	 */
	public static function getCurrentDateTime()
	{
		// 'gmt' and not 'tzserver': unlike the dates read from the invoice, which DoliDB::jdate()
		// hands back in the server timezone, this one is an instant, not a calendar date, and it
		// travels between platforms. UTC is the safe convention for it.
		// The limit, so that the next reader does not believe the matter settled: format 204
		// (YYYYMMDDHHmmss) carries no offset, so writing UTC does not DECLARE UTC to the
		// recipient. The code that would carry it is 2379, which the library does not implement.
		// See generateCdarFile() for why the 'auto' default is never used in this class.
		return dol_print_date(dol_now('gmt'), '%Y%m%d%H%M%S', 'gmt');
	}

	/**
	 * getCurrentDate
	 *
	 * @return string
	 */
	public static function getCurrentDate()
	{
		// Same instant, same UTC choice and same limit as getCurrentDateTime().
		return dol_print_date(dol_now('gmt'), '%Y%m%d', 'gmt');
	}

	// ==================== PRIVATE HELPERS ====================

	/**
	 * Register the known CDAR namespaces on the given element so that prefixed
	 * XPath queries resolve. Must be done on every element (root AND sub-nodes
	 * returned by xpath()), otherwise libxml raises "Undefined namespace prefix"
	 * and the query silently returns false.
	 *
	 * @param  SimpleXMLElement $xml xml element
	 * @return SimpleXMLElement       same element, for chaining
	 */
	private function registerNamespaces($xml)
	{
		if ($xml instanceof SimpleXMLElement) {
			foreach ($this->namespaces as $prefix => $uri) {
				$xml->registerXPathNamespace($prefix, $uri);
			}
		}
		return $xml;
	}

	/**
	 * getXpathValue
	 *
	 * @param  SimpleXmlElement $xml xml
	 * @param  string $path path
	 * @param  string $default default
	 * @return string
	 */
	private function getXpathValue($xml, $path, $default = '')
	{
		$this->registerNamespaces($xml);
		$result = $xml->xpath($path);

		return !empty($result) ? (string) $result[0] : $default;
	}

	/**
	 * getXpathAttribute
	 *
	 * @param  SimpleXmlElement $xml xml
	 * @param  string $path path
	 * @param  string $attribute attribute
	 * @param  string $default default
	 * @return string
	 */
	private function getXpathAttribute($xml, $path, $attribute, $default = '')
	{
		$this->registerNamespaces($xml);
		$result = $xml->xpath($path);

		return !empty($result) ? (string) $result[0][$attribute] : $default;
	}

	/**
	 * createRootElement
	 *
	 * @param  DOMDocument $dom dom
	 *
	 * @return DOMElement|false
	 */
	private function createRootElement($dom)
	{
		$root = $dom->createElement('rsm:CrossDomainAcknowledgementAndResponse');
		$root->setAttribute('xmlns:rsm', $this->namespaces['rsm']);
		$root->setAttribute('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance');
		$root->setAttribute('xmlns:qdt', $this->namespaces['qdt']);
		$root->setAttribute('xmlns:ram', $this->namespaces['ram']);
		$root->setAttribute('xmlns:udt', $this->namespaces['udt']);
		$dom->appendChild($root);

		return $root;
	}

	/**
	 * addContext
	 *
	 * @param  DOMDocument $dom dom
	 * @param  mixed $root root
	 * @param  mixed $guidelineID guideline id
	 * @return void
	 */
	private function addContext($dom, $root, $guidelineID)
	{
		$context = $dom->createElement('rsm:ExchangedDocumentContext');

		$process = $dom->createElement('ram:BusinessProcessSpecifiedDocumentContextParameter');
		$process->appendChild($dom->createElement('ram:ID', 'REGULATED'));
		$context->appendChild($process);

		$guideline = $dom->createElement('ram:GuidelineSpecifiedDocumentContextParameter');
		$guideline->appendChild($dom->createElement('ram:ID', einvoicingXmlText((string) $guidelineID)));
		$context->appendChild($guideline);
		$root->appendChild($context);
	}

	/**
	 * addDateTimeElement
	 *
	 * @param  DOMDocument $dom dom
	 * @param  DOMElement $parent parent
	 * @param  string $elementName element name
	 * @param  string $value value
	 * @param  string $format format
	 * @return void
	 */
	private function addDateTimeElement($dom, $parent, $elementName, $value, $format)
	{
		$element = $dom->createElement($elementName);
		$dateTimeStr = $dom->createElement('udt:DateTimeString', einvoicingXmlText((string) $value));
		$dateTimeStr->setAttribute('format', $format);
		$element->appendChild($dateTimeStr);
		$parent->appendChild($element);
	}

	/**
	 * addTradeParty
	 *
	 * @param  DOMDocument $dom dom
	 * @param  DOMElement $parent parent
	 * @param  string $elementName element name
	 * @param  array $data data
	 * @return void
	 */
	private function addTradeParty($dom, $parent, $elementName, $data)
	{
		$party = $dom->createElement($elementName);

		if (isset($data['GlobalID'])) {
			$globalID = $dom->createElement('ram:GlobalID', einvoicingXmlText((string) $data['GlobalID']));
			if (!empty($data['SchemeID'])) {
				$globalID->setAttribute('schemeID', $data['SchemeID']);
			}
			$party->appendChild($globalID);
		}

		$party->appendChild($dom->createElement('ram:RoleCode', einvoicingXmlText((string) $data['RoleCode'])));

		if (isset($data['URIID'])) {
			$uriComm = $dom->createElement('ram:URIUniversalCommunication');
			$uriID = $dom->createElement('ram:URIID', einvoicingXmlText((string) $data['URIID']));
			$uriID->setAttribute('schemeID', $data['URISchemeID']);
			$uriComm->appendChild($uriID);
			$party->appendChild($uriComm);
		}

		$parent->appendChild($party);
	}

	// ==================== PARSING ====================

	/**
	 * parseExchangedDocument
	 *
	 * @param  SimpleXmlElement $xml xml
	 * @return array<string,string|array<string,string>|array<int,array<string,string>>>
	 */
	private function parseExchangedDocument($xml)
	{
		return [
			'ID' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:ID'),
			'Name' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:Name'),
			'IssueDateTime' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:IssueDateTime/udt:DateTimeString'),
			'SenderTradeParty' => [
				'RoleCode' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:SenderTradeParty/ram:RoleCode')
			],
			'IssuerTradeParty' => [
				'RoleCode' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:IssuerTradeParty/ram:RoleCode')
			],
			'RecipientTradeParty' => [
				'GlobalID' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:RecipientTradeParty/ram:GlobalID'),
				'SchemeID' => $this->getXpathAttribute($xml, '//rsm:ExchangedDocument/ram:RecipientTradeParty/ram:GlobalID', 'schemeID'),
				'RoleCode' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:RecipientTradeParty/ram:RoleCode'),
				'URIID' => $this->getXpathValue($xml, '//rsm:ExchangedDocument/ram:RecipientTradeParty/ram:URIUniversalCommunication/ram:URIID'),
				'URISchemeID' => $this->getXpathAttribute($xml, '//rsm:ExchangedDocument/ram:RecipientTradeParty/ram:URIUniversalCommunication/ram:URIID', 'schemeID')
			],
			// The key above keeps the FIRST recipient, which is all the callers reading it need. A
			// lifecycle message may address several, and which ones is what tells a rejection posted
			// at emission from one posted at reception (issue #973), so keep the whole list too.
			'RecipientTradeParties' => $this->parseRecipientTradeParties($xml)
		];
	}

	/**
	 * Every ExchangedDocument/RecipientTradeParty of a CDAR, in document order.
	 *
	 * XP Z12-012 annex A, sheet "Acteurs CDV", gives a status one recipient per audience: a rejection
	 * posted at emission is addressed to the seller alone, one posted at reception to the seller AND
	 * the buyer. Nothing else in a 213 says which platform posted it - issuer and sender are both the
	 * generic "WK" with an empty identifier on the documents seen so far.
	 *
	 * @param  SimpleXMLElement $xml	CDAR with the namespaces registered
	 * @return array<int,array{GlobalID:string,SchemeID:string,RoleCode:string,Name:string}>
	 */
	private function parseRecipientTradeParties($xml)
	{
		$parties = array();

		$nodes = $this->registerNamespaces($xml)->xpath('//rsm:ExchangedDocument/ram:RecipientTradeParty');
		if (empty($nodes)) {
			return $parties;
		}

		foreach ($nodes as $node) {
			$parties[] = array(
				'GlobalID' => $this->getXpathValue($node, 'ram:GlobalID'),
				'SchemeID' => $this->getXpathAttribute($node, 'ram:GlobalID', 'schemeID'),
				'RoleCode' => $this->getXpathValue($node, 'ram:RoleCode'),
				'Name' => $this->getXpathValue($node, 'ram:Name')
			);
		}

		return $parties;
	}

	/**
	 * The RoleCodes of the recipients above, comma separated, as stored on a lifecycle message
	 * (llx_einvoicing_lifecycle_msg.lc_recipient_roles): "SE", "SE,BY"...
	 *
	 * @param  array<string,mixed> $cdarDocument	Result of readFromString()
	 * @return string								Empty when the CDAR names no recipient
	 */
	public static function recipientRoles($cdarDocument)
	{
		$parties = $cdarDocument['ExchangedDocument']['RecipientTradeParties'] ?? array();
		if (!is_array($parties)) {
			return '';
		}

		$roles = array();
		foreach ($parties as $party) {
			$role = trim((string) ($party['RoleCode'] ?? ''));
			if ($role !== '' && !in_array($role, $roles, true)) {
				$roles[] = $role;
			}
		}

		return implode(',', $roles);
	}

	/**
	 * parseAcknowledgementDocument
	 *
	 * @param  SimpleXmlElement $xml xml
	 *
	 * @return array<string,bool|string|array<string,string>>
	 */
	private function parseAcknowledgementDocument($xml)
	{
		$indicator = $this->getXpathValue($xml, '//rsm:AcknowledgementDocument/ram:MultipleReferencesIndicator/udt:Indicator');

		// Parse the referenced document
		$referenceDocument = $this->parseReferencedDocument($xml);

		return [
			'MultipleReferencesIndicator' => $indicator === 'true',
			'TypeCode' => $this->getXpathValue($xml, '//rsm:AcknowledgementDocument/ram:TypeCode'),
			'IssueDateTime' => $this->getXpathValue($xml, '//rsm:AcknowledgementDocument/ram:IssueDateTime/udt:DateTimeString'),
			'ReferenceReferencedDocument' => $referenceDocument
		];
	}

	/**
	 * parseReferencedDocument
	 *
	 * @param  SimpleXmlElement $xml xml
	 *
	 * @return array<string,int|string|array<string,string>>
	 */
	private function parseReferencedDocument($xml)
	{
		$result = [
			'IssuerAssignedID' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:IssuerAssignedID'),
			'StatusCode' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:StatusCode'),
			'TypeCode' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:TypeCode'),
			'FormattedIssueDateTime' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:FormattedIssueDateTime/qdt:DateTimeString'),
			'ProcessConditionCode' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:ProcessConditionCode'),
			'ProcessCondition' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:ProcessCondition'),
			'IssuerTradeParty' => [
				'GlobalID' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:IssuerTradeParty/ram:GlobalID'),
				'SchemeID' => $this->getXpathAttribute($xml, '//ram:ReferenceReferencedDocument/ram:IssuerTradeParty/ram:GlobalID', 'schemeID'),
				'RoleCode' => $this->getXpathValue($xml, '//ram:ReferenceReferencedDocument/ram:IssuerTradeParty/ram:RoleCode')
			]
		];

		$statusNodes = $this->registerNamespaces($xml)->xpath('//ram:ReferenceReferencedDocument/ram:SpecifiedDocumentStatus');
		if (!empty($statusNodes)) {
			$status = $statusNodes[0];
			$result['StatusReasonCode'] = $this->getXpathValue($status, 'ram:ReasonCode');
			$result['StatusReason'] = $this->getXpathValue($status, 'ram:Reason');

			$seqResult = $this->registerNamespaces($status)->xpath('ram:SequenceNumeric');
			if (!empty($seqResult)) {
				$result['StatusSequenceNumeric'] = (int) $seqResult[0];
			}

			// Collect all note contents from all SpecifiedDocumentStatus nodes
			$allContents = [];
			foreach ($statusNodes as $statusNode) {
				$contentNodes = $this->registerNamespaces($statusNode)->xpath('ram:IncludedNote/ram:Content');
				if (!empty($contentNodes)) {
					foreach ($contentNodes as $node) {
						$content = trim((string) $node);
						if ($content !== '') {
							$allContents[] = $content;
						}
					}
				}
			}

			if (!empty($allContents)) {
				$result['StatusIncludedNoteContents'] = $allContents;               // array of all notes
				$result['StatusIncludedNoteContent'] = implode("\n", $allContents); // backward-compatible string
			}

			// MDG-43 blocks: what the status is about in figures - the amount cashed in (MEN) of a 212,
			// the amount paid (MPA) of a 211, what is left to pay (RAP), ...
			$characteristics = array();
			foreach ($statusNodes as $statusNode) {
				foreach ($this->registerNamespaces($statusNode)->xpath('ram:SpecifiedDocumentCharacteristic') as $node) {
					$block = array(
						'TypeCode' => $this->getXpathValue($node, 'ram:TypeCode'),
						'ValueAmount' => $this->getXpathValue($node, 'ram:ValueAmount'),
						'CurrencyID' => $this->getXpathAttribute($node, 'ram:ValueAmount', 'currencyID'),
						'ValuePercent' => $this->getXpathValue($node, 'ram:ValuePercent'),
						'ValueDateTime' => $this->getXpathValue($node, 'ram:ValueDateTime/qdt:DateTimeString')
					);
					if ($block['TypeCode'] !== '' || $block['ValueAmount'] !== '') {
						$characteristics[] = $block;
					}
				}
			}
			if (!empty($characteristics)) {
				$result['StatusCharacteristics'] = $characteristics;
			}
		}

		return $result;
	}

	/**
	 * Describe the MDG-43 blocks of a received status in one line, for the status comment and the log.
	 *
	 * @param  array<array{TypeCode?:string,ValueAmount?:string,CurrencyID?:string,ValuePercent?:string,ValueDateTime?:string}> $characteristics Blocks as parsed from the CDAR
	 * @param  Translate $langs Translate object
	 * @return string           One line, empty when no block carries an amount
	 */
	public static function describeStatusCharacteristics($characteristics, $langs)
	{
		$parts = array();

		foreach ($characteristics as $block) {
			if (!isset($block['ValueAmount']) || $block['ValueAmount'] === '') {
				continue;	// A block with no amount says nothing a reader can use
			}

			// A cash-in and a cash-out are both a 212, told apart by the sign alone (rule P1.15): say
			// which one this is rather than leave "Cashed in -240.00" on the screen.
			$code = isset($block['TypeCode']) ? (string) $block['TypeCode'] : '';
			$key = 'EInvCdarAmount' . $code . ($code === 'MEN' && (float) $block['ValueAmount'] < 0 ? 'Negative' : '');
			$label = ($code !== '' && $langs->trans($key) !== $key) ? $langs->trans($key) : $code;

			$one = price((float) $block['ValueAmount'], 0, $langs, 1, -1, -1, !empty($block['CurrencyID']) ? $block['CurrencyID'] : '');
			if (isset($block['ValuePercent']) && $block['ValuePercent'] !== '') {
				$one .= ' (' . vatrate((string) $block['ValuePercent'], true) . ')';
			}
			if (!empty($block['ValueDateTime'])) {
				$one .= ' ' . dol_print_date(dol_stringtotime($block['ValueDateTime']), 'day');
			}

			$parts[] = ($label !== '' ? $label . ' ' : '') . $one;
		}

		return implode(', ', $parts);
	}

	// ==================== GENERATION ====================

	/**
	 * addExchangedDocument
	 *
	 * @param  DOMDocument $dom dom
	 * @param  DOMElement $root root
	 * @param  array $doc doc
	 * @return void
	 */
	private function addExchangedDocument($dom, $root, $doc)
	{
		$exchanged = $dom->createElement('rsm:ExchangedDocument');
		$exchanged->appendChild($dom->createElement('ram:ID', einvoicingXmlText((string) $doc['ID'])));
		$exchanged->appendChild($dom->createElement('ram:Name', einvoicingXmlText((string) $doc['Name'])));

		$this->addDateTimeElement($dom, $exchanged, 'ram:IssueDateTime', $doc['IssueDateTime'], self::FORMAT_DATETIME);

		$this->addTradeParty($dom, $exchanged, 'ram:SenderTradeParty', $doc['SenderTradeParty']);
		$this->addTradeParty($dom, $exchanged, 'ram:IssuerTradeParty', $doc['IssuerTradeParty']);
		$this->addTradeParty($dom, $exchanged, 'ram:RecipientTradeParty', $doc['RecipientTradeParty']);

		$root->appendChild($exchanged);
	}

	/**
	 * addAcknowledgementDocument
	 *
	 * @param  DOMDocument $dom dom
	 * @param  DOMElement $root root
	 * @param  array $doc doc
	 * @return void
	 */
	private function addAcknowledgementDocument($dom, $root, $doc)
	{
		$ack = $dom->createElement('rsm:AcknowledgementDocument');

		$multipleRef = $dom->createElement('ram:MultipleReferencesIndicator');
		$indicator = $dom->createElement('udt:Indicator', $doc['MultipleReferencesIndicator'] ? 'true' : 'false');
		$multipleRef->appendChild($indicator);
		$ack->appendChild($multipleRef);

		$ack->appendChild($dom->createElement('ram:TypeCode', einvoicingXmlText((string) $doc['TypeCode'])));
		$this->addDateTimeElement($dom, $ack, 'ram:IssueDateTime', $doc['IssueDateTime'], self::FORMAT_DATETIME);
		$this->addReferencedDocument($dom, $ack, $doc['ReferenceReferencedDocument']);

		$root->appendChild($ack);
	}

	/**
	 * addReferencedDocument
	 *
	 * @param  DOMDocument $dom dom
	 * @param  DOMElement $parent parent
	 * @param  array $doc doc
	 * @return void
	 */
	private function addReferencedDocument($dom, $parent, $doc)
	{
		$ref = $dom->createElement('ram:ReferenceReferencedDocument');
		$ref->appendChild($dom->createElement('ram:IssuerAssignedID', einvoicingXmlText((string) $doc['IssuerAssignedID'])));
		$ref->appendChild($dom->createElement('ram:StatusCode', einvoicingXmlText((string) $doc['StatusCode'])));
		$ref->appendChild($dom->createElement('ram:TypeCode', einvoicingXmlText((string) $doc['TypeCode'])));

		// MDT-97. Its place in the CDAR XSD sequence (ReferencedDocumentType) is after ReceiptDateTime /
		// AttachmentBinaryObject and before FormattedIssueDateTime - the order the platforms use too.
		if (!empty($doc['ReferenceTypeCode'])) {
			$ref->appendChild($dom->createElement('ram:ReferenceTypeCode', einvoicingXmlText((string) $doc['ReferenceTypeCode'])));
		}

		$formattedDateTime = $dom->createElement('ram:FormattedIssueDateTime');
		$dateTimeStr = $dom->createElement('qdt:DateTimeString', einvoicingXmlText((string) $doc['FormattedIssueDateTime']));
		$dateTimeStr->setAttribute('format', self::FORMAT_DATE);
		$formattedDateTime->appendChild($dateTimeStr);
		$ref->appendChild($formattedDateTime);

		$ref->appendChild($dom->createElement('ram:ProcessConditionCode', einvoicingXmlText((string) $doc['ProcessConditionCode'])));
		$ref->appendChild($dom->createElement('ram:ProcessCondition', einvoicingXmlText((string) $doc['ProcessCondition'])));

		$this->addTradeParty($dom, $ref, 'ram:IssuerTradeParty', $doc['IssuerTradeParty']);
		$parent->appendChild($ref);

		if (!empty($doc['SpecifiedDocumentStatus'])) {
			$status = $dom->createElement('ram:SpecifiedDocumentStatus');

			if (!empty($doc['SpecifiedDocumentStatus']['ReasonCode'])) {
				$status->appendChild(
					$dom->createElement('ram:ReasonCode', einvoicingXmlText((string) $doc['SpecifiedDocumentStatus']['ReasonCode']))
				);
			}

			if (!empty($doc['SpecifiedDocumentStatus']['Reason'])) {
				$status->appendChild(
					$dom->createElement('ram:Reason', einvoicingXmlText((string) $doc['SpecifiedDocumentStatus']['Reason']))
				);
			}

			if (isset($doc['SpecifiedDocumentStatus']['SequenceNumeric'])) {
				$status->appendChild(
					$dom->createElement(
						'ram:SequenceNumeric',
						(string) $doc['SpecifiedDocumentStatus']['SequenceNumeric']
					)
				);
			}

			// MDT-126. Its place in the D22B DocumentStatusType sequence is after SequenceNumeric and
			// before the MDG-43 blocks.
			if (!empty($doc['SpecifiedDocumentStatus']['IncludedNoteContent'])) {
				$note = $dom->createElement('ram:IncludedNote');
				$note->appendChild($dom->createElement('ram:Content', einvoicingXmlText((string) $doc['SpecifiedDocumentStatus']['IncludedNoteContent'])));
				$status->appendChild($note);
			}

			// MDG-43 blocks (cashed amount per VAT rate for status 212). Element order follows the D22B
			// DocumentCharacteristicType sequence: TypeCode, then ValueAmount, then ValuePercent.
			if (!empty($doc['SpecifiedDocumentStatus']['SpecifiedDocumentCharacteristic'])) {
				foreach ($doc['SpecifiedDocumentStatus']['SpecifiedDocumentCharacteristic'] as $characteristic) {
					$characteristicElement = $dom->createElement('ram:SpecifiedDocumentCharacteristic');
					$characteristicElement->appendChild($dom->createElement('ram:TypeCode', einvoicingXmlText((string) $characteristic['TypeCode'])));

					if (isset($characteristic['ValueAmount'])) {
						$amountElement = $dom->createElement('ram:ValueAmount', einvoicingXmlText((string) $characteristic['ValueAmount']));
						if (!empty($characteristic['CurrencyID'])) {
							$amountElement->setAttribute('currencyID', $characteristic['CurrencyID']);
						}
						$characteristicElement->appendChild($amountElement);
					}

					if (isset($characteristic['ValueDateTime'])) {
						$this->addDateTimeElement($dom, $characteristicElement, 'ram:ValueDateTime', $characteristic['ValueDateTime'], self::FORMAT_DATE);
					}

					if (isset($characteristic['ValuePercent'])) {
						$characteristicElement->appendChild($dom->createElement('ram:ValuePercent', einvoicingXmlText((string) $characteristic['ValuePercent'])));
					}

					$status->appendChild($characteristicElement);
				}
			}

			$ref->appendChild($status);
		}
	}
}
