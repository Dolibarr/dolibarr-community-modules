<?php
/* Copyright (C) 2026       solauv
 * Copyright (C) 2026		MDW	<mdeweerd@users.noreply.github.com>
 * Copyright (C) 2026		Jose Martinez			<jose.martinez@pichinov.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    einvoicing/class/utils/SupplierInvoiceHelper.class.php
 * \ingroup einvoicing
 * \brief   Utility class for supplier invoices.
 */

dol_include_once('einvoicing/class/einvoicing.class.php');
dol_include_once('einvoicing/class/protocols/ProtocolManager.class.php');
dol_include_once('einvoicing/class/document.class.php');
// calcul_price_total(), used below to recompute the totals of a line the way the invoice got them.
// The core ships install/inc.php, which defines DOL_DOCUMENT_ROOT as '..', and PHPStan resolves the
// constant against it: the path it reports does not exist, the one used at runtime does.
require_once DOL_DOCUMENT_ROOT.'/core/lib/price.lib.php';  // @phpstan-ignore requireOnce.fileNotFound
dol_include_once('fourn/class/fournisseur.facture.class.php');
dol_include_once('einvoicing/lib/einvoicing.lib.php');

/**
 * Class SupplierInvoiceHelper
 */
class SupplierInvoiceHelper
{
	/**
	 * Close code set on a Dolibarr supplier invoice abandoned because its refusal was confirmed
	 * by the e-invoicing platform (PDP/PA). Distinct from the standard close codes (abandon,
	 * replaced, ...) so it can be reliably excluded from the accountancy transfer screen.
	 */
	const CLOSECODE_PDPREFUSED = 'pdp_refused';

	/**
	 * Special code marking the line an import adds to carry BT-114, the rounding amount of a received
	 * document. It is the module number, the way Dolibarr tags a line a module created, and it is the
	 * only line of an imported invoice outside the VAT breakdown: every per-rate comparison skips it.
	 */
	const LINE_SPECIAL_CODE_ROUNDING = 95020;

	/**
	 * BT-114 of a received document, the amount that rounds its total to what is due.
	 *
	 * @param	array<string,mixed>	$parsedHeader	Header data of the received document
	 * @return	float								The rounding amount, 0 when the document carries none
	 */
	public static function documentRoundingAmount(array $parsedHeader): float
	{
		return isset($parsedHeader['roundingAmount']) ? (float) $parsedHeader['roundingAmount'] : 0.0;
	}

	/**
	 * Sign that turns the amounts of a supplier invoice into those of the document it was imported from.
	 *
	 * Dolibarr stores a credit note negative and the document announces it positive; any other invoice
	 * carries the sign of its document, a negative one included (BT-3 380 with negative lines).
	 *
	 * @param	FactureFournisseur	$invoice	The supplier invoice
	 * @return	int								-1 for a credit note, 1 otherwise
	 */
	public static function documentSign(FactureFournisseur $invoice): int
	{
		return ((int) $invoice->type === FactureFournisseur::TYPE_CREDIT_NOTE) ? -1 : 1;
	}

	/**
	 * The VAT included total a Dolibarr invoice is expected to carry for a received document (issue #994).
	 *
	 * BT-115 is what the buyer owes, and what the invoice totals once BT-114 is carried as a line, so it
	 * is read in place of BT-112 - plus BT-113, which Dolibarr deducts beside the invoice and not from its
	 * total. It is checked against BR-CO-16 and dropped for BT-112 + BT-114 when it does not hold: a
	 * payable of the issuer's own invention must not move the guards that block a bad import.
	 *
	 * @param	array<string,mixed>	$parsedHeader	Header data of the received document
	 * @return	?float								Total with the sign of the document, or null when it announces none
	 */
	public static function announcedTotalTtc(array $parsedHeader)
	{
		if (!isset($parsedHeader['grandTotalAmount'])) {
			return null;
		}

		$rounded = (float) $parsedHeader['grandTotalAmount'] + self::documentRoundingAmount($parsedHeader);

		if (isset($parsedHeader['duePayableAmount'])) {
			$prepaid = isset($parsedHeader['totalPrepaidAmount']) ? (float) $parsedHeader['totalPrepaidAmount'] : 0.0;
			$due = (float) $parsedHeader['duePayableAmount'] + $prepaid;
			if (abs($due - $rounded) < 0.005) {
				return $due;
			}
			dol_syslog(__METHOD__ . ' BT-115 (' . $parsedHeader['duePayableAmount'] . ') does not answer BR-CO-16 on BT-112/BT-113/BT-114, the invoice is confronted with BT-112 instead', LOG_WARNING, 0, '_einvoicing');
		}

		return $rounded;
	}

	/**
	 * The VAT excluded total a Dolibarr invoice is expected to carry for a received document (issue #994).
	 *
	 * BT-109 sums the taxable bases and ignores BT-114, which the invoice carries as a line of its own:
	 * what the invoice totals is therefore the one plus the other.
	 *
	 * @param	array<string,mixed>	$parsedHeader	Header data of the received document
	 * @return	?float								Total with the sign of the document, or null when it announces none
	 */
	public static function announcedTotalHt(array $parsedHeader)
	{
		if (!isset($parsedHeader['taxBasisTotalAmount'])) {
			return null;
		}

		return (float) $parsedHeader['taxBasisTotalAmount'] + self::documentRoundingAmount($parsedHeader);
	}

	/**
	 * Whether a line is the one an import added to carry BT-114.
	 *
	 * @param	object	$line	A line of a supplier invoice
	 * @return	bool			True when the line carries the rounding amount of a received document
	 */
	public static function isRoundingLine($line): bool
	{
		return isset($line->special_code) && (int) $line->special_code === self::LINE_SPECIAL_CODE_ROUNDING;
	}

	/**
	 * Compare amounts according to a number of digits after decimal point and return true if they are equal.
	 *
	 * @param float $amount1    The first amount to compare
	 * @param float $amount2    The second amount to compare
	 * @param ?int $roundPrecision The number of digits after decimal point to apply round()
	 * @return bool Whether the amounts are equal or not
	 */
	private static function areAmountsEqual($amount1, $amount2, $roundPrecision = null): bool
	{
		return (self::round($amount1, $roundPrecision) === self::round($amount2, $roundPrecision));
	}

	/**
	 * Compare a Dolibarr supplier invoice to its related e-invoice and check they are identical
	 * using following criteria : currency, VAT excl. total, VAT incl. total, VAT total, basis
	 * amount & VAT amount of each VAT rate
	 *
	 * @param FactureFournisseur $dolSupplierInvoice   The Dolibarr object to compare to e-invoice
	 *
	 * @return	array{identical:bool,errors:array}|false
	 */
	public static function checkDolInvoiceAndEInvoiceConsistency(FactureFournisseur $dolSupplierInvoice)
	{
		global $conf, $db, $langs;

		$errors = [];

		// Get supplier invoice XML data
		$xmlData = SupplierInvoiceHelper::getXmlData($dolSupplierInvoice->id, true);

		// Can't check consistency if there is no XML content
		if (!isset($xmlData) || $xmlData === '') {
			return false;
		}

		// Detect protocol
		$protocolManager = new ProtocolManager($db);
		$detectedProtocolName = $protocolManager->detectProtocolFromContent($xmlData);
		if (!isset($detectedProtocolName)) {
			return false;
		}
		$protocol = $protocolManager->getProtocol($detectedProtocolName);

		// Extract XML header data
		$parsedHeader = $protocol->parseInvoiceHeader($xmlData);

		// Currency
		$currencyCode = $dolSupplierInvoice->multicurrency_code ?? $conf->currency;
		if ($currencyCode != $parsedHeader['invoiceCurrency']) {
			$errors[] = $langs->trans('SupplierInvoiceComparisonCurrencyDifference', $parsedHeader['invoiceCurrency'], $currencyCode);
		}

		// -----------------------------------------------------------------
		// 		Compare amount depending VAT calculation mode 1 & 2
		// -----------------------------------------------------------------

		// ? As we can't know if VAT of supplier invoice has been calculated in mode 1 or 2,
		// ? we need to calculate VAT in 3 different modes to be able to suggest the good one (can suggest only if differences are detected) :
		// ? - 'current' : if current supplier invoice data are identical to e-invoice, no need to suggest to switch VAT mode
		// ? - 'totalofround' (mode 1) : round VAT amount of each line then sum rounded amounts
		// ? - 'roundoftotal' (mode 2) : sum VAT amount of each line then round total

		// ? NOTE : Have to recode calculation of mode 1 & mode 2 because there is currently no Dolibarr function allowing to properly
		// ? apply VAT mode 1 or 2 on the supplier object without updating database.
		// ? Previously tried with CommonObject::update_price(), but it was not appropriate because it always refetch lines data from database
		// ? instead of using current object ones.

		$calculationRules = [
			'current' => 0,
			'totalofround' => 1,
			'roundoftotal' => 2,
		];

		$amountErrors = [];

		$sign = self::documentSign($dolSupplierInvoice);

		foreach ($calculationRules as $calculationRule => $vatComputeMode) {
			$details = self::getInvoiceDetailsForComparison($dolSupplierInvoice, $vatComputeMode);
			$amountErrors[$calculationRule] = [];

			// The invoice is put in the sign of its document before anything is compared
			$details['total_ht'] = $sign * $details['total_ht'];
			$details['total_ttc'] = $sign * $details['total_ttc'];
			$details['total_tva'] = $sign * $details['total_tva'];
			foreach ($details['vat_by_rate'] as $rate => $rateDetails) {
				$details['vat_by_rate'][$rate]['vat_amount'] = $sign * $rateDetails['vat_amount'];
				$details['vat_by_rate'][$rate]['vat_basis_amount'] = $sign * $rateDetails['vat_basis_amount'];
			}

			// VAT excl. and VAT incl. totals. Both are confronted with what the invoice is expected to
			// carry rather than with BT-109 and BT-112 alone: a document carrying BT-114 is imported with
			// a rounding line, and its invoice totals BT-115 (issue #994).
			$announcedHt = self::announcedTotalHt($parsedHeader);
			$announcedTtc = self::announcedTotalTtc($parsedHeader);

			if ($announcedHt !== null && !self::areAmountsEqual($details['total_ht'], $announcedHt)) {
				$amountErrors[$calculationRule][] = $langs->trans('SupplierInvoiceComparisonTotalVatExclDifference', $announcedHt, $details['total_ht']);
			}

			if ($announcedTtc !== null && !self::areAmountsEqual($details['total_ttc'], $announcedTtc)) {
				$amountErrors[$calculationRule][] = $langs->trans('SupplierInvoiceComparisonTotalVatInclDifference', $announcedTtc, $details['total_ttc']);
			}

			// VAT total
			if (!self::areAmountsEqual($details['total_tva'], $parsedHeader['taxTotalAmount'])) {
				$amountErrors[$calculationRule][] = $langs->trans('SupplierInvoiceComparisonTotalVatDifference', $parsedHeader['taxTotalAmount'], $details['total_tva']);
			}

			$dolSupplierInvoiceVatDetails = $details['vat_by_rate'];
			foreach ($parsedHeader['taxBreakdown'] as $taxDetailsByRate) {
				if ($taxDetailsByRate['typeCode'] === 'VAT') {
					$currentRate = (string) $taxDetailsByRate['rateApplicablePercent'];
					if (array_key_exists($currentRate, $dolSupplierInvoiceVatDetails)) {
						$dolVatAmount = $dolSupplierInvoiceVatDetails[$currentRate]['vat_amount'];
						$dolVatBasis = $dolSupplierInvoiceVatDetails[$currentRate]['vat_basis_amount'];

						if (!self::areAmountsEqual($dolVatBasis, $taxDetailsByRate['basisAmount'])) {
							$amountErrors[$calculationRule][] = $langs->trans('SupplierInvoiceComparisonVatBasisDifference', $currentRate, $taxDetailsByRate['basisAmount'], $dolVatBasis);
						}
						if (!self::areAmountsEqual($dolVatAmount, $taxDetailsByRate['calculatedAmount'])) {
							$amountErrors[$calculationRule][] = $langs->trans('SupplierInvoiceComparisonVatRateDifference', $currentRate, $taxDetailsByRate['calculatedAmount'], $dolVatAmount);
						}
					} else {
						$amountErrors[$calculationRule][] = $langs->trans('SupplierInvoiceComparisonVatRateNotFound', $currentRate);
					}
				}
			}

			if (count($amountErrors['current']) == 0) {
				// Don't need to calculate VAT mode 1 & 2 if supplier invoice and e-invoice are identical with current mode
				break;
			}
		}

		if (count($amountErrors['current']) > 0) {
			// If there are errors in both VAT modes (totalofround and roundoftotal), then return only the errors occurred with roundoftotal
			if (count($amountErrors['totalofround'] ?? []) > 0 && count($amountErrors['roundoftotal'] ?? []) > 0) {
				$errors = array_merge($errors, $amountErrors['roundoftotal'] ?? []);
			} else {
				$errors = array_merge($errors, $amountErrors['totalofround'] ?? [], $amountErrors['roundoftotal'] ?? []);
			}

			if ($amountErrors['current'] == $amountErrors['totalofround'] && count($amountErrors['roundoftotal']) === 0) {
				$errors[] = $langs->trans('SupplierInvoiceComparisonSuggestVatCalculationMode', 2);
			} elseif ($amountErrors['current'] == $amountErrors['roundoftotal'] && count($amountErrors['totalofround']) === 0) {
				$errors[] = $langs->trans('SupplierInvoiceComparisonSuggestVatCalculationMode', 1);
			}
		}

		return [
			'identical' => (count($errors) == 0),
			'errors' => $errors,
		];
	}

	/**
	 * Return supplier invoice details used to compare dol supplier invoice and e-invoice
	 *
	 * @param FactureFournisseur 	$supplierInvoice 	The supplier invoice object
	 * @param int 					$vatComputeMode 	The VAT mode used to calculate VAT amounts
	 * @return array{total_ht: float, total_ttc: float, total_tva: float, vat_by_rate: array<string, array{vat_amount: float, vat_basis_amount: float}>}
	 */
	private static function getInvoiceDetailsForComparison(FactureFournisseur $supplierInvoice, $vatComputeMode)
	{
		global $conf, $db;

		// If mode 0 => use current supplier invoice data
		if ($vatComputeMode == 0) {
			$details = array(
				'total_ht' => $supplierInvoice->total_ht,
				'total_ttc' => $supplierInvoice->total_ttc,
				'total_tva' => $supplierInvoice->total_tva,
				'vat_by_rate' => self::getVatDetails($supplierInvoice)
			);

			return $details;
		}

		// Manage mode 1 (totalofround) & mode 2 (roundoftotal)
		$details = array(
			'total_ht' => 0,
			'total_ttc' => 0,
			'total_tva' => 0,
		);

		$seller = new Societe($db);
		$resseller = $seller->fetch($supplierInvoice->socid);
		if ($resseller <= 0) {
			throw new Exception('Seller not found for id : ' . $supplierInvoice->socid);
		}

		// calcul_price_total() always rounds the totals of a line with 'MT'. That is mode 1
		// (totalofround): round each line, then sum. Mode 2 (roundoftotal) keeps the unit precision
		// on the lines and rounds only the sums, further down. It is obtained by lending
		// MAIN_MAX_DECIMALS_TOT the unit precision for the duration of the loop, the way the core
		// itself swaps these constants when it recalculates a line in a foreign currency.
		$roundLinesOnUnitPrecision = ($vatComputeMode != 1);
		$savMaxDecimalsTot = getDolGlobalString('MAIN_MAX_DECIMALS_TOT');
		if ($roundLinesOnUnitPrecision) {
			$conf->global->MAIN_MAX_DECIMALS_TOT = getDolGlobalInt('MAIN_MAX_DECIMALS_UNIT');
		}

		foreach ($supplierInvoice->lines as $line) {
			$rate = (string) price2num($line->tva_tx);
			// BT-114 travels on a line of its own, which counts in the totals of the invoice and in no
			// taxable base: it opens no rate of its own either (issue #994).
			$isRoundingLine = self::isRoundingLine($line);

			if (!$isRoundingLine && !isset($details['vat_by_rate'][$rate])) {
				$details['vat_by_rate'][$rate] = array(
					'vat_basis_amount' => 0,
					'vat_amount' => 0
				);
			}

			$useLocalTax1 = 1;
			$useLocalTax2 = 1;
			$remisePercentGlobal = 0;
			$priceBaseType = 'HT';
			$infoBits = 0;
			// The types are cast to string because that is what calcul_price_total() reads them as:
			// it switches on '1' to '6', while the line carries them as integers.
			$localTaxes = array((string) $line->localtax1_type, $line->localtax1_tx, (string) $line->localtax2_type, $line->localtax2_tx);
			$progress = (isset($line->situation_percent) ? $line->situation_percent : 100);
			$multiCurrencyTx = !empty($line->multicurrency_tx) ? $line->multicurrency_tx : 1;
			$puDevise = 0;
			$multicurrencyCode = '';

			// The PHPDoc of the core types the quantity as int up to Dolibarr 20, and the two localtax
			// rates as int|string, while a line carries floats and the function computes with them.
			$lineTotals = calcul_price_total(
				$line->qty,  // @phpstan-ignore argument.type
				$line->subprice,
				$line->remise_percent,
				floatval($rate),
				$useLocalTax1,
				$useLocalTax2,
				$remisePercentGlobal,
				$priceBaseType,
				$infoBits,
				$line->product_type,
				$seller,
				$localTaxes,  // @phpstan-ignore argument.type
				$progress,
				$multiCurrencyTx,
				$puDevise,
				$multicurrencyCode
			);

			$lineTotalHt = floatval($lineTotals[0]);
			$lineVatAmount = floatval($lineTotals[1]);
			$lineTotalTtc = floatval($lineTotals[2]);

			if (!$isRoundingLine) {
				$details['vat_by_rate'][$rate]['vat_basis_amount'] += $lineTotalHt;
				$details['vat_by_rate'][$rate]['vat_amount'] += $lineVatAmount;
			}

			$details['total_ht'] += $lineTotalHt;
			$details['total_ttc'] += $lineTotalTtc;
			$details['total_tva'] += $lineVatAmount;
		}

		if ($roundLinesOnUnitPrecision) {
			$conf->global->MAIN_MAX_DECIMALS_TOT = $savMaxDecimalsTot;
		}

		$roundPrecision = 'MT';

		foreach ($details['vat_by_rate'] as $rate => $rateDetails) {
			// Use floatval() to cast to float because parsed data from einvoice are of type 'float'
			$details['vat_by_rate'][$rate]['vat_amount'] = floatval(price2num($details['vat_by_rate'][$rate]['vat_amount'], $roundPrecision));
		}

		// Use floatval() to cast to float because parsed data from einvoice are of type 'float'
		$details['total_ht'] = floatval(price2num($details['total_ht'], $roundPrecision));
		$details['total_ttc'] = floatval(price2num($details['total_ttc'], $roundPrecision));
		$details['total_tva'] = floatval(price2num($details['total_tva'], $roundPrecision));

		return $details;
	}

	/**
	 * Return VAT details (by VAT rate) from a supplier invoice
	 *
	 * @param FactureFournisseur $supplierInvoice The supplier invoice object
	 * @return array<string, array{vat_amount: float, vat_basis_amount: float}>
	 */
	public static function getVatDetails(FactureFournisseur $supplierInvoice): array
	{
		$vatByRate = array();

		foreach ($supplierInvoice->lines as $line) {
			// BT-114 is carried by a line of its own and belongs to no taxable base (issue #994)
			if (self::isRoundingLine($line)) {
				continue;
			}

			$rate = (string) price2num($line->tva_tx);

			if (!isset($vatByRate[$rate])) {
				$vatByRate[$rate] = array(
					'vat_basis_amount' => 0,
					'vat_amount' => 0
				);
			}

			$vatByRate[$rate]['vat_basis_amount'] += $line->total_ht;
			$vatByRate[$rate]['vat_amount'] += $line->total_tva;
		}
		return $vatByRate;
	}

	/**
	 * Try to return XML data of a supplier invoice :
	 * - first, try to get data from database
	 * - if data not found in database, try to re-get data from AP
	 *
	 * @param	int 		$supplierInvoiceId 		The id of the supplier invoice
	 * @param 	bool 		$fetchXmlIfEmpty		Whether the XML data should be fetch again (if currently empty in database)
	 * @return 	?string 							The XML data if available or null if can't get it
	 * @throws 	Exception
	 */
	public static function getXmlData(int $supplierInvoiceId, bool $fetchXmlIfEmpty = false)
	{
		global $db, $user;

		$sql = "SELECT rowid, flow_id, provider, xml_data FROM " . $db->prefix() . "einvoicing_document";
		$sql .= " WHERE fk_element_type = 'invoice_supplier'";
		$sql .= " AND fk_element_id = " . (int) $supplierInvoiceId;
		$sql .= " AND flow_type = 'SupplierInvoice'";
		$sql .= " LIMIT 2";

		$resql = $db->query($sql);
		if ($resql) {
			if ($db->num_rows($resql) == 1) {
				$foundDocument = $db->fetch_object($resql);
				$db->free($resql);

				$document = new Document($db);
				$resdoc = $document->fetch($foundDocument->rowid);

				if ((empty($resdoc) || is_null($document->xml_data) || $document->xml_data == '') && $fetchXmlIfEmpty) {
					$providerManager = new PDPProviderManager($db);
					$provider = $providerManager->getProvider(strtoupper((string) $document->provider));

					$cleanedXmlData = $provider->fetchFlowXml($document->flow_id, true);

					if (Document::checkXmlDataMaxSize($cleanedXmlData)) {
						$document->xml_data = $cleanedXmlData;
						$document->update($user);
					} else {
						dol_syslog(__METHOD__. " : xml_data content is too big and can't be stored in database (16Mo max for MEDIUMTEXT)", LOG_ERR);
					}

					return $cleanedXmlData;
				}

				return $foundDocument->xml_data;
			} elseif ($db->num_rows($resql) > 1) {
				$db->free($resql);
				throw new Exception('Duplicate entry in einvoicing_document for supplier invoice with id '.$supplierInvoiceId);
			} elseif ($db->num_rows($resql) == 0) {
				$db->free($resql);
				throw new Exception('No result found when searching for supplier invoice with id '.$supplierInvoiceId . ' in einvoicing_document');
			}
		}

		return null;
	}

	/**
	 * Allow to know if a supplier invoice is an e-invoice or not
	 *
	 * @param int 	$supplierInvoiceId 				The id of the supplier invoice
	 * @param bool 	$checkLinkedDolObjectExistance 	Also check if linked Dol object really exists or not
	 * @param bool 	$duplicate 						Set to true when several e-invoicing documents describe the
	 *												same supplier invoice, so the caller can refuse the operation
	 * @return bool									True if invoice found.
	 */
	public static function isEInvoice(int $supplierInvoiceId, bool $checkLinkedDolObjectExistance = false, bool &$duplicate = false): bool
	{
		global $db;

		$duplicate = false;

		$sql = "SELECT rowid FROM " . $db->prefix() . "einvoicing_document";
		$sql .= " WHERE fk_element_type = 'invoice_supplier'";
		$sql .= " AND fk_element_id = " . (int) $supplierInvoiceId;
		$sql .= " AND flow_type = 'SupplierInvoice'";
		$sql .= " LIMIT 2";

		$resql = $db->query($sql);
		if (!$resql) {
			return false;
		}

		$num = $db->num_rows($resql);
		$db->free($resql);

		if ($num > 1) {
			// Several e-invoicing documents for one supplier invoice is a data integrity problem needing a
			// manual fix: the invoice may hold diverging statuses from two access points. The predicate still
			// answers yes and reports it; run_triggers() has no try/catch, so throwing here would be fatal.
			$duplicate = true;
			dol_syslog(__METHOD__ . ' duplicate entry in einvoicing_document for supplier invoice with id ' . $supplierInvoiceId, LOG_ERR);
		}

		if ($num <= 0) {
			return false;
		}

		if ($checkLinkedDolObjectExistance) {
			$factureFournisseur = new FactureFournisseur($db);

			return ($factureFournisseur->fetch((int) $supplierInvoiceId) > 0);
		}

		return true;
	}

	/**
	 * Abandon a Dolibarr supplier invoice because its refusal has been confirmed by the PDP/PA:
	 * validates it if still a draft, then cancels it with a dedicated close code, excluded from the
	 * accountancy transfer screen (see ActionsEinvoicing::printFieldListWhere()). A paid invoice is
	 * never touched; the idempotence check needs a freshly fetched $object (status/close_code).
	 * Validation runs BILL_SUPPLIER_VALIDATE: if its consistency check rejects, this method fails.
	 *
	 * @param	FactureFournisseur	$object			Supplier invoice to abandon
	 * @param	User				$user			User (or system user, when called from a cron) triggering the change
	 * @param	string				$reasonLabel	Label of the refusal reason, stored as the invoice close note
	 * @return	int									1 if abandoned, 0 if already abandoned by this rule (no-op), -1 on error (see $object->errors)
	 */
	public static function abandonRefusedSupplierInvoice(FactureFournisseur $object, User $user, $reasonLabel = '')
	{
		if (!empty($object->paid) || $object->status == FactureFournisseur::STATUS_CLOSED) {
			$object->errors[] = 'Can not abandon supplier invoice id ' . $object->id . ' : invoice is already paid';
			dol_syslog(__METHOD__ . ' Can not abandon supplier invoice id ' . $object->id . ' : invoice is already paid', LOG_ERR);
			return -1;
		}

		if ($object->status == FactureFournisseur::STATUS_ABANDONED && $object->close_code == self::CLOSECODE_PDPREFUSED) {
			// Already abandoned by this same rule on a previous call (ex: AJAX confirmation followed
			// by the hourly cron re-processing the same platform confirmation).
			return 0;
		}

		if ($object->status == FactureFournisseur::STATUS_DRAFT) {
			$resValidate = $object->validate($user);
			if ($resValidate < 0) {
				dol_syslog(__METHOD__ . ' Failed to validate supplier invoice id ' . $object->id . ' before abandon : ' . implode(', ', $object->errors), LOG_ERR);
				return -1;
			}
		}

		$resCancel = $object->setCanceled($user, self::CLOSECODE_PDPREFUSED, $reasonLabel);
		if ($resCancel < 0) {
			dol_syslog(__METHOD__ . ' Failed to abandon supplier invoice id ' . $object->id . ' : ' . implode(', ', $object->errors), LOG_ERR);
			return -1;
		}

		return 1;
	}

	/**
	 * Tell whether an invoice totals what the received document announces.
	 *
	 * Compared with their sign: a credit note is stored negative by Dolibarr and announced positive, so
	 * its totals are negated first; any other invoice carries the sign of its document, a negative
	 * invoice (BT-3 380 with negative lines) included. What a deposit attached to the invoice deducts
	 * is added back first, the document announcing its totals before the deduction. The tolerance is there
	 * for the float representation, not for a difference: the document carries its totals to the cent.
	 *
	 * @param	FactureFournisseur	$invoice			The invoice, with its totals as stored
	 * @param	float				$announcedTva		BT-110 of the received document
	 * @param	float				$announcedTtc		BT-112 of the received document
	 * @param	?float				$announcedPrepaid	BT-113 of the received document, or null not to confront it
	 * @return	bool									True when both totals are the announced ones
	 */
	public static function totalsAgreeWithDocument(FactureFournisseur $invoice, $announcedTva, $announcedTtc, $announcedPrepaid = null)
	{
		// A deposit the import attached is a negative line of the invoice (insert_discount() writes
		// total_ht/tva/ttc as -amount_*), so the invoice totals BT-112 minus BT-113 while BT-110 and BT-112
		// are announced before the deduction. Adding the deduction back is what puts the two sides on the
		// same footing; it is added signed, so a credit note stored negative comes back to its own total
		// too. Nothing is attached in the ordinary case and the sums are zero (issue #948).
		$deposits = self::linkedDepositTotals((int) $invoice->id);
		$sign = self::documentSign($invoice);
		$invoiceTva = $sign * ((float) $invoice->total_tva + $deposits['tva']);
		$invoiceTtc = $sign * ((float) $invoice->total_ttc + $deposits['ttc']);

		if (abs($invoiceTva - (float) $announcedTva) >= 0.005
			|| abs($invoiceTtc - (float) $announcedTtc) >= 0.005) {
			return false;
		}

		// BT-113 does not move BT-110 or BT-112, so the two comparisons above cannot see it: a deposit
		// the import failed to deduct leaves an invoice that totals exactly what the document announces
		// and is short of what it says was already paid. Marks written before this check carry no
		// prepaid amount and are read as null, which keeps them on the two totals alone.
		if ($announcedPrepaid === null) {
			return true;
		}

		return abs(self::linkedDepositAmount((int) $invoice->id) - (float) $announcedPrepaid) < 0.005;
	}

	/**
	 * Amount the deposits linked to a supplier invoice deduct from it, VAT included.
	 *
	 * The deposit of a received document becomes a DiscountAbsolute the imported lines point at through
	 * fk_remise_except, and that row is what BT-113 has to be confronted with. Its fk_invoice_supplier_source
	 * is what tells a deposit from a document level allowance (BT-107), which carries none.
	 *
	 * @param	int		$supplierInvoiceId	Id of the supplier invoice
	 * @return	float						Sum of the deposits linked to it, VAT included
	 */
	public static function linkedDepositAmount($supplierInvoiceId)
	{
		$totals = self::linkedDepositTotals($supplierInvoiceId);

		return $totals['ttc'];
	}

	/**
	 * What the deposits linked to a supplier invoice deduct from it, VAT included and VAT alone.
	 *
	 * BT-113 is confronted with the amount including VAT, while putting an invoice back to the totals it
	 * had before the deduction needs the VAT as well: insert_discount() takes both off, one line carrying
	 * -amount_ttc and -amount_tva. The two come from the same row, hence the same query.
	 *
	 * @param	int								$supplierInvoiceId	Id of the supplier invoice
	 * @return	array{ttc:float,tva:float}							Amounts deducted, zero when nothing is attached
	 */
	public static function linkedDepositTotals($supplierInvoiceId)
	{
		global $db;

		$sql = "SELECT SUM(r.amount_ttc) as total, SUM(r.amount_tva) as total_tva";
		$sql .= " FROM " . MAIN_DB_PREFIX . "societe_remise_except as r";
		$sql .= " WHERE r.fk_invoice_supplier_source > 0";
		$sql .= " AND (r.fk_invoice_supplier = " . (int) $supplierInvoiceId;
		$sql .= " OR r.rowid IN (SELECT d.fk_remise_except FROM " . MAIN_DB_PREFIX . "facture_fourn_det as d";
		$sql .= " WHERE d.fk_facture_fourn = " . (int) $supplierInvoiceId . " AND d.fk_remise_except > 0))";

		$resql = $db->query($sql);
		if (!$resql) {
			dol_syslog(__METHOD__ . ' ' . $db->lasterror(), LOG_ERR);
			return array('ttc' => 0.0, 'tva' => 0.0);
		}
		$obj = $db->fetch_object($resql);

		return array(
			'ttc' => abs((float) ($obj->total ?? 0)),
			'tva' => abs((float) ($obj->total_tva ?? 0)),
		);
	}

	/**
	 * Mark a supplier invoice as not totalling what the document it was imported from announces.
	 *
	 * The announced totals are kept with the mark, so what it blocks can be re-evaluated without the
	 * document: an operator who corrects the invoice to the figures the vendor bills lifts the block
	 * by doing so (issue #861).
	 *
	 * @param	int		$supplierInvoiceId		Id of the supplier invoice the import created
	 * @param	float	$announcedTva			BT-110 of the received document, absolute value
	 * @param	float	$announcedTtc			BT-112 of the received document, absolute value
	 * @param	?float	$announcedPrepaid		BT-113 of the received document, when it is what the mark is about
	 * @param	?string	$announcedRefOfDeposit	The ref of the deposit if prepaid is from a deposit
	 * @return	int								-1 on error, >0 otherwise
	 */
	public static function flagTotalsMismatch($supplierInvoiceId, $announcedTva, $announcedTtc, $announcedPrepaid = null, $announcedRefOfDeposit = null)
	{
		global $db;

		$einvoicing = new EInvoicing($db);
		$value = array('tva' => (float) $announcedTva, 'ttc' => (float) $announcedTtc);
		if ($announcedPrepaid !== null && $announcedRefOfDeposit !== null) {
			$value['prepaid'] = (float) $announcedPrepaid;
			$value['prepaidref'] = (string) $announcedRefOfDeposit;
		}
		$value = json_encode($value);

		return $einvoicing->insertOrUpdateExtraField((int) $supplierInvoiceId, 'invoice_supplier', EInvoicing::EXTRAFIELD_TOTALS_MISMATCH, (string) $value);
	}

	/**
	 * Read the mark left by an import that could not reproduce the totals of the document.
	 *
	 * @param	int		$supplierInvoiceId		Id of the supplier invoice
	 * @return	?array{tva:float,ttc:float,prepaid?:float}	The totals the document announces, or null when the invoice carries no mark
	 */
	public static function totalsMismatch($supplierInvoiceId)
	{
		global $db;

		$einvoicing = new EInvoicing($db);
		$stored = $einvoicing->getExtraFieldValue((int) $supplierInvoiceId, 'invoice_supplier', EInvoicing::EXTRAFIELD_TOTALS_MISMATCH);
		if ($stored === null || $stored === '') {
			return null;
		}

		$decoded = json_decode($stored, true);
		if (!is_array($decoded) || !isset($decoded['tva']) || !isset($decoded['ttc'])) {
			return null;
		}

		$announced = array('tva' => (float) $decoded['tva'], 'ttc' => (float) $decoded['ttc']);
		// Only a mark written for a missing deduction carries BT-113. Absent, the caller confronts the
		// two totals alone, which is what every mark written before this one means.
		if (isset($decoded['prepaid'])) {
			$announced['prepaid'] = (float) $decoded['prepaid'];
		}
		if (isset($decoded['prepaidref'])) {
			$announced['prepaidref'] = (string) $decoded['prepaidref'];
		}

		return $announced;
	}

	/**
	 * Remove the mark, once the invoice totals what the document announces.
	 *
	 * @param	int		$supplierInvoiceId	Id of the supplier invoice
	 * @return	int							-1 on error, 0 if the invoice carried no mark, 1 otherwise
	 */
	public static function clearTotalsMismatch($supplierInvoiceId)
	{
		global $db;

		$einvoicing = new EInvoicing($db);

		return $einvoicing->insertOrUpdateExtraField((int) $supplierInvoiceId, 'invoice_supplier', EInvoicing::EXTRAFIELD_TOTALS_MISMATCH, '');
	}

	/**
	 * Tell whether a supplier invoice still disagrees with the document it was imported from.
	 *
	 * The mark alone is not the answer: it says the import could not reproduce the document, and the
	 * invoice may have been corrected since. So the totals are confronted again, and a mark that no
	 * longer holds blocks nothing.
	 *
	 * @param	int		$supplierInvoiceId	Id of the supplier invoice
	 * @return	bool						True while the invoice does not total what the document announces
	 */
	public static function totalsMismatchBlocks($supplierInvoiceId)
	{
		global $db;

		$announced = self::totalsMismatch((int) $supplierInvoiceId);
		if ($announced === null) {
			return false;
		}

		$invoice = new FactureFournisseur($db);
		if ($invoice->fetch((int) $supplierInvoiceId) <= 0) {
			return true;
		}

		return !self::totalsAgreeWithDocument($invoice, $announced['tva'], $announced['ttc'], $announced['prepaid'] ?? null);
	}

	/**
	 * Tell whether a received supplier invoice is a credit note correcting an invoice we refused.
	 *
	 * Refusing a received invoice cancels it, so the credit note the vendor issues to close the matter
	 * follows it and is refused too (issue #594). Only credit notes: a replacement invoice (BT-3 = 384)
	 * also references the document it corrects, and that one is exactly what has to remain acceptable.
	 *
	 * @param	int		$supplierInvoiceId	Id of the received supplier invoice
	 * @return	int							Id of the refused source invoice, 0 when the rule does not apply
	 */
	public static function refusedSourceOfCreditNote(int $supplierInvoiceId): int
	{
		global $db;

		if ($supplierInvoiceId <= 0) {
			return 0;
		}

		$sql = "SELECT fk_facture_source FROM " . $db->prefix() . "facture_fourn";
		$sql .= " WHERE rowid = " . (int) $supplierInvoiceId;
		$sql .= " AND type = " . (int) FactureFournisseur::TYPE_CREDIT_NOTE;
		$sql .= " AND fk_facture_source > 0";

		$resql = $db->query($sql);
		if (!$resql) {
			dol_syslog(__METHOD__ . ' SQL error: ' . $db->lasterror(), LOG_ERR, 0, '_einvoicing');
			return 0;
		}
		$obj = $db->fetch_object($resql);
		$db->free($resql);
		if (!$obj) {
			return 0;
		}

		$sourceId = (int) $obj->fk_facture_source;

		// Only a refusal the platform confirmed counts: one still pending can still be rejected, and
		// answering the credit note on the strength of it would commit us to something not yet true.
		$einvoicing = new EInvoicing($db);
		if (!$einvoicing->hasSentStatusMessage($sourceId, 'invoice_supplier', EInvoicing::STATUS_REFUSED, 1)) {
			return 0;
		}

		return $sourceId;
	}

	/**
	 * Close the supplier invoice that a newly validated replacement invoice replaces.
	 *
	 * Facture::validate() does it on the customer side, FactureFournisseur::validate() does not, so a
	 * replaced supplier invoice stayed validated and payable a second time (issue #549). Only invoices
	 * exchanged through the platform are touched. Left alone: a paid replaced invoice, a draft one, and
	 * one already closed by this same rule, so the method is idempotent.
	 *
	 * @param	FactureFournisseur	$replacement	Replacement invoice that has just been validated
	 * @param	User				$user			User validating it
	 * @return	int									1 if the replaced invoice was closed, 0 if there was nothing to do, -1 on error
	 */
	public static function closeReplacedSupplierInvoice(FactureFournisseur $replacement, User $user)
	{
		global $db;

		if ((int) $replacement->type !== FactureFournisseur::TYPE_REPLACEMENT || empty($replacement->fk_facture_source)) {
			return 0;
		}

		$sourceId = (int) $replacement->fk_facture_source;

		if (!self::isEInvoice((int) $replacement->id) && !self::isEInvoice($sourceId)) {
			return 0;
		}

		$source = new FactureFournisseur($db);
		if ($source->fetch($sourceId) <= 0) {
			dol_syslog(__METHOD__ . ' Cannot load the supplier invoice id ' . $sourceId . ' replaced by id ' . $replacement->id, LOG_ERR, 0, '_einvoicing');
			return -1;
		}

		if ($source->status == FactureFournisseur::STATUS_ABANDONED && $source->close_code == FactureFournisseur::CLOSECODE_REPLACED) {
			return 0;
		}

		if (!empty($source->paid) || $source->status == FactureFournisseur::STATUS_CLOSED) {
			dol_syslog(__METHOD__ . ' Supplier invoice id ' . $sourceId . ' is replaced by id ' . $replacement->id . ' but is already paid: left as it is', LOG_WARNING, 0, '_einvoicing');
			return 0;
		}

		if ($source->status == FactureFournisseur::STATUS_DRAFT) {
			dol_syslog(__METHOD__ . ' Supplier invoice id ' . $sourceId . ' is replaced by id ' . $replacement->id . ' but is still a draft: left as it is', LOG_INFO, 0, '_einvoicing');
			return 0;
		}

		if ($source->setCanceled($user, FactureFournisseur::CLOSECODE_REPLACED, '') < 0) {
			dol_syslog(__METHOD__ . ' Failed to close the supplier invoice id ' . $sourceId . ' replaced by id ' . $replacement->id . ' : ' . implode(', ', (array) $source->errors), LOG_ERR, 0, '_einvoicing');
			return -1;
		}

		dol_syslog(__METHOD__ . ' Supplier invoice id ' . $sourceId . ' closed as replaced by id ' . $replacement->id, LOG_DEBUG, 0, '_einvoicing');

		return 1;
	}

	/**
	 * Tell whether validating this supplier invoice has to answer its vendor with "Approved" (fr:205).
	 *
	 *   - EINVOICING_SEND_APPROVED_ON_VALIDATION, for an instance where validating an invoice
	 *     mean approving it. The status stays available by hand from the invoice card.
	 *   - the answer is no with EINVOICING_DISABLE_SYNC_DOLI_TO_AP set, on an invoice that never came from
	 *     the platform, when a 205 or a 210 was already sent, on a credit note of a refused one (#594), or
	 *     on a flow the platform filed as B2B international, where it refuses every status (#799).
	 *
	 * @param	EInvoicing	$einvoicing		Module object, for the lifecycle message lookup
	 * @param	int			$supplierInvoiceId	Id of the supplier invoice being validated
	 * @param	string		$elementType	Element type of that invoice ('invoice_supplier')
	 * @return	bool						True when the status has to be sent
	 */
	public static function shouldSendApprovedOnValidation($einvoicing, int $supplierInvoiceId, string $elementType = 'invoice_supplier'): bool
	{
		if (!getDolGlobalString('EINVOICING_SEND_APPROVED_ON_VALIDATION')) {
			return false;
		}
		if (einvoicingIsSendDisabled()) {
			return false;
		}
		if (!self::isEInvoice($supplierInvoiceId)) {
			return false;
		}
		if ($einvoicing->hasSentStatusMessage($supplierInvoiceId, $elementType, EInvoicing::STATUS_APPROVED)) {
			return false;
		}
		if ($einvoicing->hasSentStatusMessage($supplierInvoiceId, $elementType, EInvoicing::STATUS_REFUSED)) {
			return false;
		}
		if (self::refusedSourceOfCreditNote($supplierInvoiceId) > 0) {
			return false;
		}
		if ($einvoicing->isInternationalFlow($supplierInvoiceId, $elementType)) {
			return false;
		}

		return true;
	}

	/**
	 * Callback to invoke once an outbound lifecycle status message has been validated by the
	 * e-invoicing platform. No-op unless the message is a confirmed ('Ok') refusal
	 * (EInvoicing::STATUS_REFUSED) of a supplier invoice, then it abandons the Dolibarr supplier
	 * invoice (see abandonRefusedSupplierInvoice()). Errors are logged but never thrown, to never
	 * break the caller persisting the confirmation (see EInvoicing::updateStatusMessageValidation()).
	 *
	 * @param	DoliDB	$db					Database handler
	 * @param	User	$user				User (or system user, when called from a cron) triggering the change
	 * @param	int		$elementId			Id of the Dolibarr supplier invoice (einvoicing_lifecycle_msg.element_id)
	 * @param	int		$lcStatus			PDP/PA status code that was sent (einvoicing_lifecycle_msg.lc_status)
	 * @param	?string	$lcReasonCode		Reason code that was sent, if any (einvoicing_lifecycle_msg.lc_reason_code)
	 * @param	string	$validationStatus	Validation status just confirmed by the platform: 'Ok', 'Pending' or 'Error'
	 * @return	int							1 if abandoned, 0 if not applicable / already done, -1 on error (logged, not blocking)
	 */
	public static function onOutboundStatusMessageValidated($db, User $user, int $elementId, int $lcStatus, $lcReasonCode, string $validationStatus)
	{
		global $langs;

		if ($validationStatus !== 'Ok' || $lcStatus !== EInvoicing::STATUS_REFUSED) {
			return 0;
		}

		$object = new FactureFournisseur($db);
		$resFetch = $object->fetch($elementId);
		if ($resFetch <= 0) {
			dol_syslog(__METHOD__ . ' Failed to fetch supplier invoice id ' . $elementId, LOG_ERR);
			return -1;
		}

		$langs->load('einvoicing@einvoicing');
		$einvoicing = new EInvoicing($db);
		$reasons = $einvoicing->getReasonsByStatus(EInvoicing::STATUS_REFUSED, 0);
		$reasonLabel = (!empty($lcReasonCode) && is_array($reasons) && isset($reasons[$lcReasonCode])) ? $langs->trans($reasons[$lcReasonCode]['label']) : (string) $lcReasonCode;

		// abandonRefusedSupplierInvoice() already logs the specific failure reason (validate or
		// setCanceled) - not logged again here to avoid duplicate log entries for the same error.
		return self::abandonRefusedSupplierInvoice($object, $user, $reasonLabel);
	}

	/**
	 * Whether the total of an invoice already in base is the one a received document expects.
	 *
	 * @param	float	$invoiceTtc		Total of the invoice found, VAT included
	 * @param	float	$expectedTtc	Total the document announces, VAT included
	 * @param	float	$tolerance		Difference still read as the same invoice
	 * @return	bool					True when the two are the same amount
	 */
	private static function amountMatchesInvoice(float $invoiceTtc, float $expectedTtc, float $tolerance = 0.0): bool
	{
		return abs($invoiceTtc - $expectedTtc) <= abs($tolerance) + 0.004;
	}

	/**
	 * Find the supplier invoice of a given supplier whose ref_supplier is the given reference.
	 *
	 * Exact match by default: a wrong match silently drops an invoice or links it to the wrong document.
	 * EINVOICING_TOLERANT_SUPPLIER_REF_MATCH adds a narrow fallback, tried only when the exact match found
	 * nothing: a short or purely numeric reference is never searched as a substring, the substring must be
	 * delimited, and an ambiguity is reported rather than guessed.
	 *
	 * @param	string|null	$ref		Reference to look for (ExchangedDocument/ID or IssuerAssignedID of the XML)
	 * @param	int			$socId		Id of the supplier thirdparty
	 * @param	float		$total_ttc	If set, check that the total amount of the invoice is the expected one. 0 to look the reference up without checking any amount.
	 * @param	float		$tolerance	Difference still read as the same invoice, on top of the cent the amounts are compared to. BT-114 is passed here: a document carrying a rounding amount was imported without it before the rounding line existed, and it is the same invoice (issue #994).
	 * @return	int						Invoice id (>0) on a single certain match, 0 when not found, -1 on database error, -2 when several invoices match, -3 when the reference matches but not with the expected amount
	 */
	public static function findIdByRef($ref, int $socId, float $total_ttc = 0, float $tolerance = 0.0): int
	{
		global $db;

		$ref = trim((string) $ref);
		if ($ref === '' || $socId <= 0) {
			return 0;
		}

		// Exact match. Always tried first, and always enough on its own.
		$sql = "SELECT rowid, total_ttc FROM " . $db->prefix() . "facture_fourn";
		$sql .= " WHERE ref_supplier = '" . $db->escape($ref) . "'";
		$sql .= " AND fk_soc = " . ((int) $socId);

		$listofentityids = getEntity('facture_fourn');
		if (getDolGlobalString('EINVOICING_ALLOW_MULTICOMPANY_INVOICE_MOVE')) {
			$listofentityids .= ','.getDolGlobalString('EINVOICING_ALLOW_MULTICOMPANY_INVOICE_MOVE');
		}
		$sql .= " AND entity IN (" . $db->sanitize($listofentityids) . ")";

		$sql .= " LIMIT 1";
		$resql = $db->query($sql);
		if (!$resql) {
			dol_syslog(__METHOD__ . ' ' . $db->lasterror(), LOG_ERR);
			return -1;
		}
		$obj = $db->fetch_object($resql);

		$db->free($resql);
		if ($obj) {
			if ($total_ttc && !self::amountMatchesInvoice((float) $obj->total_ttc, $total_ttc, $tolerance)) {
				dol_syslog(__METHOD__ . ' found a supplier invoice matching the ref "' . $ref . '" for socid ' . ((int) $socId) . ' but not with the expected amount ' . $total_ttc, LOG_WARNING);
				return -3;
			}

			return (int) $obj->rowid;
		} elseif (getDolGlobalInt('EINVOICING_TOLERANT_SUPPLIER_REF_MATCH')) {
			// Tolerant fallback, opt-in and deliberately narrow. Everything that widens the match is
			// enclosed in this branch on purpose: no code path reaches it while the option is off.
			$refNoSpaces = self::normalizeRef($ref);
			if (dol_strlen($refNoSpaces) < getDolGlobalInt('EINVOICING_TOLERANT_SUPPLIER_REF_MIN_LENGTH', 8) || ctype_digit($refNoSpaces)) {
				// A short or purely numeric reference is a substring of far too many others, do not even try
				return 0;
			}

			$sql = "SELECT rowid, ref_supplier, total_ttc FROM " . $db->prefix() . "facture_fourn";
			$sql .= " WHERE REPLACE(ref_supplier, ' ', '') LIKE '%" . $db->escape($db->escapeforlike($refNoSpaces)) . "%'";
			$sql .= " AND fk_soc = " . ((int) $socId);

			$listofentityids = getEntity('facture_fourn');
			if (getDolGlobalString('EINVOICING_ALLOW_MULTICOMPANY_INVOICE_MOVE')) {
				$listofentityids .= ','.getDolGlobalString('EINVOICING_ALLOW_MULTICOMPANY_INVOICE_MOVE');
			}
			$sql .= " AND entity IN (" . $db->sanitize($listofentityids) . ")";

			$resql = $db->query($sql);
			if (!$resql) {
				dol_syslog(__METHOD__ . ' ' . $db->lasterror(), LOG_ERR);
				return -1;
			}
			$matches = array();
			$grandTotal = 0;
			while ($obj = $db->fetch_object($resql)) {
				// The SQL LIKE is only a prefilter, the delimiter rule below is what decides
				if (self::refEmbedsReference($obj->ref_supplier, $ref)) {
					$matches[(int) $obj->rowid] = (int) $obj->rowid;
					$grandTotal = $obj->total_ttc;
				}
			}
			$db->free($resql);

			if (count($matches) > 1) {
				dol_syslog(__METHOD__ . ' several supplier invoices embed reference "' . $ref . '" for socid ' . ((int) $socId) . ', ids ' . implode(',', $matches), LOG_WARNING);
				return -2;
			}

			if (count($matches) == 1) {
				if ($total_ttc && !self::amountMatchesInvoice((float) $grandTotal, $total_ttc, $tolerance)) {
					dol_syslog(__METHOD__ . ' found a supplier invoice matching the supplier invoice ref "' . $ref . '" for socid ' . ((int) $socId) . ' but not with the expected amount ' . $total_ttc, LOG_WARNING);
					return -3;
				}

				$found = (int) reset($matches);
				dol_syslog(__METHOD__ . ' reference "' . $ref . '" matched supplier invoice id ' . $found . ' by tolerant match', LOG_NOTICE);
				return $found;
			}
		}

		return 0;
	}

	/**
	 * Return the supplier invoice that shares a supplier reference with a vendor, whatever its amount.
	 *
	 * findIdByRef() answers "which invoice to reuse" and deliberately returns -3 (a conflict, not an id)
	 * when the only match carries a different amount. This companion answers "which invoice conflicts",
	 * so the caller can link straight to it and show its amount next to the announced one, instead of
	 * only telling the operator that a conflict exists.
	 *
	 * @param	string	$ref		Supplier reference (document number) to look for
	 * @param	int		$socId		Vendor thirdparty id
	 * @return	?array{id:int,total_ttc:float}	The exact-ref match ('id' and 'total_ttc'), or null
	 */
	public static function conflictingInvoiceByRef($ref, int $socId): ?array
	{
		global $db;

		$ref = (string) $ref;
		if ($ref === '' || $socId <= 0) {
			return null;
		}

		$sql = "SELECT rowid, total_ttc FROM " . $db->prefix() . "facture_fourn";
		$sql .= " WHERE ref_supplier = '" . $db->escape($ref) . "'";
		$sql .= " AND fk_soc = " . ((int) $socId);

		$listofentityids = getEntity('facture_fourn');
		if (getDolGlobalString('EINVOICING_ALLOW_MULTICOMPANY_INVOICE_MOVE')) {
			$listofentityids .= ',' . getDolGlobalString('EINVOICING_ALLOW_MULTICOMPANY_INVOICE_MOVE');
		}
		$sql .= " AND entity IN (" . $db->sanitize($listofentityids) . ")";
		$sql .= " LIMIT 1";

		$resql = $db->query($sql);
		if (!$resql) {
			dol_syslog(__METHOD__ . ' ' . $db->lasterror(), LOG_ERR);
			return null;
		}
		$obj = $db->fetch_object($resql);
		$db->free($resql);
		if ($obj) {
			return array('id' => (int) $obj->rowid, 'total_ttc' => (float) $obj->total_ttc);
		}

		return null;
	}

	/**
	 * Build the message of a lookup that findIdByRef() could not answer.
	 *
	 * A database failure and an ambiguous reference are two different problems, and neither of them
	 * is a missing document, so neither may be reported as one.
	 *
	 * @param	int			$code		Negative code returned by findIdByRef()
	 * @param	string|null	$ref		Reference that was looked for
	 * @param	string		$context	Where that reference comes from, appended to the message
	 * @return	string					Message to report to the caller
	 */
	public static function refLookupErrorMessage(int $code, $ref, string $context): string
	{
		global $db;

		// $ref and $context carry values read from the received e-invoice (document number, line id).
		// The caller prints this message as HTML in the synchronization panel, so neutralize any markup.
		$ref = dol_escape_htmltag((string) $ref);
		$context = dol_escape_htmltag($context);

		if ($code == -2) {
			return 'Several supplier invoices match reference "' . $ref . '" ' . $context . ', cannot determine which one to use';
		}
		if ($code == -3) {
			return 'Found a supplier invoice matching "' . $ref . '" for the thirdparty (but with non matching expected amount) ' . $context . ', cannot determine which one to use';
		}

		return 'Database error while looking for a supplier invoice with reference "' . $ref . '" ' . $context . ': ' . dol_escape_htmltag($db->lasterror());
	}

	/**
	 * Build the postponed result of a reference lookup findIdByRef() could not answer.
	 *
	 * None of these codes is a missing document, and none of them has stored anything: the import runs
	 * inside the one transaction createSupplierInvoiceFromSource() rolls back whole. Returned bare, the
	 * failure makes syncFlows() count an error and break, so a database hiccup - or an ambiguity, which
	 * no retry clears on its own - takes the rest of the batch down with it and every flow behind stays
	 * unimported for as long as nobody looks. 'postponeflow' keeps this flow pending, reports it with
	 * what to do about it, and lets the ones behind through.
	 *
	 * @param	int			$code		Negative code returned by findIdByRef()
	 * @param	string|null	$ref		Reference that was looked for
	 * @param	string		$context	Where that reference comes from, appended to the message
	 * @param	int			$socId		Supplier the reference was looked up for
	 * @param	string		$documentno	Reference of the received document being imported
	 * @return	array{res:int,postponeflow:int,message:string,businessmessage:string,actioncode:string,actionurl:string,actiondata:array<string,mixed>,action:string}	The postponed result
	 */
	public static function refLookupPostponedResult(int $code, $ref, string $context, int $socId, string $documentno): array
	{
		global $langs;

		$langs->loadLangs(array('bills', 'einvoicing@einvoicing'));

		$action = $langs->trans('CheckTheSupplierInvoicesCarryingTheReference', $ref);
		$action .= ' <a class="butAction small smallpaddingimp nomarginleft" href="' . DOL_URL_ROOT . '/fourn/facture/list.php?search_refsupplier=' . urlencode((string) $ref) . '&socid=' . $socId . '" target="_blank">';
		$action .= '<i class="fas fa-search"></i> ';
		$action .= $langs->trans('ModifySupplierInvoice');
		$action .= '</a>';

		return array(
			'res' => -1,
			'postponeflow' => 1,
			'message' => self::refLookupErrorMessage($code, $ref, $context),
			'businessmessage' => $langs->trans('CantResolveReferenceOfTheImportedInvoice', $documentno, (string) $ref),
			'actioncode' => 'LINKED_INVOICE_LOOKUP_FAILED',
			'actionurl' => 'none',
			'actiondata' => array('supplierref' => (string) $ref, 'linkedref' => $documentno, 'socid' => $socId),
			'action' => $action
		);
	}

	/**
	 * Tell whether a ref_supplier embeds a reference as a delimited substring.
	 *
	 * Both values are compared without their whitespace, so "FA 2026 10" matches "FA202610". The reference
	 * must be bounded by a non alphanumeric character, a removed gap or an edge, so that "FA202610" matches
	 * "PAY123 - FA202610 - dinner" but not "FA2026100". Case insensitive, like the SQL prefilter.
	 *
	 * @param	string|null	$refSupplier	ref_supplier value read from database
	 * @param	string|null	$ref			Reference looked for
	 * @return	bool						True when the reference is embedded as a delimited substring
	 */
	public static function refEmbedsReference($refSupplier, $ref): bool
	{
		$needle = self::normalizeRef($ref);
		if ($needle === '') {
			return false;
		}

		// Whitespace is removed so that "FA 2026 10" matches "FA202610", but removing it must not
		// destroy the boundary it forms: remember where a gap was, it counts as a delimiter.
		$haystack = '';
		$gapBefore = array();
		$pendingGap = false;
		foreach (preg_split('//u', (string) $refSupplier, -1, PREG_SPLIT_NO_EMPTY) as $char) {
			if (preg_match('/^(\s|\xc2\xa0)$/u', $char)) {
				$pendingGap = true;
				continue;
			}
			$gapBefore[strlen($haystack)] = $pendingGap;
			$pendingGap = false;
			$haystack .= $char;
		}
		$gapBefore[strlen($haystack)] = $pendingGap;

		$length = strlen($needle);
		$offset = 0;
		while (($pos = stripos($haystack, $needle, $offset)) !== false) {
			$end = $pos + $length;
			$startIsBounded = ($pos == 0 || !empty($gapBefore[$pos]) || !ctype_alnum($haystack[$pos - 1]));
			$endIsBounded = ($end >= strlen($haystack) || !empty($gapBefore[$end]) || !ctype_alnum($haystack[$end]));
			if ($startIsBounded && $endIsBounded) {
				return true;
			}
			$offset = $pos + 1;
		}

		return false;
	}

	/**
	 * Strip from a reference the whitespace that manual entry adds (space, tab, non breaking space).
	 *
	 * @param	string|null	$value	Raw reference
	 * @return	string				Reference without any whitespace
	 */
	private static function normalizeRef($value): string
	{
		return (string) preg_replace('/(\s|\xc2\xa0)+/u', '', (string) $value);
	}

	/**
	 * Round an amount according to a number of digits after decimal point and return it.
	 *
	 * @param float $amount    		The amount to round
	 * @param ?int $roundPrecision 	The number of digits after decimal point to apply round()
	 * @return float The rounded amount
	 */
	private static function round($amount, $roundPrecision = null): float
	{
		if (!isset($roundPrecision)) {
			$roundPrecision = getDolGlobalInt('MAIN_MAX_DECIMALS_TOT', 2);
		}

		return round($amount, (int) $roundPrecision);
	}
}
