<?php
/* Copyright (C) 2017       Laurent Destailleur      <eldy@users.sourceforge.net>
 * Copyright (C) 2023-2025  Frédéric France          <frederic.france@free.fr>
 * Copyright (C) 2025		SuperAdmin					<daoud.mouhamed@gmail.com>
 * Copyright (C) 2026		MDW							<mdeweerd@users.noreply.github.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/document.class.php
 * \ingroup     einvoicing
 * \brief       This file is a CRUD class file for Document (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
// getNomUrl() calls dolPrintHTMLForAttribute(), added to the core in Dolibarr 19: the backport is loaded here
// because a caller outside this module has no reason to know this class needs it.
require_once __DIR__ . '/../compat/functions.lib.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

/**
 * Class for Document
 */
class Document extends CommonObject
{
	/**
	 * @var string 		ID of module.
	 */
	public $module = 'einvoicing';

	/**
	 * @var string 		ID to identify managed object.
	 */
	public $element = 'document';

	/**
	 * @var string		Prefix to check for any trigger code of any business class to prevent bad value for trigger code.
	 * @see CommonTrigger::call_trigger()
	 */
	public $TRIGGER_PREFIX = 'EINVOICING_MYOBJECT';	// Will be used to build trgiger keys 'EINVOICING_MYOBJECT_MODIFY', ...

	/**
	 * @var string 		Name of table without prefix where object is stored. This is also the key used for extrafields management (so extrafields know the link to the parent table).
	 */
	public $table_element = 'einvoicing_document';

	/**
	 * @var string 		If permission must be checked with hasRight('einvoicing', 'read') and not hasright('einvoicing', 'document', 'read'), you can uncomment this line
	 */
	//public $element_for_permission = 'einvoicing';

	/**
	 * @var string 		String with name of icon for document. Must be a 'fa-xxx' fontawesome code (or 'fa-xxx_fa_color_size') or 'document@einvoicing' if picto is file 'img/object_document.png'.
	 */
	public $picto = 'fa-file-alt';

	/**
	 * @var int<0,1>	Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 0;

	/**
	 * @var int<0,1>|string		Does this object support multicompany module ?
	 * 							0=No test on entity, 1=Test with field entity in local table, 'field@table'=Test entity into the field@table (example 'fk_soc@societe')
	 */
	public $ismultientitymanaged = 1;


	const STATUS_DRAFT = 0;
	const STATUS_VALIDATED = 1;
	const STATUS_CANCELED = 9;

	/**
	 *  'type' field format:
	 *  	'integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter[:Sortfield]]]',
	 *  	'select' (list of values are in 'options'. for integer list of values are in 'arrayofkeyval'),
	 *  	'sellist:TableName:LabelFieldName[:KeyFieldName[:KeyFieldParent[:Filter[:CategoryIdType[:CategoryIdList[:SortField]]]]]]',
	 *  	'chkbxlst:...',
	 *  	'varchar(x)',
	 *  	'text', 'text:none', 'html',
	 *   	'double(24,8)', 'real', 'price', 'stock',
	 *  	'date', 'datetime', 'timestamp', 'duration',
	 *  	'boolean', 'checkbox', 'radio', 'array',
	 *  	'email', 'phone', 'url', 'password', 'ip'
	 *		Note: Filter must be a Dolibarr Universal Filter syntax string. Example: "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.status:!=:0) or (t.nature:is:NULL)"
	 *  'length' the length of field. Example: 255, '24,8'
	 *  'label' the translation key.
	 *  'langfile' the key of the language file for translation.
	 *  'alias' the alias used into some old hard coded SQL requests
	 *  'picto' is code of a picto to show before value in forms
	 *  'enabled' is a condition when the field must be managed (Example: 1 or 'getDolGlobalInt("MY_SETUP_PARAM")' or 'isModEnabled("multicurrency")' ...)
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form (not create). 5=Visible on list and view form (not create/not update). 6=visible on list and update/view form (not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'alwayseditable' says if field can be modified also when status is not draft ('1' or '0')
	 *  'default' is a default value for creation (can still be overwritten by the Setup of Default Values if the field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommended to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 or 2 if field can be used for measure. Field type must be summable like integer or double(24,8). Use 1 in most cases, or 2 if you don't want to see the column total into list (for example for percentage)
	 *  'css' and 'cssview' and 'csslist' is the CSS style to use on field. 'css' is used in creation and update. 'cssview' is used in view mode. 'csslist' is used for columns in lists. For example: 'css'=>'minwidth300 maxwidth500 widthcentpercentminusx', 'cssview'=>'wordbreak', 'csslist'=>'tdoverflowmax200'
	 *  'placeholder' to set the placeholder of a varchar field.
	 *  'help' and 'helplist' is a 'TranslationString' to use to show a tooltip on field. You can also use 'TranslationString:keyfortooltiponlick' for a tooltip on click.
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code like the constructor of the class.
	 *  'arrayofkeyval' to set a list of values if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel"). Note that type can be 'integer' or 'varchar'
	 *  'autofocusoncreate' to have field having the focus on a create form. Only 1 field should have this property set to 1.
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *	'validate' is 1 if you need to validate the field with $this->validateField(). Need MAIN_ACTIVATE_VALIDATION_RESULT.
	 *  'copytoclipboard' is 1 or 2 to allow to add a picto to copy value into clipboard (1=picto after label, 2=picto after value)
	 *
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @inheritdoc
	 * Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields = array(
		"rowid" => array("type" => "integer", "label" => "ID", "enabled" => "1", 'position' => 1, 'notnull' => 1, "visible" => "1", "noteditable" => "1", "index" => "1", "css" => "left", "comment" => "Id"),
		"provider" => array("type" => "varchar(50)", "label" => "AccessPoint", "langfile" => "einvoicing@einvoicing", "enabled" => "1", 'position' => 5, 'notnull' => 1, "visible" => "-1", "comment" => "EInvoice Platform provider"),
		"flow_id" => array("type" => "varchar(255)", "label" => "flow_id", "enabled" => "1", 'position' => 10, 'notnull' => 0, "visible" => "1", "comment" => "EInvoice flow UUID", "csslist" => "tdoverflowmax100"),
		"call_id" => array("type" => "varchar(50)", "label" => "TransactionID", "enabled" => "1", 'position' => 20, 'notnull' => 0, "visible" => "1", "comment" => "Reference to the original call", "csslist" => "tdoverflowmax100"),
		"flow_type" => array("type" => "varchar(255)", "label" => "flow_type", "enabled" => "1", 'position' => 40, 'notnull' => 0, "visible" => "1", "comment" => "Flow type ('sync', 'CustomerInvoice', 'Manual...', etc.)"),
		"flow_direction" => array("type" => "varchar(10)", "label" => "flow_direction", "enabled" => "1", 'position' => 50, 'notnull' => 0, "visible" => "1", "comment" => "In or Out", 'csslist' => 'center'),
		"flow_syntax" => array("type" => "varchar(50)", "label" => "flow_syntax", "enabled" => "1", 'position' => 60, 'notnull' => 0, "visible" => "-1", "comment" => "Document syntax (Factur-X, CII, UBL, etc.)"),
		"flow_profile" => array("type" => "varchar(50)", "label" => "flow_profile", "enabled" => "1", 'position' => 70, 'notnull' => 0, "visible" => "-1", "comment" => "Profile used (Basic, Cius, etc.)"),
		"processing_rule" => array("type" => "varchar(50)", "label" => "ProcessingRule", "enabled" => "1", 'position' => 75, 'notnull' => 0, "visible" => "-1", "help" => "ProcessingRuleHelp", "comment" => "Rule the platform computed for the flow (B2B, B2BInt, NotApplicable, ...)"),
		"document_body" => array("type" => "text", "label" => "document_body", "enabled" => "1", 'position' => 110, 'notnull' => 0, "visible" => "0", "comment" => "Full document content XML"),
		"fk_element_type" => array("type" => "varchar(100)", "label" => "fk_element_type", "enabled" => "1", 'position' => 120, 'notnull' => 0, "visible" => "1",),
		"fk_element_id" => array("type" => "integer", "label" => "fk_element_id", "enabled" => "1", 'position' => 130, 'notnull' => 0, "visible" => "-1",),
		"tracking_idref" => array("type" => "varchar(255)", "label" => "RefObject", "enabled" => "1", 'position' => 135, 'notnull' => 0, "visible" => "1", "comment" => "Document tracking identifier", "csslist" => "nowraponall"),
		"submittedat" => array("type" => "datetime", "label" => "submittedAt", "enabled" => "1", 'position' => 140, 'notnull' => 1, "visible" => "-1", "comment" => "submittedAt (PDP Date)"),
		"updatedat" => array("type" => "datetime", "label" => "updatedAt", "enabled" => "1", 'position' => 150, 'notnull' => 0, "visible" => "1", "comment" => "updatedAt (PDP Date)"),
		"entity" => array("type" => "integer", "label" => "entity", "enabled" => "1", 'position' => 170, 'notnull' => 0, "visible" => "0", "comment" => "Multi-entity support"),
		"flow_uiid" => array("type" => "varchar(255)", "label" => "flow_uiid", "enabled" => "1", 'position' => 180, 'notnull' => 0, "visible" => "0",),
		"cdar_lifecycle_code" => array("type" => "varchar(50)", "label" => "cdar_lifecycle_code", "enabled" => "1", 'position' => 101, 'notnull' => 0, "visible" => "-1",),
		"cdar_lifecycle_label" => array("type" => "varchar(255)", "label" => "cdar_lifecycle_label", "enabled" => "1", 'position' => 102, 'notnull' => 0, "visible" => "-1", "csslist" => "tdoverflowmax150",),
		"cdar_reason_code" => array("type" => "varchar(50)", "label" => "cdar_reason_code", "enabled" => "1", 'position' => 103, 'notnull' => 0, "visible" => "-1",),
		"cdar_reason_desc" => array("type" => "varchar(255)", "label" => "cdar_reason_desc", "enabled" => "1", 'position' => 104, 'notnull' => 0, "visible" => "-1",),
		"cdar_reason_detail" => array("type" => "text", "label" => "cdar_reason_detail", "enabled" => "1", 'position' => 105, 'notnull' => 0, "visible" => "-1",),
		"ack_status" => array("type" => "varchar(50)", "label" => "ack_status", "enabled" => "1", 'position' => 80, 'notnull' => 0, "visible" => "-1", "comment" => "Acknowledgment status (Success, Error, Pending)"),
		"ack_reason_code" => array("type" => "varchar(255)", "label" => "ack_reason_code", "enabled" => "1", 'position' => 90, 'notnull' => 0, "visible" => "-1", "comment" => "Reason code if error"),
		"ack_info" => array("type" => "text", "label" => "ack_info", "enabled" => "1", 'position' => 100, 'notnull' => 0, "visible" => "-1", "comment" => "Additional information if error/warning"),
		"date_creation" => array("type" => "datetime", "label" => "DateSyncro", "enabled" => "1", 'position' => 500, 'notnull' => 1, "visible" => "-1",),
		"tms" => array("type" => "timestamp", "label" => "DateModification", "enabled" => "1", 'position' => 501, 'notnull' => 0, "visible" => "-2",),
		"fk_user_creat" => array("type" => "integer:User:user/class/user.class.php", "label" => "UserAuthor", "picto" => "user", "enabled" => "1", 'position' => 510, 'notnull' => 1, "visible" => "-2", "csslist" => "tdoverflowmax150",),
		"fk_user_modif" => array("type" => "integer:User:user/class/user.class.php", "label" => "UserModif", "picto" => "user", "enabled" => "1", 'position' => 511, 'notnull' => -1, "visible" => "-2", "csslist" => "tdoverflowmax150",),
		"response_for_debug" => array("type" => "text", "label" => "RetreivedMessage", "enabled" => "1", 'position' => 700, 'notnull' => 0, "visible" => "-1", "comment" => "Full response body (JSON) of flow"),
		"xml_data" => array("type" => "text", "label" => "XmlData", "enabled" => "1", 'position' => 701, 'notnull' => 0, "visible" => "0", "comment" => "Document XML data (without PDF)"),
		//"status" => array("type" => "integer", "label" => "Status", "enabled" => "1", 'position' => 2000, 'notnull' => 1, "visible" => "0", "index" => "1", "arrayofkeyval" => array("0" => "Brouillon", "1" => "Valid&eacute;", "9" => "Annul&eacute;"), "validate" => "1",),
	);
	public $rowid;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $status;
	public $call_id;
	public $flow_id;
	public $tracking_idref;
	public $flow_type;
	public $flow_direction;
	public $flow_syntax;
	public $flow_profile;
	public $processing_rule;
	public $ack_status;
	public $ack_reason_code;
	public $ack_info;
	public $document_body;
	public $fk_element_id;
	public $fk_element_type;
	public $submittedat;
	public $updatedat;
	public $provider;
	public $entity;
	public $flow_uiid;
	public $cdar_lifecycle_code;
	public $cdar_lifecycle_label;
	public $cdar_reason_code;
	public $cdar_reason_desc;
	public $cdar_reason_detail;
	public $response_for_debug;
	// END MODULEBUILDER PROPERTIES

	// Contains raw XML content (/!\ may not be identical to original XML content from AP file because it can be partially cleaned (like attachment files) to preserve XML size stored in database)
	// It allows to work on XML data (even if AP is down) but will not suit for all usages (be aware of limitations)
	public $xml_data;


	// If this object has a subtable with lines

	// /**
	//  * @var string    Name of subtable line
	//  */
	// public $table_element_line = 'einvoicing_documentline';

	// /**
	//  * @var string    Field name with ID of parent key if this object has a parent, Or Field name of in child tables to link to this record.
	//  */
	// public $fk_element = 'fk_document';

	// /**
	//  * @var string    Name of subtable class that manage subtable lines
	//  */
	// public $class_element_line = 'Documentline';

	// /**
	//  * @var array	List of child tables. To test if we can delete object.
	//  */
	// protected $childtables = array('mychildtable' => array('name'=>'Document', 'fk_element'=>'fk_document'));

	// /**
	//  * @var array    List of child tables. To know object to delete on cascade.
	//  *               If name matches '@ClassName:FilePathClass:ParentFkFieldName' (the recommended mode) it will
	//  *               call method ClassName->deleteByParentField(parentId, 'ParentFkFieldName') to fetch and delete child object.
	//  *               Using an array like childtables should not be implemented because a child may have other child, so we must only use the method that call deleteByParentField().
	//  */
	// protected $childtablesoncascade = array('einvoicing_documentdet');

	// /**
	//  * @var DocumentLine[]     Array of subtable lines
	//  */
	// public $lines = array();



	/**
	 * Constructor
	 *
	 * @param	DoliDB $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $langs;

		$this->db = $db;

		if (!getDolGlobalInt('MAIN_SHOW_TECHNICAL_ID') && isset($this->fields['rowid']) && !empty($this->fields['ref'])) {
			$this->fields['rowid']['visible'] = 0;
		}
		if (!isModEnabled('multicompany') && isset($this->fields['entity'])) {
			$this->fields['entity']['enabled'] = 0;
		}

		// Unset fields that are disabled
		foreach ($this->fields as $key => $val) {
			if (isset($val['enabled']) && empty($val['enabled'])) {
				unset($this->fields[$key]);
			}
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs)) {
			foreach ($this->fields as $key => $val) {
				if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
					foreach ($val['arrayofkeyval'] as $key2 => $val2) {
						$this->fields[$key]['arrayofkeyval'][$key2] = $langs->trans($val2);
					}
				}
			}
		}
	}

	/**
	 * Create object into database
	 *
	 * @param	User		$user		User that creates
	 * @param	int<0,1> 	$notrigger	0=launch triggers after, 1=disable triggers
	 * @return	int<-1,max>				Return integer <0 if KO, Id of created object if OK
	 */
	public function create(User $user, $notrigger = 0)
	{
		// The label and reason of a lifecycle status are free text in the CDAR, the columns hold 255 characters,
		// the notes keep the whole text in cdar_reason_detail.
		foreach (array('cdar_lifecycle_label', 'cdar_reason_desc') as $field) {
			if (isset($this->$field)) {
				$this->$field = dol_substr((string) $this->$field, 0, 255);
			}
		}
		$result = $this->createCommon($user, $notrigger);

		// uncomment lines below if you want to validate object after creation
		// if ($result > 0) {
		// $this->fetch($this->id); // needed to retrieve some fields (ie date_creation for masked ref)
		// $resultupdate = $this->validate($user, $notrigger);
		// if ($resultupdate < 0) { return $resultupdate; }
		// }

		return $result;
	}

	/**
	 * Clone an object into another one
	 *
	 * @param	User 	$user		User that creates
	 * @param	int 	$fromid		Id of object to clone
	 * @return	self|int<-1,-1>		New object created, <0 if KO
	 */
	public function createFromClone(User $user, $fromid)
	{
		global $langs, $extrafields;
		$error = 0;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$object = new self($this->db);

		$this->db->begin();

		// Load source object
		$result = $object->fetchCommon($fromid);
		if ($result > 0 && !empty($object->table_element_line)) {
			$object->fetchLines();
		}

		// get lines so they will be clone
		//foreach($this->lines as $line)
		//	$line->fetch_optionals();

		// Reset some properties. unset() rather than an empty value is what the core does in its own
		// createFromClone(): createCommon() below builds the INSERT from the properties that are set.
		// @phan-suppress-next-line PhanTypeObjectUnsetDeclaredProperty
		unset($object->id);
		// @phan-suppress-next-line PhanTypeObjectUnsetDeclaredProperty
		unset($object->fk_user_creat);
		// @phan-suppress-next-line PhanTypeObjectUnsetDeclaredProperty
		unset($object->import_key);

		// Clear fields
		if (property_exists($object, 'ref')) {
			$object->ref = empty($this->fields['ref']['default']) ? "Copy_Of_".$object->ref : $this->fields['ref']['default'];
		}
		if (property_exists($object, 'label')) {
			$object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf")." ".$object->label : $this->fields['label']['default']; // @phan-suppress-current-line PhanUndeclaredProperty
		}
		if (property_exists($object, 'status')) {
			$object->status = self::STATUS_DRAFT;
		}
		if (property_exists($object, 'date_creation')) {
			$object->date_creation = dol_now();
		}
		if (property_exists($object, 'date_modification')) {
			$object->date_modification = null;
		}
		// ...
		// Clear extrafields that are unique
		if (is_array($object->array_options) && count($object->array_options) > 0) {
			$extrafields->fetch_name_optionals_label($this->table_element);
			foreach ($object->array_options as $key => $option) {
				$shortkey = preg_replace('/options_/', '', $key);
				if (!empty($extrafields->attributes[$this->table_element]['unique'][$shortkey])) {
					//var_dump($key);
					//var_dump($clonedObj->array_options[$key]); exit;
					unset($object->array_options[$key]);
				}
			}
		}

		// Create clone
		$object->context['createfromclone'] = 'createfromclone';
		$result = $object->createCommon($user);
		if ($result < 0) {
			$error++;
			$this->setErrorsFromObject($object);
		}

		if (!$error) {
			// copy internal contacts
			if ($this->copy_linked_contact($object, 'internal') < 0) {
				$error++;
			}
		}

		if (!$error) {
			// copy external contacts if same company
			if (!empty($object->socid) && ((property_exists($this, 'fk_soc') && ($this->fk_soc == $object->socid)) || (property_exists($this, 'socid') && ($this->socid == $object->socid)))) {	// @phpstan-ignore-line @phan-suppress-current-line PhanUndeclaredProperty
				if ($this->copy_linked_contact($object, 'external') < 0) {
					$error++;
				}
			}
		}

		unset($object->context['createfromclone']);

		// End
		if (!$error) {
			$this->db->commit();
			return $object;
		} else {
			$this->db->rollback();
			return -1;
		}
	}

	/**
	 * Load object in memory from the database
	 *
	 * @param	int    		$id   			Id object
	 * @param	string 		$ref  			Ref
	 * @param	int<0,1>	$noextrafields	0=Default to load extrafields, 1=No extrafields
	 * @param	int<0,1>	$nolines		0=Default to load lines, 1=No lines
	 * @return	int<-1,1>					Return integer <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null, $noextrafields = 0, $nolines = 0)
	{
		$result = $this->fetchCommon($id, $ref, '', $noextrafields);
		if ($result > 0 && !empty($this->table_element_line) && empty($nolines)) {
			$this->fetchLines($noextrafields);
		}
		return $result;
	}

	/**
	 * Load object lines in memory from the database
	 *
	 * @param	int<0,1>	$noextrafields	0=Default to load extrafields, 1=No extrafields
	 * @return 	int<-1,1>					Return integer <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchLines($noextrafields = 0)
	{
		$this->lines = array();

		$result = $this->fetchLinesCommon('', $noextrafields);
		return $result;
	}


	/**
	 * Load list of objects in memory from the database.
	 * Using a fetchAll() with limit = 0 is a very bad practice. Instead try to forge yourself an optimized SQL request with
	 * your own loop with start and stop pagination.
	 *
	 * @param	string		$sortorder	Sort Order
	 * @param	string		$sortfield	Sort field
	 * @param	int<0,max>	$limit		Limit the number of lines returned
	 * @param	int<0,max>	$offset		Offset
	 * @param	string		$filter		Filter as an Universal Search string.
	 *                                  Example: '((client:=:1) OR ((client:>=:2) AND (client:<=:3))) AND (client:!=:8) AND (nom:like:'a%')'
	 * @param	string		$filtermode	No longer used
	 * @return	array<int,self>|int<-1,-1>	 <0 if KO, array of pages if OK
	 */
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 1000, $offset = 0, string $filter = '', $filtermode = 'AND') // @phan-suppress-current-line PhanPluginMoreSpecificActualReturnType
	{
		dol_syslog(__METHOD__, LOG_DEBUG);

		$records = array();

		$sql = "SELECT ";
		$sql .= $this->getFieldList('t');
		$sql .= " FROM ".$this->db->prefix().$this->table_element." as t";
		if (!empty($this->isextrafieldmanaged) && $this->isextrafieldmanaged == 1) {
			$sql .= " LEFT JOIN ".$this->db->prefix().$this->table_element."_extrafields as te ON te.fk_object = t.rowid";
		}
		if (!empty($this->ismultientitymanaged) && (int) $this->ismultientitymanaged == 1) {
			$sql .= " WHERE t.entity IN (".getEntity($this->element).")";
		} elseif (preg_match('/^\w+@\w+$/', (string) $this->ismultientitymanaged)) {
			$tmparray = explode('@', (string) $this->ismultientitymanaged);
			$sql .= " LEFT JOIN ".$this->db->prefix().$this->db->sanitize($tmparray[1])." as pt ON t.".$this->db->sanitize($tmparray[0])." = pt.rowid";
			$sql .= " WHERE pt.entity IN (".getEntity($this->element).")";
		} else {
			$sql .= " WHERE 1 = 1";
		}

		// Manage filter
		$errormessage = '';
		$sql .= forgeSQLFromUniversalSearchCriteria($filter, $errormessage);
		if ($errormessage) {
			$this->errors[] = $errormessage;
			dol_syslog(__METHOD__.' '.implode(',', $this->errors), LOG_ERR);
			return -1;
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= $this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			while ($i < ($limit ? min($limit, $num) : $num)) {
				$obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				if (!empty($record->isextrafieldmanaged)) {
					$record->fetch_optionals();
				}

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.implode(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 * Update object into database
	 *
	 * @param	User		$user		User that modifies
	 * @param	int<0,1>	$notrigger	0=launch triggers after, 1=disable triggers
	 * @return	int<-1,1>				Return integer <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = 0)
	{
		return $this->updateCommon($user, $notrigger);
	}

	/**
	 * Delete object in database
	 *
	 * @param	User		$user		User that deletes
	 * @param	int<0,1> 	$notrigger	0=launch triggers, 1=disable triggers
	 * @return	int<-1,1>				Return integer <0 if KO, >0 if OK
	 */
	public function delete(User $user, $notrigger = 0)
	{
		return $this->deleteCommon($user, $notrigger);
		//return $this->deleteCommon($user, $notrigger, 1);
	}

	/**
	 * Import a received document again, from the access point, as if it had never been imported.
	 *
	 * The vendor of a supplier invoice cannot be changed once it exists, so a document booked on the
	 * wrong third party has no way back short of this: fix the third party data, then import again.
	 * The local draft is deleted first; a validated invoice is refused, it is an accounting record.
	 * A failed import leaves this record in place, detached, rather than losing the document.
	 *
	 * @param	User				$user		User asking for the import
	 * @return	array{res:int,message:string}	res > 0 is the id of the supplier invoice created
	 */
	public function reimport(User $user)
	{
		global $langs;

		require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
		require_once __DIR__.'/providers/PDPProviderManager.class.php';

		$langs->load('einvoicing@einvoicing');

		if ($this->flow_direction !== 'In' || $this->fk_element_type !== 'invoice_supplier') {
			return array('res' => -1, 'message' => $langs->trans('EInvoiceReimportNotAReceivedInvoice'));
		}
		if (empty($this->flow_id)) {
			return array('res' => -1, 'message' => $langs->trans('EInvoiceReimportNoFlowId'));
		}

		$providerManager = new PDPProviderManager($this->db);
		$provider = $providerManager->getProvider(getDolGlobalString('EINVOICING_PDP'));
		if (empty($provider)) {
			return array('res' => -1, 'message' => $langs->trans('EInvoiceReimportNoProvider'));
		}

		// The invoice this document was booked on, if it is still there. Deleting it detaches this
		// record (see the BILL_SUPPLIER_DELETE trigger), which is why the id is read before. Its
		// reference is read for the same reason: the draft it names is about to disappear, and the
		// import that follows creates another one, which is given that same reference back.
		$previousInvoiceId = (int) $this->fk_element_id;
		$previousInvoiceRef = '';
		$previousInvoiceRecords = array();
		if ($previousInvoiceId > 0) {
			$previousInvoice = new FactureFournisseur($this->db);
			if ($previousInvoice->fetch($previousInvoiceId) > 0) {
				if ((int) $previousInvoice->status !== FactureFournisseur::STATUS_DRAFT) {
					return array('res' => -1, 'message' => $langs->trans('EInvoiceReimportInvoiceIsNotADraft', $previousInvoice->ref));
				}
				$previousInvoiceRef = (string) $previousInvoice->ref;
				// The other flows of that invoice - the lifecycle statuses its vendor has already sent -
				// are listed before it goes: deleting it detaches every record it has at once, and a
				// detached record no longer says which invoice it came from.
				$previousInvoiceRecords = $this->fetchOtherRecordsOfInvoice($previousInvoiceId);
				if ($previousInvoice->delete($user) <= 0) {
					$reason = $previousInvoice->error ? $previousInvoice->error : implode(', ', (array) $previousInvoice->errors);
					return array('res' => -1, 'message' => $langs->trans('EInvoiceReimportFailedToDeleteTheDraft', $previousInvoice->ref).' '.$reason);
				}
			}
		}

		$res = $provider->syncFlow($this->flow_id);
		if (!isset($res['res']) || $res['res'] <= 0) {
			return array('res' => -1, 'message' => (string) ($res['message'] ?? ''));
		}

		// The record the import has just written for this flow. Without it there is nothing to move
		// onto this line, which then stays as it is - detached, and the only line of the flow.
		$importedRecord = $this->fetchRecordWrittenByImport();
		if (!($importedRecord instanceof Document)) {
			dol_syslog(__METHOD__.' imported flow '.$this->flow_id.' again but found no record written by the import to move onto record '.$this->id, LOG_WARNING);

			return array('res' => 1, 'message' => (string) ($res['message'] ?? ''));
		}

		// The invoice the import has just booked the document on, to send the user straight to it.
		$newInvoiceId = (int) $importedRecord->fk_element_id;

		// Give that invoice back the number of the draft it replaces. Nothing in the core reads an id
		// out of a "(PROV...)" reference - it only tests the prefix - and the number of the draft that
		// has just been deleted is free, so the operator keeps looking at the number they know.
		if ($newInvoiceId > 0 && $previousInvoiceRef !== '') {
			$newInvoice = new FactureFournisseur($this->db);
			if ($newInvoice->fetch($newInvoiceId) > 0 && $this->reuseDraftRef($newInvoice, $previousInvoiceRef) > 0) {
				$importedRecord->tracking_idref = $previousInvoiceRef;
			}
		}

		// The statuses the vendor has already sent for this invoice describe the document, not the
		// local row it was booked on, so they follow it onto the invoice the import has just created.
		if ($newInvoiceId > 0 && $previousInvoiceId > 0) {
			$this->moveHistoryToInvoice($previousInvoiceId, $newInvoiceId, $previousInvoiceRecords, (string) $importedRecord->tracking_idref);
		}

		// Move that record onto this line, so the flow keeps the line it already had in the list
		// instead of losing it for a new one describing the same flow.
		if ($this->adoptRecordWrittenByImport($importedRecord, $user) < 0) {
			dol_syslog(__METHOD__.' imported flow '.$this->flow_id.' again but could not move record '.$importedRecord->id.' onto record '.$this->id.': '.$this->error, LOG_WARNING);
		}

		return array('res' => ($newInvoiceId > 0 ? $newInvoiceId : 1), 'message' => (string) ($res['message'] ?? ''));
	}

	/**
	 * Find the record an import has just written for this flow, that is the most recent record of the
	 * same flow other than this one.
	 *
	 * @return	?Document		The record, null when the import wrote none
	 */
	private function fetchRecordWrittenByImport()
	{
		$sql = "SELECT rowid FROM ".MAIN_DB_PREFIX.$this->table_element;
		$sql .= " WHERE flow_id = '".$this->db->escape($this->flow_id)."'";
		$sql .= " AND fk_element_type = 'invoice_supplier'";
		$sql .= " AND entity IN (".getEntity($this->element).")";
		$sql .= " AND rowid <> ".((int) $this->id);
		$sql .= " ORDER BY rowid DESC LIMIT 1";

		$resql = $this->db->query($sql);
		if (!$resql) {
			dol_syslog(__METHOD__.' '.$this->db->lasterror(), LOG_ERR);

			return null;
		}

		$obj = $this->db->fetch_object($resql);
		$this->db->free($resql);
		if (empty($obj)) {
			return null;
		}

		$record = new Document($this->db);
		if ($record->fetch((int) $obj->rowid) <= 0) {
			return null;
		}

		return $record;
	}

	/**
	 * Take over what an import has just written for this flow, and remove the record it wrote.
	 *
	 * Everything the access point said about the flow is taken, including the invoice it has just been
	 * booked on; what belongs to this line as a line - its id, its entity, and who created it when -
	 * is kept, which is the whole point: the flow keeps its place in the list.
	 *
	 * @param	Document	$record		Record written by the import, deleted once its content is taken
	 * @param	User		$user		User asking for the import
	 * @return	int<-1,1>				1 when the record has been taken over, -1 on error
	 */
	private function adoptRecordWrittenByImport(Document $record, User $user)
	{
		// The identity of the line, as opposed to what it says about the flow.
		$ownfields = array('rowid', 'entity', 'date_creation', 'tms', 'fk_user_creat', 'fk_user_modif');

		$this->db->begin();

		foreach (array_keys($this->fields) as $field) {
			if (in_array($field, $ownfields)) {
				continue;
			}
			$this->$field = $record->$field;
		}
		$this->fk_user_modif = $user->id;

		if ($this->update($user) <= 0) {
			$this->db->rollback();

			return -1;
		}

		// The trigger refuses the deletion of a flow linked to a supplier invoice that exists, which is
		// exactly what this record is: it is not deleted here as a flow the user gives up on, it is the
		// same flow, on the line above. Its content has just been written there, so nothing is lost.
		if ($record->delete($user, 1) <= 0) {
			$this->error = $record->error ? $record->error : implode(', ', (array) $record->errors);
			$this->db->rollback();

			return -1;
		}

		$this->db->commit();

		return 1;
	}

	/**
	 * List the records of a supplier invoice other than this one, that is the lifecycle statuses its
	 * vendor has sent for it.
	 *
	 * @param	int			$invoiceid	Supplier invoice the records are attached to
	 * @return	int[]					Row ids, empty when there is none
	 */
	private function fetchOtherRecordsOfInvoice($invoiceid)
	{
		$ids = array();

		$sql = "SELECT rowid FROM ".MAIN_DB_PREFIX.$this->table_element;
		$sql .= " WHERE fk_element_type = 'invoice_supplier'";
		$sql .= " AND fk_element_id = ".((int) $invoiceid);
		$sql .= " AND rowid <> ".((int) $this->id);
		$sql .= " AND entity IN (".getEntity($this->element).")";

		$resql = $this->db->query($sql);
		if (!$resql) {
			dol_syslog(__METHOD__.' '.$this->db->lasterror(), LOG_ERR);

			return $ids;
		}

		while ($obj = $this->db->fetch_object($resql)) {
			$ids[] = (int) $obj->rowid;
		}
		$this->db->free($resql);

		return $ids;
	}

	/**
	 * Attach to a supplier invoice the lifecycle history of the one it replaces.
	 *
	 * A status sent by the vendor is about the document, not about the row Dolibarr booked it on, so an
	 * import made again must carry it over. Left in place it would point at a deleted invoice.
	 *
	 * @param	int			$previousinvoiceid	Supplier invoice the import has just replaced
	 * @param	int			$newinvoiceid		Supplier invoice the import has just created
	 * @param	int[]		$recordids			Records of the previous invoice, listed before it was deleted
	 * @param	string		$newref				Reference of the new invoice, as the flow list shows it
	 * @return	int<-1,1>						1 when the history has been moved, -1 on error
	 */
	private function moveHistoryToInvoice($previousinvoiceid, $newinvoiceid, $recordids, $newref)
	{
		$this->db->begin();

		if (!empty($recordids)) {
			$sql = "UPDATE ".MAIN_DB_PREFIX.$this->table_element;
			$sql .= " SET fk_element_id = ".((int) $newinvoiceid);
			$sql .= ", tracking_idref = '".$this->db->escape($newref)."'";
			$sql .= " WHERE rowid IN (".$this->db->sanitize(implode(',', $recordids)).")";
			if (!$this->db->query($sql)) {
				dol_syslog(__METHOD__.' '.$this->db->lasterror(), LOG_ERR);
				$this->db->rollback();

				return -1;
			}
		}

		$sql = "UPDATE ".MAIN_DB_PREFIX."einvoicing_lifecycle_msg";
		$sql .= " SET element_id = ".((int) $newinvoiceid);
		$sql .= " WHERE element_type = 'invoice_supplier'";
		$sql .= " AND element_id = ".((int) $previousinvoiceid);
		if (!$this->db->query($sql)) {
			dol_syslog(__METHOD__.' '.$this->db->lasterror(), LOG_ERR);
			$this->db->rollback();

			return -1;
		}

		$this->db->commit();

		return 1;
	}

	/**
	 * Give a draft supplier invoice the temporary reference of the draft it replaces.
	 *
	 * The core never reads an id back out of a "(PROV1234)" reference, it only tests the prefix, so the
	 * number of the deleted draft can be given back to the new row, files included.
	 * Only a temporary reference is moved this way, and only onto a draft: a validated invoice carries
	 * a number of the numbering module, which belongs to it alone.
	 *
	 * @param	FactureFournisseur	$invoice	Draft the import has just created, renamed in place on success
	 * @param	string				$wantedref	Reference of the draft it replaces
	 * @return	int<-1,1>						1 when renamed, 0 when there was nothing to do, -1 on error
	 */
	private function reuseDraftRef(FactureFournisseur $invoice, $wantedref)
	{
		global $conf;

		require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

		$currentref = (string) $invoice->ref;
		if ($wantedref === '' || $wantedref === $currentref) {
			return 0;
		}
		if (!preg_match('/^[\(]?PROV/i', $wantedref) || !preg_match('/^[\(]?PROV/i', $currentref)) {
			return 0;
		}
		if ((int) $invoice->status !== FactureFournisseur::STATUS_DRAFT) {
			return 0;
		}

		// Same path as the one the import writes its attachments to, and the same the card reads.
		$folderpart = get_exdir($invoice->id, 2, 0, 0, $invoice, 'invoice_supplier');
		$dirsource = $conf->fournisseur->facture->dir_output.'/'.$folderpart.dol_sanitizeFileName($currentref);
		$dirdest = $conf->fournisseur->facture->dir_output.'/'.$folderpart.dol_sanitizeFileName($wantedref);

		$moved = false;
		if (file_exists($dirsource)) {
			if (file_exists($dirdest)) {
				// Left over by something else: merging two directories is not this method's business.
				dol_syslog(__METHOD__.' cannot reuse reference '.$wantedref.': '.$dirdest.' already exists', LOG_WARNING);

				return 0;
			}
			if (!@rename($dirsource, $dirdest)) {
				dol_syslog(__METHOD__.' failed to rename '.$dirsource.' into '.$dirdest, LOG_ERR);

				return -1;
			}
			$moved = true;
		}

		$relativesource = 'fournisseur/facture/'.$folderpart.dol_sanitizeFileName($currentref);
		$relativedest = 'fournisseur/facture/'.$folderpart.dol_sanitizeFileName($wantedref);

		$this->db->begin();

		// Files named after the reference, then the directory they are indexed under: the two updates
		// the core itself makes when it renames a draft (FactureFournisseur::validate()).
		$sql = "UPDATE ".MAIN_DB_PREFIX."ecm_files SET";
		$sql .= " filename = CONCAT('".$this->db->escape($wantedref)."', SUBSTR(filename, ".(strlen($currentref) + 1).")),";
		$sql .= " filepath = '".$this->db->escape($relativedest)."'";
		$sql .= " WHERE filename LIKE '".$this->db->escape($this->db->escapeforlike($currentref))."%'";
		$sql .= " AND filepath = '".$this->db->escape($relativesource)."'";
		$sql .= " AND entity = ".((int) $conf->entity);
		$ok = (bool) $this->db->query($sql);

		if ($ok) {
			$sql = "UPDATE ".MAIN_DB_PREFIX."ecm_files SET filepath = '".$this->db->escape($relativedest)."'";
			$sql .= " WHERE filepath = '".$this->db->escape($relativesource)."'";
			$sql .= " AND entity = ".((int) $conf->entity);
			$ok = (bool) $this->db->query($sql);
		}

		if ($ok) {
			$sql = "UPDATE ".MAIN_DB_PREFIX."facture_fourn SET ref = '".$this->db->escape($wantedref)."'";
			$sql .= " WHERE rowid = ".((int) $invoice->id);
			$ok = (bool) $this->db->query($sql);
		}

		if (!$ok) {
			dol_syslog(__METHOD__.' '.$this->db->lasterror(), LOG_ERR);
			$this->db->rollback();
			if ($moved) {
				@rename($dirdest, $dirsource);
			}

			return -1;
		}

		$this->db->commit();

		// The files themselves, when their name starts with the reference that has just changed.
		if ($moved) {
			foreach (dol_dir_list($dirdest, 'files', 1, '^'.preg_quote(dol_sanitizeFileName($currentref), '/')) as $fileentry) {
				$newname = preg_replace('/^'.preg_quote(dol_sanitizeFileName($currentref), '/').'/', dol_sanitizeFileName($wantedref), $fileentry['name']);
				@rename($fileentry['path'].'/'.$fileentry['name'], $fileentry['path'].'/'.$newname);
			}
		}

		$invoice->ref = $wantedref;

		return 1;
	}

	/**
	 *  Delete a line of object in database
	 *
	 *	@param	User		$user		User that delete
	 *  @param	int			$idline		Id of line to delete
	 *  @param	int<0,1>	$notrigger	0=launch triggers after, 1=disable triggers
	 *  @return	int<-2,1>				>0 if OK, <0 if KO
	 */
	public function deleteLine(User $user, $idline, $notrigger = 0)
	{
		if ($this->status < 0) {
			$this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
			return -2;
		}

		return $this->deleteLineCommon($user, $idline, $notrigger);
	}


	/**
	 *	Validate object
	 *
	 *	@param	User		$user		User making status change
	 *  @param	int<0,1>	$notrigger	1=Does not execute triggers, 0= execute triggers
	 *	@return	int<-1,1>				Return integer <=0 if OK, 0=Nothing done, >0 if KO
	 */
	public function validate($user, $notrigger = 0)
	{
		global $conf;

		require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

		$error = 0;

		// Protection
		if ($this->status == self::STATUS_VALIDATED) {
			dol_syslog(get_class($this)."::validate action abandoned: already validated", LOG_WARNING);
			return 0;
		}

		$now = dol_now();

		$this->db->begin();

		// The object has no ref column and the module ships no numbering model: fetchCommon() fills
		// $this->ref with the row id, and the reference the user sees is tracking_idref.
		$num = (string) $this->ref;
		$this->newref = $num;

		if (!empty($num)) {
			// Validate
			$sql = "UPDATE ".$this->db->prefix().$this->table_element;
			$sql .= " SET ";
			if (!empty($this->fields['ref'])) {
				$sql .= " ref = '".$this->db->escape($num)."',";
			}
			$sql .= " status = ".self::STATUS_VALIDATED;
			if (!empty($this->fields['date_validation'])) {
				$sql .= ", date_validation = '".$this->db->idate($now)."'";
			}
			if (!empty($this->fields['fk_user_valid'])) {
				$sql .= ", fk_user_valid = ".((int) $user->id);
			}
			$sql .= " WHERE rowid = ".((int) $this->id);

			dol_syslog(get_class($this)."::validate()", LOG_DEBUG);
			$resql = $this->db->query($sql);
			if (!$resql) {
				dol_print_error($this->db);
				$this->error = $this->db->lasterror();
				$error++;
			}

			if (!$error && !$notrigger) {
				// Call trigger
				$result = $this->call_trigger('MYOBJECT_VALIDATE', $user);
				if ($result < 0) {
					$error++;
				}
				// End call triggers
			}
		}

		if (!$error) {
			$this->oldref = $this->ref;

			// Rename directory if dir was a temporary ref
			if (preg_match('/^[\(]?PROV/i', $this->ref)) {
				// Now we rename also files into index
				$sql = 'UPDATE '.$this->db->prefix()."ecm_files set filename = CONCAT('".$this->db->escape($this->newref)."', SUBSTR(filename, ".(strlen($this->ref) + 1).")), filepath = 'document/".$this->db->escape($this->newref)."'";
				$sql .= " WHERE filename LIKE '".$this->db->escape($this->ref)."%' AND filepath = 'document/".$this->db->escape($this->ref)."' and entity = ".((int) $conf->entity);
				$resql = $this->db->query($sql);
				if (!$resql) {
					$error++;
					$this->error = $this->db->lasterror();
				}
				$sql = 'UPDATE '.$this->db->prefix()."ecm_files set filepath = 'document/".$this->db->escape($this->newref)."'";
				$sql .= " WHERE filepath = 'document/".$this->db->escape($this->ref)."' and entity = ".((int) $conf->entity);
				$resql = $this->db->query($sql);
				if (!$resql) {
					$error++;
					$this->error = $this->db->lasterror();
				}

				// We rename directory ($this->ref = old ref, $num = new ref) in order not to lose the attachments
				$oldref = dol_sanitizeFileName($this->ref);
				$newref = dol_sanitizeFileName($num);
				$dirsource = $conf->einvoicing->dir_output.'/document/'.$oldref;
				$dirdest = $conf->einvoicing->dir_output.'/document/'.$newref;
				if (!$error && file_exists($dirsource)) {
					dol_syslog(get_class($this)."::validate() rename dir ".$dirsource." into ".$dirdest);

					if (@rename($dirsource, $dirdest)) {
						dol_syslog("Rename ok");
						// Rename docs starting with $oldref with $newref
						$listoffiles = dol_dir_list($conf->einvoicing->dir_output.'/document/'.$newref, 'files', 1, '^'.preg_quote($oldref, '/'));
						foreach ($listoffiles as $fileentry) {
							$dirsource = $fileentry['name'];
							$dirdest = preg_replace('/^'.preg_quote($oldref, '/').'/', $newref, $dirsource);
							$dirsource = $fileentry['path'].'/'.$dirsource;
							$dirdest = $fileentry['path'].'/'.$dirdest;
							@rename($dirsource, $dirdest);
						}
					}
				}
			}
		}

		// Set new ref and current status
		if (!$error) {
			$this->ref = $num;
			$this->status = self::STATUS_VALIDATED;
		}

		if (!$error) {
			$this->db->commit();
			return 1;
		} else {
			$this->db->rollback();
			return -1;
		}
	}


	/**
	 *	Set draft status
	 *
	 *	@param	User		$user		Object user that modify
	 *  @param	int<0,1>	$notrigger	1=Does not execute triggers, 0=Execute triggers
	 *	@return	int<0,1>				Return integer <0 if KO, >0 if OK
	 */
	public function setDraft($user, $notrigger = 0)
	{
		// Protection
		if ($this->status <= self::STATUS_DRAFT) {
			return 0;
		}

		return $this->setStatusCommon($user, self::STATUS_DRAFT, $notrigger, 'EINVOICING_MYOBJECT_UNVALIDATE');
	}

	/**
	 *	Set cancel status
	 *
	 *	@param	User		$user		Object user that modify
	 *  @param	int<0,1>	$notrigger	1=Does not execute triggers, 0=Execute triggers
	 *	@return	int<-1,1>				Return integer <0 if KO, 0=Nothing done, >0 if OK
	 */
	public function cancel($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_VALIDATED) {
			return 0;
		}

		return $this->setStatusCommon($user, self::STATUS_CANCELED, $notrigger, 'EINVOICING_MYOBJECT_CANCEL');
	}

	/**
	 *	Set back to validated status
	 *
	 *	@param	User		$user			Object user that modify
	 *  @param	int<0,1>	$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int<-1,1>					Return integer <0 if KO, 0=Nothing done, >0 if OK
	 */
	public function reopen($user, $notrigger = 0)
	{
		// Protection
		if ($this->status == self::STATUS_VALIDATED) {
			return 0;
		}

		return $this->setStatusCommon($user, self::STATUS_VALIDATED, $notrigger, 'EINVOICING_MYOBJECT_REOPEN');
	}

	/**
	 * getTooltipContentArray
	 *
	 * @param	array<string,string> 	$params 	Params to construct tooltip data
	 * @since 	v18
	 * @return	array{optimize?:string,picto?:string,ref?:string}
	 */
	public function getTooltipContentArray($params)
	{
		global $langs;

		$datas = [];

		if (getDolGlobalInt('MAIN_OPTIMIZEFORTEXTBROWSER')) {
			return ['optimize' => $langs->trans("ShowDocument")];
		}
		$datas['picto'] = img_picto('', $this->picto).' <u>'.$langs->trans("Document").'</u>';
		if (isset($this->status)) {
			$datas['picto'] .= ' '.$this->getLibStatut(5);
		}
		if (property_exists($this, 'ref')) {
			$datas['ref'] = '<br><b>'.$langs->trans('Ref').':</b> '.$this->ref;
		}
		if (property_exists($this, 'label')) {
			$datas['ref'] = '<br>'.$langs->trans('Label').':</b> '.$this->label;
		}

		return $datas;
	}

	/**
	 *  Return a link to the object card (with optionally the picto)
	 *
	 *  @param	int     $withpicto                  Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
	 *  @param	string  $option                     On what the link point to ('nolink', ...)
	 *  @param	int     $notooltip                  1=Disable tooltip
	 *  @param	string  $morecss                    Add more css on link
	 *  @param	int     $save_lastsearch_value      -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
	 *  @return	string                              String with URL
	 */
	public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
	{
		global $conf, $langs, $hookmanager;

		if (!empty($conf->dol_no_mouse_hover)) {
			$notooltip = 1; // Force disable tooltips
		}

		$result = '';
		$params = [
			'id' => (string) $this->id,
			'objecttype' => $this->element.($this->module ? '@'.$this->module : ''),
			'option' => $option,
		];
		$classfortooltip = 'classfortooltip';
		$dataparams = '';
		if (getDolGlobalInt('MAIN_ENABLE_AJAX_TOOLTIP')) {
			$classfortooltip = 'classforajaxtooltip';
			$dataparams = ' data-params="'.dol_escape_htmltag(json_encode($params)).'"';
			$label = '';
		} else {
			$label = implode($this->getTooltipContentArray($params));
		}

		$baseurl = dol_buildpath('/einvoicing/document_card.php', 1);
		$query = ['id' => $this->id];
		if ($option !== 'nolink') {
			// Add param to save lastsearch_values or not
			$add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
			if ($save_lastsearch_value == -1 && isset($_SERVER["PHP_SELF"]) && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) {
				$add_save_lastsearch_values = 1;
			}
			if ($add_save_lastsearch_values) {
				$query = array_merge($query, ['save_lastsearch_values' => 1]);
			}
		}
		$url = $baseurl . '?' . http_build_query($query);

		$linkclose = '';
		if (empty($notooltip)) {
			if (getDolGlobalInt('MAIN_OPTIMIZEFORTEXTBROWSER')) {
				$label = $langs->trans("ShowDocument");
				$linkclose .= ' alt="'.dolPrintHTMLForAttribute($label).'"';
			}
			$linkclose .= ($label ? ' title="'.dolPrintHTMLForAttribute($label).'"' : ' title="tocomplete"');
			$linkclose .= $dataparams.' class="'.$classfortooltip.($morecss ? ' '.$morecss : '').'"';
		} else {
			$linkclose = ($morecss ? ' class="'.$morecss.'"' : '');
		}

		if ($option == 'nolink') {
			$linkstart = '<span';
		} else {
			$linkstart = '<a href="'.$url.'"';
		}
		$linkstart .= $linkclose.'>';
		if ($option == 'nolink') {
			$linkend = '</span>';
		} else {
			$linkend = '</a>';
		}

		$result .= $linkstart;

		if (empty($this->showphoto_on_popup)) {
			if ($withpicto) {
				$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), (($withpicto != 2) ? 'class="paddingright"' : ''), 0, 0, $notooltip ? 0 : 1);
			}
		} else {
			if ($withpicto) {
				require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

				list($class, $module) = explode('@', $this->picto);
				$upload_dir = $conf->$module->multidir_output[$conf->entity]."/$class/".dol_sanitizeFileName($this->ref);
				$filearray = dol_dir_list($upload_dir, "files");
				$filename = $filearray[0]['name'];
				if (!empty($filename)) {
					$pospoint = strpos($filearray[0]['name'], '.');

					$pathtophoto = $class.'/'.$this->ref.'/thumbs/'.substr($filename, 0, $pospoint).'_mini'.substr($filename, $pospoint);
					if (!getDolGlobalString(strtoupper($module.'_'.$class).'_FORMATLISTPHOTOSASUSERS')) {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref"><img class="photo'.$module.'" alt="No photo" border="0" src="'.DOL_URL_ROOT.'/viewimage.php?modulepart='.$module.'&entity='.$conf->entity.'&file='.urlencode($pathtophoto).'"></div></div>';
					} else {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><img class="photouserphoto userphoto" alt="No photo" border="0" src="'.DOL_URL_ROOT.'/viewimage.php?modulepart='.$module.'&entity='.$conf->entity.'&file='.urlencode($pathtophoto).'"></div>';
					}

					$result .= '</div>';
				} else {
					$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="'.(($withpicto != 2) ? 'paddingright ' : '').'"'), 0, 0, $notooltip ? 0 : 1);
				}
			}
		}

		if ($withpicto != 2) {
			$result .= $this->ref;
		}

		$result .= $linkend;
		//if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

		global $action, $hookmanager;
		$hookmanager->initHooks(array($this->element.'dao'));
		$parameters = array('id' => $this->id, 'getnomurl' => &$result);
		$reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) {
			$result = $hookmanager->resPrint;
		} else {
			$result .= $hookmanager->resPrint;
		}

		return $result;
	}

	/**
	 * Return a link to the card of the Dolibarr object the flow was exchanged for.
	 *
	 * tracking_idref only holds the reference as it was when the flow was exchanged, so an invoice sent while
	 * still a draft keeps its "(PROV552)" there for good. The link is built from fk_element_type/fk_element_id,
	 * which follow the object through its renaming, and the stored text is only the fallback label.
	 *
	 * @param	int		$withvendorref	1=Add the vendor reference of a supplier invoice on a second line
	 * @return	string					Link to the object card, or the stored reference when there is no object to link
	 */
	public function getElementNomUrl($withvendorref = 0)
	{
		$out = dol_escape_htmltag((string) $this->tracking_idref);

		if (empty($this->fk_element_type) || empty($this->fk_element_id)) {
			return $out;
		}

		// The core ships install/inc.php, which defines DOL_DOCUMENT_ROOT as '..'; PHPStan
		// resolves the constant against it and looks for the file next to the module.
		if ($this->fk_element_type === 'facture') {
			// @phpstan-ignore requireOnce.fileNotFound
			require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
			$linkedobject = new Facture($this->db);
		} elseif ($this->fk_element_type === 'invoice_supplier') {
			// @phpstan-ignore requireOnce.fileNotFound
			require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
			$linkedobject = new FactureFournisseur($this->db);
		} else {
			return $out;
		}

		if ($linkedobject->fetch((int) $this->fk_element_id) <= 0) {
			return $out;
		}

		$out = $linkedobject->getNomUrl(1);

		if ($withvendorref && $linkedobject instanceof FactureFournisseur && !empty($linkedobject->ref_supplier)) {
			$out = '<div class="tdoverflowmax200 inline-block lineheightsmall">'.$out;
			// The vendor reference is a field of the received document, escaped like the rest of it.
			$out .= '<br><span class="spantitle small">'.dol_escape_htmltag($linkedobject->ref_supplier).'</span>';
			$out .= '</div>';
		}

		return $out;
	}

	/**
	 * Return HTML string to show a field into a page, overridden to link the reference of the object to its card
	 *
	 * @param	array<string,mixed>	$val			Array of properties of field to show
	 * @param	string				$key			Key of attribute
	 * @param	string				$value			Preselected value to show
	 * @param	string				$moreparam		To add more parameters on html tag
	 * @param	string				$keysuffix		Prefix string to add into name and id of field
	 * @param	string				$keyprefix		Suffix string to add into name and id of field
	 * @param	mixed				$morecss		Value for CSS to use (Old usage: May also be a numeric to define a size)
	 * @return	string
	 */
	public function showOutputField($val, $key, $value, $moreparam = '', $keysuffix = '', $keyprefix = '', $morecss = '')
	{
		if ($key === 'tracking_idref') {
			return $this->getElementNomUrl();
		}

		return parent::showOutputField($val, $key, $value, $moreparam, $keysuffix, $keyprefix, $morecss);
	}

	/**
	 *	Return a thumb for kanban views
	 *
	 *	@param	string	    			$option		Where point the link (0=> main card, 1,2 => shipment, 'nolink'=>No link)
	 *  @param	?array<string,mixed>	$arraydata	Array of data
	 *  @return	string								HTML Code for Kanban thumb.
	 */
	public function getKanbanView($option = '', $arraydata = null)
	{
		global $conf, $langs;

		$selected = (empty($arraydata['selected']) ? 0 : $arraydata['selected']);

		$return = '<div class="box-flex-item box-flex-grow-zero">';
		$return .= '<div class="info-box info-box-sm">';
		$return .= '<span class="info-box-icon bg-infobox-action">';
		$return .= img_picto('', $this->picto);
		$return .= '</span>';
		$return .= '<div class="info-box-content">';
		$return .= '<span class="info-box-ref inline-block tdoverflowmax150 valignmiddle">'.(method_exists($this, 'getNomUrl') ? $this->getNomUrl() : $this->ref).'</span>';
		if ($selected >= 0) {
			$return .= '<input id="cb'.$this->id.'" class="flat checkforselect fright" type="checkbox" name="toselect[]" value="'.$this->id.'"'.($selected ? ' checked="checked"' : '').'>';
		}
		if (property_exists($this, 'label')) {
			$return .= ' <div class="inline-block opacitymedium valignmiddle tdoverflowmax100">'.$this->label.'</div>';
		}
		if (property_exists($this, 'thirdparty') && is_object($this->thirdparty)) {
			$return .= '<br><div class="info-box-ref tdoverflowmax150">'.$this->thirdparty->getNomUrl(1).'</div>';
		}
		if (property_exists($this, 'amount')) {
			$return .= '<br>';
			$return .= '<span class="info-box-label amount">'.price($this->amount, 0, $langs, 1, -1, -1, $conf->currency).'</span>'; // @phan-suppress-current-line PhanUndeclaredProperty
		}
		if (method_exists($this, 'getLibStatut')) {
			$return .= '<br><div class="info-box-status">'.$this->getLibStatut(3).'</div>';
		}
		$return .= '</div>';
		$return .= '</div>';
		$return .= '</div>';

		return $return;
	}

	/**
	 *  Return the label of the status
	 *
	 *  @param	int<0,6>	$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLabelStatus($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	/**
	 *  Return the label of the status
	 *
	 *  @param	int<0,6>	$mode	0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string				Label of status
	 */
	public function getLibStatut($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	/**
	 *  Return the label of a given status
	 *
	 *  @param	int			$status		Id status
	 *  @param	int<0,6>	$mode		0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string					Label of status
	 */
	public function LibStatut($status, $mode = 0)
	{
		// phpcs:enable
		if (is_null($status)) {
			return '';
		}

		$paramsBadge = array('badgeParams' => array('attr' => array(
			'data-status-element' => $this->element,
			'data-status' => (int) $status
		)));


		if (empty($this->labelStatus) || empty($this->labelStatusShort)) {
			global $langs;
			//$langs->load("einvoicing@einvoicing");
			$this->labelStatus[self::STATUS_DRAFT] = $langs->transnoentitiesnoconv('Draft');
			$this->labelStatus[self::STATUS_VALIDATED] = $langs->transnoentitiesnoconv('Enabled');
			$this->labelStatus[self::STATUS_CANCELED] = $langs->transnoentitiesnoconv('Disabled');
			$this->labelStatusShort[self::STATUS_DRAFT] = $langs->transnoentitiesnoconv('Draft');
			$this->labelStatusShort[self::STATUS_VALIDATED] = $langs->transnoentitiesnoconv('Enabled');
			$this->labelStatusShort[self::STATUS_CANCELED] = $langs->transnoentitiesnoconv('Disabled');
		}

		$statusType = 'status'.$status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		if ($status == self::STATUS_CANCELED) {
			$statusType = 'status6';
		}

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode, '', $paramsBadge);
	}

	/**
	 *	Load the info information in the object
	 *
	 *	@param	int		$id       Id of object
	 *	@return	void
	 */
	public function info($id)
	{
		$sql = "SELECT t.rowid, t.date_creation as datec";
		if (!empty($this->isextrafieldmanaged) && $this->isextrafieldmanaged == 1) {
			$sql .= ", GREATEST(t.tms, te.tms) as datem";
		} else {
			$sql .= ", t.tms as datem";
		}
		if (!empty($this->fields['date_validation'])) {
			$sql .= ", t.date_validation as datev";
		}
		if (!empty($this->fields['fk_user_creat'])) {
			$sql .= ", t.fk_user_creat";
		}
		if (!empty($this->fields['fk_user_modif'])) {
			$sql .= ", t.fk_user_modif";
		}
		if (!empty($this->fields['fk_user_valid'])) {
			$sql .= ", t.fk_user_valid";
		}
		$sql .= " FROM ".$this->db->prefix().$this->table_element." as t";
		if (!empty($this->isextrafieldmanaged) && $this->isextrafieldmanaged == 1) {
			$sql .= " LEFT JOIN ".$this->db->prefix().$this->table_element."_extrafields as te ON te.fk_object = t.rowid";
		}
		$sql .= " WHERE t.rowid = ".((int) $id);

		$result = $this->db->query($sql);
		if ($result) {
			if ($this->db->num_rows($result)) {
				$obj = $this->db->fetch_object($result);

				$this->id = $obj->rowid;

				if (!empty($this->fields['fk_user_creat'])) {
					$this->user_creation_id = $obj->fk_user_creat;
				}
				if (!empty($this->fields['fk_user_modif'])) {
					$this->user_modification_id = $obj->fk_user_modif;
				}
				if (!empty($this->fields['fk_user_valid'])) {
					$this->user_validation_id = $obj->fk_user_valid;
				}
				$this->date_creation = $this->db->jdate($obj->datec);
				$this->date_modification = empty($obj->datem) ? '' : $this->db->jdate($obj->datem);
				if (!empty($obj->datev)) {
					$this->date_validation = empty($obj->datev) ? '' : $this->db->jdate($obj->datev);
				}
			}

			$this->db->free($result);
		} else {
			dol_print_error($this->db);
		}
	}

	/**
	 * Initialize object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return	int
	 */
	public function initAsSpecimen()
	{
		// Set here init that are not commonf fields
		// $this->property1 = ...
		// $this->property2 = ...

		return $this->initAsSpecimenCommon();
	}

	/**
	 * 	Create an array of lines
	 *
	 * 	@return	CommonObjectLine[]|int		array of lines if OK, <0 if KO
	 */
	public function getLinesArray()
	{
		$this->lines = array();

		$objectline = new DocumentLine($this->db);
		$result = $objectline->fetchAll('ASC', 'position', 0, 0, '(fk_document:=:'.((int) $this->id).')');

		if (is_numeric($result)) {
			$this->setErrorsFromObject($objectline);
			return $result;
		} else {
			$this->lines = $result;
			return $this->lines;
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 *  @param	string		$modele			Force template to use ('' to not force)
	 *  @param	Translate	$outputlangs	object lang a utiliser pour traduction
	 *  @param	int<0,1>	$hidedetails    Hide details of lines
	 *  @param	int<0,1>	$hidedesc       Hide description
	 *  @param	int<0,1>	$hideref        Hide ref
	 *  @param	?array<string,string>  $moreparams     Array to provide more information
	 *  @return	int         				0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	{
		global $langs;

		$result = 0;
		$includedocgeneration = 0;

		$langs->load("einvoicing@einvoicing");

		if (!dol_strlen($modele)) {
			if (!empty($this->model_pdf)) {
				$modele = $this->model_pdf;
			} else {
				$modele = getDolGlobalString('MYOBJECT_ADDON_PDF', 'standard_document');
			}
		}

		$modelpath = "core/modules/einvoicing/doc/";

		if ($includedocgeneration && !empty($modele)) {
			$result = $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
		}

		return $result;
	}

	/**
	 * Return validation test result for a field.
	 * Need MAIN_ACTIVATE_VALIDATION_RESULT to be called.
	 *
	 * @param   array<string,array{type:string,label:string,enabled:int<0,2>|string,position:int,notnull?:int,visible:int<-2,5>|string,noteditable?:int<0,1>,default?:int<0,1>|string,index?:int,foreignkey?:string,searchall?:int<0,1>,isameasure?:int<0,1>,css?:string,csslist?:string,help?:string,showoncombobox?:int<0,2>,disabled?:int<0,1>,arrayofkeyval?:array<int|string,string>,comment?:string,validate?:int<0,1>}>  $fields Array of properties of field to show
	 * @param	string  $fieldKey            Key of attribute
	 * @param	string  $fieldValue          value of attribute
	 * @return	bool 						Return false if fail, true on success, set $this->error for error message
	 */
	public function validateField($fields, $fieldKey, $fieldValue)
	{
		// Add your own validation rules here.
		// ...

		return parent::validateField($fields, $fieldKey, $fieldValue);
	}


	/**
	 * Action executed by scheduler. This is the only cron job of the module, declared by
	 * modEInvoicing::$cronjobs. It takes no parameter from the 'Parameters' setup field.
	 *
	 * @return	int			0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
	 */
	public function cronSyncFlows()
	{
		global $langs;

		$error = 0;
		$this->output = '';

		dol_syslog(__METHOD__." start", LOG_INFO);

		// Run from the scheduler, nothing has loaded the provider classes yet: the cron runner only
		// includes this class file. Without this the job dies on "Class PDPProviderManager not found",
		// a fatal the scheduler reports as a plain failed job.
		require_once __DIR__ . '/providers/PDPProviderManager.class.php';

		// Generation-only mode: nothing is ever sent or received, so the sync job must not reach the
		// network even if a real provider is still selected in EINVOICING_PDP.
		if (getDolGlobalString('EINVOICING_PDP') && !getDolGlobalString('EINVOICING_ONLY_GENERATE')) {
			$providerManager = new PDPProviderManager($this->db);
			$provider = $providerManager->getProvider(getDolGlobalString('EINVOICING_PDP'));
		}

		if (isset($provider)) {
			// A flow postponed on one run (nothing stored for it) is only re-listed by a later run if the
			// cursor still reaches back to it - a margin, applied here since the manual sync of
			// document_list.php can already be re-run with a hand-picked date, the cron cannot. The flows
			// it re-lists that are already stored are cheaply discarded by the alreadyProcessedFlowIds
			// pre-check in syncFlows(), which queries only the flowIds of the current listing.
			$syncFromDate = $provider->getLastSyncDate(getDolGlobalInt('EINVOICING_SYNC_MARGIN_TIME_HOURS'));
			$maxflows = self::getCronSyncBatchSize();

			// Sync all flows
			$sync_result = $provider->syncFlows($syncFromDate, $maxflows);

			if (!empty($sync_result['messages'])) {
				$this->output = implode('<br>', $sync_result['messages']);
			}

			if ($sync_result['res'] <= 0) {
				$error++;
				// The scheduler builds what it shows from $this->error and $this->errors, never from
				// $this->output. Leaving both empty is what turns a precise cause into the bare
				// "Unknown error" the job card ends up displaying.
				if (!empty($sync_result['actions'])) {
					// A business error already carries a message written for a human, and the technical
					// line with it, inside the tooltip its picto opens on the card. Handing the transcript
					// to the scheduler as well would print that same line a second time and in clear,
					// under the very action the operator is being asked to carry out. What is missing here
					// is a cause, not a copy of one: give the sentence that closes the list, and stop
					// writing it above them.
					$this->output .= '<br>';
					foreach ($sync_result['actions'] as $action) {
						$this->output .= "---<br>";
						$this->output .= $action['businessmessage'] . '<br>';
					}
					// Not rtrim($output, '<br>'): rtrim strips characters, not a string, so it eats into
					// the closing tags of the business message and leaves broken markup behind.
					$this->output = preg_replace('/<br>$/', '', $this->output);
					$this->error = $langs->trans("EINVOICING_JOB_MANUAL_ACTION_REQUIRED");
				} else {
					// Everything else has no message written for a human, so the transcript is what the
					// operator gets. A third-party provider may only fill the older 'details' key, so fall
					// back on it rather than on nothing.
					$this->errors = $sync_result['errors'] ?? ($sync_result['details'] ?? array());

					// The early returns of syncFlows() - the access point answering something other than
					// 200, the lookup of the already-processed flows failing - put their one message in
					// both keys. The scheduler prints output and then the cause, so leaving it in both
					// shows it twice.
					$this->output = implode('<br>', array_diff($sync_result['messages'] ?? array(), $this->errors));
				}
			}
		} else {
			$error++;
			// Set on error only, not on output: the scheduler concatenates the two and would show it twice.
			$this->error = $langs->trans("NoPDPProviderConfigured");
		}

		$this->output = trim($this->output);

		dol_syslog(__METHOD__." end", LOG_INFO);

		return $error ?: 0;
	}

	/**
	 * The hidden EINVOICING_FLOWS_SYNC_CRON_SIZE must keep falling back on EINVOICING_FLOWS_SYNC_CALL_SIZE, the admin setting.
	 *
	 * @return int	Number of flows the scheduled sync asks for
	 */
	public static function getCronSyncBatchSize()
	{
		return getDolGlobalInt('EINVOICING_FLOWS_SYNC_CRON_SIZE', getDolGlobalInt('EINVOICING_FLOWS_SYNC_CALL_SIZE', 100));
	}

	/**
	 * Return true if given XML data can be stored in Database (size < 16Mo)
	 * @param ?string $xmlData The XML data to check
	 * @return bool True if xmlData is within size bounds
	 */
	public static function checkXmlDataMaxSize(&$xmlData): bool
	{
		if (isset($xmlData)) {
			// 16Mo for MEDIUMTEXT
			return (strlen($xmlData) <= 16777215);
		}
		return true;
	}

	/**
	 * Clean XML data by removing or replacing specific contents like :
	 * - attachments
	 *
	 * Not optional: this column is a MEDIUMTEXT capped at 16 Mo by checkXmlDataMaxSize(), and one
	 * embedded PDF is enough to pass it - a document too big is then not stored at all.
	 * EINVOICING_SPLIT_XML_WITH_EMBEDDED_PDF_IN_TWO_FILES only concerns the file kept on disk beside
	 * the supplier invoice, which is otherwise the document the access point returned, byte for byte.
	 *
	 * @param ?string $xmlData The XML data to clean
	 * @return ?string The cleaned XML data
	 */
	public static function cleanXmlData($xmlData)
	{
		global $db;

		if (!isset($xmlData) || $xmlData === '') {
			return $xmlData;
		}

		$protocolManager = new ProtocolManager($db);
		$detectedProtocolName = $protocolManager->detectProtocolFromContent($xmlData);
		if (!isset($detectedProtocolName)) {
			throw new Exception(__METHOD__ . " : protocol not detected for XML data");
		}
		$protocol = $protocolManager->getProtocol($detectedProtocolName);
		$protocolClassName = get_class($protocol);

		$cleanedXmlData = $protocolClassName::removeAttachmentFromXml($xmlData);

		return $cleanedXmlData;
	}
}


require_once DOL_DOCUMENT_ROOT.'/core/class/commonobjectline.class.php';

/**
 * Class DocumentLine. You can also remove this and generate a CRUD class for lines objects.
 */
class DocumentLine extends CommonObjectLine
{
	// To complete with content of an object DocumentLine
	// We should have a field rowid, fk_document and position

	/**
	 * To overload
	 * @see CommonObjectLine
	 */
	public $parent_element = '';		// Example: '' or 'document'

	/**
	 * To overload
	 * @see CommonObjectLine
	 */
	public $fk_parent_attribute = '';	// Example: '' or 'fk_document'

	/**
	 * @var int<0,1>	Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 0;

	/**
	 * @var int<0,1>|string|null  	Does this object support multicompany module ?
	 * 								0=No test on entity, 1=Test with field entity in local table, 'field@table'=Test entity into the field@table (example 'fk_soc@societe')
	 */
	public $ismultientitymanaged = 0;


	/**
	 * Constructor
	 *
	 * @param	DoliDB $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		$this->db = $db;
	}
}
