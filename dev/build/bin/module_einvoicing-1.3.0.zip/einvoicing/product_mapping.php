<?php
/* Copyright (C) 2026		Pierre Grasswill				<da.grumpf@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       product_mapping.php
 *		\ingroup    einvoicing
 *		\brief      Map the vendor product references of an incoming e-invoice onto existing Dolibarr products.
 *
 *		When the automatic creation of products is disabled, the synchronization of a supplier invoice stops
 *		on the first line whose product cannot be found. This page lists all the lines of the flow, shows
 *		which ones are already resolved, and lets the user link the unresolved ones to existing products.
 *		The link is stored as a vendor reference (llx_product_fournisseur_price), which is the first criteria
 *		used by the product matching, so the next synchronization will find the products by itself.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res && file_exists("../../../../main.inc.php")) {
	$res = @include "../../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}
/**
 * The main.inc.php has been included so the following variable are now defined:
 * @var Conf $conf
 * @var DoliDB $db
 * @var HookManager $hookmanager
 * @var Translate $langs
 * @var User $user
 */
include_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
include_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
include_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.product.class.php';
include_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';
include_once __DIR__.'/class/providers/PDPProviderManager.class.php';
include_once __DIR__.'/class/protocols/ProtocolManager.class.php';
include_once __DIR__.'/class/document.class.php';

// Load translation files required by the page
$langs->loadLangs(array("einvoicing@einvoicing", "products", "companies", "bills", "other"));


/**
 * Price of a single unit of a parsed line, the one this page shows and stores as a buying price.
 *
 * EN 16931 states BT-146 as the price of BT-149 units, so a line priced "2.00 per 100" carries a
 * ChargeAmount of 2.00 - which is not the price of one unit and must not be recorded as one
 * (issues #777 and #778). The protocol owns that arithmetic; this page only asks it.
 *
 * @param	object|null				$protocol	Protocol that parsed the flow, when it knows how to answer
 * @param	array<string,mixed>		$parsedLine	One line as parseInvoiceLines() returns it
 * @return	float								Price of a single unit, without tax
 */
function einvoicingLineUnitPrice($protocol, array $parsedLine)
{
	if (is_object($protocol) && method_exists($protocol, 'resolveLineUnitPrice')) {
		return (float) $protocol->resolveLineUnitPrice($parsedLine);
	}

	return (float) ($parsedLine['netpriceamount'] ?? 0);
}

// Get parameters
$action = GETPOST('action', 'aZ09');
$flowid = GETPOST('flowid', 'alphanohtml');
$socid = GETPOSTINT('socid');

$form = new Form($db);

$permissiontoread = $user->hasRight('einvoicing', 'read');
$permissiontoadd = $user->hasRight('einvoicing', 'write') && $user->hasRight('produit', 'creer');
// The default product of a vendor is a field of its thirdparty card, so it takes the right on the thirdparty.
$permissiontosetdefaultproduct = $user->hasRight('societe', 'creer');

if (!isModEnabled('einvoicing')) {
	accessforbidden();
}
if (!$permissiontoread) {
	accessforbidden();
}


/*
 * Load the lines of the flow
 */

$parsedLines = array();
$parsedHeader = array();
$loaderror = '';
$provider = null;
$protocol = null;

if (!empty($flowid)) {
	if (!getDolGlobalString('EINVOICING_PDP')) {
		$loaderror = $langs->trans("NoPDPDefined");
	} else {
		$providerManager = new PDPProviderManager($db);
		$provider = $providerManager->getProvider(getDolGlobalString('EINVOICING_PDP'));

		if (!is_object($provider)) {
			$loaderror = $langs->trans("FailedToGetProvider", getDolGlobalString('EINVOICING_PDP'));
		} else {
			// Get the invoice of the flow. We ask the 'Converted' document, like the synchronization does,
			// because the 'Original' one may use a syntax we are not able to parse (UBL...).
			$flowResponse = $provider->fetchFlowData($flowid, 'Converted', 'get_flow_for_product_mapping');

			if (empty($flowResponse['status_code']) || $flowResponse['status_code'] != 200) {
				$loaderror = $langs->trans("FailedToGetFlowContent", $flowid).(empty($flowResponse['errorMessage']) ? '' : ' - '.$flowResponse['errorMessage']);
			} else {
				$flowContent = $flowResponse['response'];

				$protocolManager = new ProtocolManager($db);
				$detectedProtocol = $protocolManager->detectProtocolFromContent($flowContent);
				$protocol = empty($detectedProtocol) ? null : $protocolManager->getProtocol($detectedProtocol);

				if (!is_object($protocol)) {
					$loaderror = $langs->trans("FailedToDetectProtocolOfFlow", $flowid);
				} else {
					// A Factur-X document is a PDF embedding the XML, so we may have to extract it first.
					$xmlData = method_exists($protocol, 'extractXmlFromFileContent') ? $protocol->extractXmlFromFileContent($flowContent) : $flowContent;

					// The extracted content is a pure XML (CII for a Factur-X PDF), so we may have to
					// switch to the protocol able to parse it.
					$detectedXmlProtocol = $protocolManager->detectProtocolFromContent($xmlData);
					if (!empty($detectedXmlProtocol) && $detectedXmlProtocol != $detectedProtocol) {
						$xmlProtocol = $protocolManager->getProtocol($detectedXmlProtocol);
						if (is_object($xmlProtocol)) {
							$protocol = $xmlProtocol;
						}
					}

					try {
						$parsedHeader = $protocol->parseInvoiceHeader($xmlData);
						$parsedLines = $protocol->parseInvoiceLines($xmlData);
					} catch (Exception $e) {
						$loaderror = $langs->trans("FailedToParseFlowContent", $flowid).' - '.$e->getMessage();
					}
				}
			}
		}
	}
}


/*
 * Actions
 */

if ($action == 'savemapping' && $permissiontoadd && !empty($parsedLines) && $socid > 0) {
	$supplier = new Societe($db);
	if ($supplier->fetch($socid) <= 0) {
		setEventMessages($langs->trans("ErrorRecordNotFound"), null, 'errors');
	} else {
		$nbdone = 0;
		$nberror = 0;

		foreach ($parsedLines as $idx => $parsedLine) {
			$idprod = GETPOSTINT('idprod_'.$idx);
			if ($idprod <= 0) {
				continue;
			}

			$reffourn = trim((string) ($parsedLine['prodsellerid'] ?? ''));
			if ($reffourn === '') {
				// Without a vendor reference we have nothing to store the mapping on
				continue;
			}

			$productFourn = new ProductFournisseur($db);
			$productFourn->id = $idprod;
			$resultbuyprice = $productFourn->update_buyprice(
				1,															// qty min
				einvoicingLineUnitPrice($protocol, $parsedLine),			// unit price without tax, BT-146 brought back to one unit
				$user,
				'HT',
				$supplier,
				0,															// availability
				$reffourn,													// vendor reference
				(float) ($parsedLine['rateApplicablePercent'] ?? 0)
			);

			if ($resultbuyprice < 0) {
				$nberror++;
				setEventMessages($langs->trans("FailedToMapProduct", $reffourn).' - '.$productFourn->error, null, 'errors');
			} else {
				$nbdone++;
			}
		}

		if ($nbdone > 0) {
			setEventMessages($langs->trans("NbOfProductsMapped", $nbdone), null, 'mesgs');
		}
		if (!$nbdone && !$nberror) {
			setEventMessages($langs->trans("NoProductMapped"), null, 'warnings');
		}

		// Reload the page to run the matching again on fresh data
		header("Location: ".$_SERVER["PHP_SELF"].'?flowid='.urlencode($flowid).'&socid='.((int) $socid));
		exit;
	}
}


/*
 * View
 */

$title = $langs->trans("MapEInvoiceProducts");
$help_url = '';

llxHeader('', $title, $help_url, '', 0, 0, '', '', '', 'mod-einvoicing page-product_mapping');

if (getDolGlobalInt("EINVOICING_MULTICOMPANY_USE_MASTER_SETUP") && $conf->entity != getDolGlobalInt("EINVOICING_MULTICOMPANY_USE_MASTER_SETUP")) {
	print $langs->trans("EInvoicingInfoManagedByMasterSetup", getDolGlobalInt("EINVOICING_MULTICOMPANY_USE_MASTER_SETUP"));

	llxFooter();
	exit;
}

print load_fiche_titre($title, '', 'einvoicing.png@einvoicing');

// The mappings saved here are only visible product by product afterwards, so point to the list of them.
$vendorrefsurl = dol_buildpath('/einvoicing/vendorref_list.php', 1).($socid > 0 ? '?search_socid='.((int) $socid) : '');

print '<div class="info"><span class="">'.$langs->trans("MapEInvoiceProductsDesc");
print ' '.$langs->trans("MapEInvoiceProductsDesc2");
print '</span>';
print ' - <a class="" href="'.$vendorrefsurl.'">'.$langs->trans("SeeMappedVendorRefs").'</a>';
print '</div><br>';

// Form to select the flow to work on (prefilled when we come from the synchronization result)
print '<form method="GET" action="'.$_SERVER["PHP_SELF"].'">';
print '<div class="inline-block valignmiddle paddingright">'.$langs->trans("flow_id").' ';
print '<input type="text" class="width200" name="flowid" value="'.dol_escape_htmltag($flowid).'">';
print '</div>';
print ' &nbsp; ';
print '<div class="inline-block valignmiddle paddingright">'.$langs->trans("Supplier").' ';
// Form::select_company() does not read this filter the same way on every version. Until Dolibarr 18
// the criteria is appended to the query as it stands, so it has to be plain SQL; from 18 a criteria
// holding parentheses is converted by forgeSQLFromUniversalSearchCriteria(), and on 24 that conversion
// is no longer conditional - every criteria goes through it. Passing the Universal Search syntax to 17
// therefore ends the page on "DB_ERROR_SYNTAX ... near ':=:1))'", and passing plain SQL to 24 would be
// mangled the other way round.
$vendorfilter = ((float) DOL_VERSION < 18) ? 's.fournisseur = 1' : '(s.fournisseur:=:1)';
print $form->select_company($socid, 'socid', $vendorfilter, 'SelectThirdParty', 0, 0, array(), 0, 'minwidth200');
print '</div>';
print '<input type="submit" class="button small" value="'.$langs->trans("Refresh").'">';
print '</form>';

print '<br>';

if ($loaderror) {
	setEventMessages($loaderror, null, 'errors');
	print '<div class="error">'.dol_escape_htmltag($loaderror).'</div>';
}

if (!empty($parsedLines)) {
	if (empty($socid)) {
		print '<div class="warning">'.$langs->trans("SelectTheSupplierOfThisFlow").'</div>';
	}

	// Run the matching on each line (read only, nothing is created here)
	// The matching method comes from the CommonProtocol trait, used by the protocols able to import an invoice.
	'@phan-var-force ?CIIProtocol $protocol';
	/** @var ?CIIProtocol $protocol */
	$nbtomap = 0;
	$matchresults = array();
	$defaultrouted = array();
	foreach ($parsedLines as $idx => $parsedLine) {
		$hasvendorref = (trim((string) ($parsedLine['prodsellerid'] ?? '')) !== '');
		$parsedLine['supplierId'] = $socid;
		$matchresults[$idx] = ($socid > 0 && is_object($protocol)) ? $protocol->findProductFromEinvoiceLine($parsedLine) : array('res' => 0, 'message' => '');
		// The default product of the vendor is a catch-all answering every line nothing was found for, so a
		// line it caught is routed, not mapped. As long as the line carries a vendor reference it can still
		// be bound to the right product, and it stays in the lines to map.
		$defaultrouted[$idx] = (($matchresults[$idx]['matchtype'] ?? '') == 'defaultrouting');
		if (empty($matchresults[$idx]['res']) || ($defaultrouted[$idx] && $hasvendorref)) {
			$nbtomap++;
		}
	}

	print '<div class="opacitymedium">';
	if (!empty($parsedHeader['documentno'])) {
		print $langs->trans("Invoice").' : '.dol_escape_htmltag($parsedHeader['documentno']).' - ';
	}
	print $langs->trans("NbOfLines").' : '.count($parsedLines).' - '.$langs->trans("NbOfLinesToMap").' : '.$nbtomap;
	print '</div><br>';

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="savemapping">';
	print '<input type="hidden" name="flowid" value="'.dol_escape_htmltag($flowid).'">';
	print '<input type="hidden" name="socid" value="'.((int) $socid).'">';

	print '<div class="div-table-responsive'.($flowid ? '-nomin' : '').'">';
	print '<table class="noborder centpercent">';
	print '<tr class="liste_titre">';
	print '<th>'.$langs->trans("Line").'</th>';
	print '<th>'.$langs->trans("VendorProductRef").'</th>';
	print '<th>'.$langs->trans("BuyerProductRef").'</th>';
	print '<th>'.$langs->trans("ProductGlobalId").'</th>';
	print '<th>'.$langs->trans("Label").'</th>';
	print '<th class="right">'.$langs->trans("Qty").'</th>';
	print '<th class="right">'.$langs->trans("PriceUHT").'</th>';
	print '<th class="right">'.$langs->trans("VATRate").'</th>';
	print '<th>'.$langs->trans("DolibarrProduct").'</th>';
	print '</tr>';

	foreach ($parsedLines as $idx => $parsedLine) {
		$reffourn = trim((string) ($parsedLine['prodsellerid'] ?? ''));

		print '<tr class="oddeven">';
		print '<td>'.dol_escape_htmltag((string) ($parsedLine['lineid'] ?? ($idx + 1))).'</td>';
		print '<td>'.dol_escape_htmltag($reffourn).'</td>';
		print '<td>'.dol_escape_htmltag((string) ($parsedLine['prodbuyerid'] ?? '')).'</td>';
		print '<td>'.dol_escape_htmltag((string) ($parsedLine['prodglobalid'] ?? '')).'</td>';
		print '<td>'.dol_escape_htmltag(dol_trunc((string) ($parsedLine['prodname'] ?? ''), 60)).'</td>';
		print '<td class="right">'.dol_escape_htmltag((string) ($parsedLine['billedquantity'] ?? '')).' '.dol_escape_htmltag((string) ($parsedLine['billedquantityunitcode'] ?? '')).'</td>';
		print '<td class="right">'.price(einvoicingLineUnitPrice($protocol, $parsedLine)).'</td>';
		print '<td class="right">'.price((float) ($parsedLine['rateApplicablePercent'] ?? 0)).'%</td>';

		print '<td>';
		if (!empty($matchresults[$idx]['res']) && empty($defaultrouted[$idx])) {
			// Line already resolved by the automatic matching
			$producttmp = new Product($db);
			if ($producttmp->fetch($matchresults[$idx]['res']) > 0) {
				print $producttmp->getNomUrl(1);
			} else {
				print '<span class="opacitymedium">'.$langs->trans("Product").' #'.((int) $matchresults[$idx]['res']).'</span>';
			}
			print ' '.$form->textwithpicto('', $matchresults[$idx]['message'], 1, 'help');
		} elseif ($socid <= 0) {
			print '<span class="opacitymedium">'.$langs->trans("SelectTheSupplierOfThisFlow").'</span>';
		} else {
			// Show the catch-all the line currently falls back on, then still offer to map it properly.
			if (!empty($defaultrouted[$idx])) {
				$producttmp = new Product($db);
				$routedto = ($producttmp->fetch($matchresults[$idx]['res']) > 0) ? $producttmp->getNomUrl(1) : $langs->trans("Product").' #'.((int) $matchresults[$idx]['res']);
				print $form->textwithpicto('<span class="opacitymedium">'.$langs->trans("LineRoutedToDefaultProduct").'</span> '.$routedto, $langs->trans("LineRoutedToDefaultProductHelp"), 1, 'warning');
				print '<br>';
			}
			if ($reffourn === '') {
				// Without a vendor reference, the mapping has nothing to be stored on
				print $form->textwithpicto('<span class="opacitymedium">'.$langs->trans("NotMappable").'</span>', $langs->trans("NotMappableBecauseNoVendorRef"), 1, 'warning');
			} elseif ($permissiontoadd) {
				// Filter on the purchase status (tobuy): the product of a supplier invoice line is bought, and a
				// product created by a previous import is not on sale, so filtering on tosell hides them all.
				print $form->select_produits(0, 'idprod_'.$idx, '', 0, 0, -1, 2, '', 0, array(), 0, '1', 0, 'maxwidth300', 0, '', null, 0, 1);
			} else {
				print '<span class="opacitymedium">'.$langs->trans("NotEnoughPermissions").'</span>';
			}
		}
		print '</td>';

		print '</tr>';
	}

	print '</table>';
	print '</div>';

	print '<div class="center paddingtop">';
	if ($nbtomap == 0 && $socid > 0) {
		print '<br><div class="ok">'.$langs->trans("AllLinesOfFlowAreMapped").'</div>';
	}
	if ($permissiontoadd && $socid > 0 && $nbtomap > 0) {
		print '<input type="submit" class="button" value="'.$langs->trans("SaveMappingAndCreateVendorRefs").'">';
	}
	// A line without any vendor reference has nothing to be mapped on, and the default product of the vendor
	// is the only answer for it. Same link as the one the synchronization suggests, so the page is not a
	// dead end - and a button, because it is reached when nothing else on the page can be done. Greyed and
	// titled without the right on the thirdparty, rather than absent: the user reads why, not "how?".
	if ($socid > 0) {
		$defaultproducturl = dol_buildpath('/societe/card.php', 1).'?socid='.((int) $socid).'&action=edit&highlight=routing_product_id#treinvoicing';
		if ($permissiontosetdefaultproduct) {
			print '<a class="button" href="'.dol_escape_htmltag($defaultproducturl).'" target="_blank">'.$langs->trans("SetDefaultProductForThirdparty").'</a>';
		} else {
			print '<a class="button disabled classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans("SetDefaultProductForThirdparty").'</a>';
		}
	}
	print '<a class="button button-cancel" href="'.dol_buildpath('/einvoicing/document_list.php', 1).'">'.$langs->trans("BackToSynchronization").'</a>';
	print '</div>';

	print '</form>';
} elseif (empty($loaderror) && !empty($flowid)) {
	print '<div class="warning">'.$langs->trans("NoLineFoundIntoThisFlow").'</div>';
}

// End of page
llxFooter();
$db->close();
