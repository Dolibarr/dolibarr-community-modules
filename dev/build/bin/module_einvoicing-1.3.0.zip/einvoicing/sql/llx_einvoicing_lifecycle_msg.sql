-- Copyright (C) 2025		SuperAdmin					<daoud.mouhamed@gmail.com>
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


CREATE TABLE llx_einvoicing_lifecycle_msg(
	rowid integer AUTO_INCREMENT PRIMARY KEY NOT NULL,
	element_id int NOT NULL, 		    			-- ID of element.
	element_type varchar(50) NOT NULL, 		    	-- Type of element (from property object->element)
    provider varchar(50) NOT NULL, 					-- Provider key ('esalink', ...)
	flow_id varchar(255),							-- Flow identifier UUID
	direction varchar(3) NOT NULL,					-- IN | OUT
	lc_status integer NOT NULL,						-- Lifecycle status code
	lc_status_message text NOT NULL,				-- Lifecycle status message (a rejection quotes whole Schematron assertions)
	lc_validation_status varchar(20) NOT NULL,		-- Lifecycle validation status: OK | PENDING | ERROR - only filled if direction is OUT
	lc_validation_message text NOT NULL,	-- Lifecycle validation message if error - only filled if direction is OUT
	lc_reason_code varchar(50) NOT NULL,			-- Reason code for current status if applicable (e.g. for rejected status)
	lc_recipient_roles varchar(50),					-- RoleCodes the CDAR addressed the status to ('SE', 'SE,BY'), empty when we sent it
	date_creation datetime NOT NULL,
	tms timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	fk_user_creat integer NOT NULL,
	fk_user_modif integer
) ENGINE=innodb;
